<div style="display: none;" class="register-login-modal">
        <div class="modal-content">
            <div class="modal-body">
              
                    <ul class="nav nav-tabs">
                        <li class="active dlzccss dldd" style="opacity: 1;"><a href="javascript:;" data-toggle="login">登录</a>
                        </li>
                        <li><a class="dlzccss zcdd" href="javascript:;" data-toggle="signup" style="opacity: 0.3;">注册</a>
                        </li>
                    </ul>
                    
  
                    <div class="tab-content">
                        
                        <div class="tab-pane fade in active" id="login666" style="display: block;">
                            <div class="signup-form-container text-center">
                                <form class="mb-0">
                                        <div class="form-group">
                                            <input type="text" class="form-control yhhyx" name="username" placeholder="*输入用户名">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control yhhyx" name="password" placeholder="*密码">
                                        </div>
                                        <button type="button" class="ljdl go-login btn btn--primary btn--block"><i class="fa fa-bullseye"></i> 安全登录</button> 
                                </form>
                            </div>
                        </div>
                        <div class="tab-pane fade in" id="signup666" style="display: none;">
                            <form class="mb-0">
                                    <div class="form-group">
                                        <input type="text" class="form-control yhhyx ywyhm" name="user_name" placeholder="*输入英文用户名">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control yhhyx yxxxx" name="user_email" placeholder="*输入邮箱">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control yhhyx" name="user_pass" placeholder="*输入密码(6位以上)">
                                    </div>
                                    <!--<div class="form-group yaoqing">-->
                                    <!--    <input type="password" class="form-control yhhyx" name="user_pass2" placeholder="*再次输入密码">-->
                          
                                    <!--</div>-->
                               
                               
                               <?php
                               
                               if($yanzhengma){
                                   echo '<div class="form-group">
                                        <div class="input-group">
                                          <input type="text" class="form-control yhhyx yxyzmm" name="captcha" placeholder="*验证码">
                                          <span class="input-group-btn">
                                            <button class="go-captcha_email btn btn--secondary fsyzm" type="button">发送验证码</button>
                                          </span>
                                        </div>
                                    </div>';
                               }
                 
                               
                               
                               
                               if($yanzhengmasj){
                                   echo '
                                   
                                    <div class="form-group">
                                        <input type="text" class="form-control yhhyx sjhs" name="sjhs" placeholder="*输入手机号">
                                    </div>
                                   
                                   <div class="form-group">
                                        <div class="input-group">
                                          <input type="text" class="form-control yhhyx sjyzm" name="captcha" placeholder="*验证码">
                                          <span class="input-group-btn">
                                            <button class="go-captcha_email btn btn--secondary fsyzm" type="button">发送验证码</button>
                                          </span>
                                        </div>
                                    </div>';
                               }
                               
                               
                               
                               
                               
                               
                               
                               
                               ?>
                
                                    
                               
                                    <button type="button" class="ljzc go-register btn btn--primary btn--block yqmc"><i class="fa fa-bullseye"></i> 立即注册</button>
                            </form>
                        </div>
                    </div>
                    
                    <a target="_blank" href="./tool/mimazhaohui.php" class="rest-password">忘记密码？</a>
                    
            </div>
        </div>
</div>


    
    