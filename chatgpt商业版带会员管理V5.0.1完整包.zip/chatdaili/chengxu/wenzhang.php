<?php include_once('./tool/get.php');?>
<?php
require('./code.php');
if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
    $ip = $_SERVER["HTTP_CF_CONNECTING_IP"];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
$expiration = time() + (30 * 24 * 60 * 60); 
setcookie("yhip", $ip, $expiration, "/");
require('./tool/coo.php');
require('./tool/pu.php');
if(($sfvip != '') || ($time2 < $time1)){
    $shihuiyuan = '是会员';
}
$banbenhao = file_get_contents($banbenhlj.'admin/banben.php');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="google" content="notranslate">
    <title><?php echo $wzmc;?></title>
    <meta name="description" content="<?php echo $wzms;?>">
    
<script type="text/javascript" src="/jquery.js?id=<?php echo $banbenhao;?>"></script>
<script src="/assets/jquery.cookie.min.js?id=<?php echo $banbenhao;?>"></script>          
<div id="cssah"></div>
<div id="cssah2"></div>
<script src="/assets/anse.js?id=<?php echo $banbenhao;?>"></script>    
<style>
</style>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="/css/index.css?id=<?php echo $banbenhao;?>">
    <script src="/assets/vue@2.62.js?id=<?php echo $banbenhao;?>"></script>
    <link rel="stylesheet" href="/assets/css.css?id=<?php echo $banbenhao;?>">
    <link href="/assets/bootstrap.min.css?id=<?php echo $banbenhao;?>" rel="stylesheet">
	<link rel="stylesheet" href="/css/common.css?id=<?php echo $banbenhao;?>">
	<link rel="stylesheet" href="/css/wenda.css?id=<?php echo $banbenhao;?>">
	<link rel="stylesheet" href="/css/hightlight.css?id=<?php echo $banbenhao;?>">
	<link rel="stylesheet" href="/zidingyi.css?id=<?php echo $banbenhao;?>">
	<link href="/assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="/assets/lm.css?id=<?php echo $banbenhao;?>">
    <link rel="stylesheet" href="/css/css/jiazai.css?id=<?php echo $banbenhao;?>">
    <link rel="stylesheet" href="/css/css/youhua.css?id=<?php echo $banbenhao;?>">
</head>
<?php
include_once('./tool/head.php');
?>
<body style="background: white;">
    
<div id="moxicon" class="zbsc" style="display:none;background-color: #f6f6f6;">

<transition name="el-zoom-in-center">

<div  class="con-left" v-show="left_show||dw>800" style="height: 100%; 
    
    
  top: 0;
  bottom: 0;
  
  background-color: #fff;
  z-index: 999;">
        <div style="padding: 10px;position: relative;flex: 1;overflow: auto">
            <div style="display: flex;flex-direction: column">

    
    <?php
    
$sfyjdl = $_COOKIE['dengluname'];
if(!empty(uacc())){
    
    
    if($gpt35qd == '0'){
        if($shihuiyuan == '是会员'){
            echo '<div class="p-4 gmtc2" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
        height: var(--n-merged-size);
        color: #FFF;
        font-size: var(--n-font-size);
        display: inline-flex;
        position: relative;
        overflow: hidden;
        text-align: center;
        border: var(--n-border);
        border-radius: var(--n-border-radius);
        --n-merged-color: var(--n-color);
        background-color: var(--n-merged-color);
        transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
        height: 100%;" class="" loading="eager" src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1="" data-image-src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1=""><!----></span><p style="margin-top: 10px;"><span class="" style="color: white;"> Hi,'.$sfyjdl.'&nbsp;<span data-v-bf40dc81="" class="bg-yellow-200 text-yellow-900 py-0.5 px-1.5 text-xs md:text-sm rounded-md uppercase" style="text-transform: uppercase; font-size: 0.275rem; line-height: 1.25rem; --un-bg-opacity:1; background-color: rgba(254,240,138,var(--un-bg-opacity)); --un-text-opacity:1; color: rgba(113,63,18,var(--un-text-opacity)); padding: 0.125rem 0.375rem; border-radius: 0.375rem;"> 尊贵会员 </span></span></p></div>';
    
        
        }else{
            echo '<div class="p-4 gmtc2" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
        height: var(--n-merged-size);
        color: #FFF;
        font-size: var(--n-font-size);
        display: inline-flex;
        position: relative;
        overflow: hidden;
        text-align: center;
        border: var(--n-border);
        border-radius: var(--n-border-radius);
        --n-merged-color: var(--n-color);
        background-color: var(--n-merged-color);
        transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
        height: 100%;" class="" loading="eager" src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1="" data-image-src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1=""><!----></span><p style="margin-top: 10px;"><span class="" style="color: white;"> Hi,'.$sfyjdl.'&nbsp;<span data-v-bf40dc81="" class="bg-yellow-200 text-yellow-900 py-0.5 px-1.5 text-xs md:text-sm rounded-md uppercase" style="text-transform: uppercase; font-size: 0.275rem; line-height: 1.25rem; --un-bg-opacity:1; background-color: rgba(254,240,138,var(--un-bg-opacity)); --un-text-opacity:1; color: rgba(113,63,18,var(--un-text-opacity)); padding: 0.125rem 0.375rem; border-radius: 0.375rem;"> 升级会员 </span></span></p></div>';
        }
    }else{
        
        
        if($orqiandao == '已签到'){
            echo '<div class="p-4 weiqiandao" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
        height: var(--n-merged-size);
        color: #FFF;
        font-size: var(--n-font-size);
        display: inline-flex;
        position: relative;
        overflow: hidden;
        text-align: center;
        border: var(--n-border);
        border-radius: var(--n-border-radius);
        --n-merged-color: var(--n-color);
        background-color: var(--n-merged-color);
        transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
        height: 100%;" class="" loading="eager" src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1="" data-image-src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1=""><!----></span><p style="margin-top: 10px;"><span class="" style="color: white;"> Hi,'.$sfyjdl.'&nbsp;<span data-v-bf40dc81="" class="bg-yellow-200 text-yellow-900 py-0.5 px-1.5 text-xs md:text-sm rounded-md uppercase qdwz" style="text-transform: uppercase; font-size: 0.275rem; line-height: 1.25rem; --un-bg-opacity:1; background-color: rgba(254,240,138,var(--un-bg-opacity)); --un-text-opacity:1; color: rgba(113,63,18,var(--un-text-opacity)); padding: 0.125rem 0.375rem; border-radius: 0.375rem;"> 已签到 </span></span></p></div>';
        }else{
            echo '<div class="p-4 weiqiandao" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
        height: var(--n-merged-size);
        color: #FFF;
        font-size: var(--n-font-size);
        display: inline-flex;
        position: relative;
        overflow: hidden;
        text-align: center;
        border: var(--n-border);
        border-radius: var(--n-border-radius);
        --n-merged-color: var(--n-color);
        background-color: var(--n-merged-color);
        transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
        height: 100%;" class="" loading="eager" src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1="" data-image-src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1=""><!----></span><p style="margin-top: 10px;"><span class="" style="color: white;"> Hi,'.$sfyjdl.'&nbsp;<span data-v-bf40dc81="" class="bg-yellow-200 text-yellow-900 py-0.5 px-1.5 text-xs md:text-sm rounded-md uppercase qdwz" style="text-transform: uppercase; font-size: 0.275rem; line-height: 1.25rem; --un-bg-opacity:1; background-color: rgba(254,240,138,var(--un-bg-opacity)); --un-text-opacity:1; color: rgba(113,63,18,var(--un-text-opacity)); padding: 0.125rem 0.375rem; border-radius: 0.375rem;"> 未签到 </span></span></p></div>';
        }
    }
    
}else{
    echo '<div class="p-4 dlzc" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
    height: var(--n-merged-size);
    color: #FFF;
    font-size: var(--n-font-size);
    display: inline-flex;
    position: relative;
    overflow: hidden;
    text-align: center;
    border: var(--n-border);
    border-radius: var(--n-border-radius);
    --n-merged-color: var(--n-color);
    background-color: var(--n-merged-color);
    transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
    height: 100%;" class="dlzc" loading="eager" src="/assets/anonymous.jpg" data-image-src="/assets/anonymous.jpg"><!----></span><p style="margin-top: 10px;"><span class="dlzc" style="color: white;">点击登录</span></p></div>';
}
    
    ?>
               
            
               <div class="talk-add tjxhh"><i class="el-icon-plus all-talk-icon"></i>
                    新会话
                </div>
               
               
               
               <div id="xdh">
                   
        
                   
               </div>
               
 
               
               
            </div>
        </div>
        <div class="left-bottom" style="">
            <ul style="" >
    
            <li class="indextz">
            <i class="fa fa-send" aria-hidden="true" /></i>
                    <a href="index.php"> 回到ChatGPT提问</a>
                </li>

          

         
              <?php

$sfyjdl = $_COOKIE['dengluname'];
if(!empty(uacc())){
    
    
    if($shihuiyuan == '是会员'){
        
          echo '<li  @click.stop="nydl()" class="" style="display: flex;flex-direction: row;position: relative" >
                    <a><i class="el-icon-s-custom"></i> Hi,'.$sfyjdl.'</a>     <span class="" style="background: linear-gradient(to right,#ce9434,#fcb848);
                    font-size: 12px;padding: 1px 2px;border-radius: 4px;margin-left: 10px" >尊贵会员</span>
                    
            <li>
            <a href="index.php?tcdl=1">
                 <i class="el-icon-switch-button"></i> 退出登录</a>
                
                </li>    ';
        
    }else{
          echo '<li  @click.stop="nydl()" class="" style="display: flex;flex-direction: row;position: relative" >
                    <a><i class="el-icon-s-custom"></i> Hi,'.$sfyjdl.'</a>     <span class="" style="background: linear-gradient(to right,#ce9434,#fcb848);
                    font-size: 12px;padding: 1px 2px;border-radius: 4px;margin-left: 10px" >升级会员</span>
                    
            <li>
             <a href="index.php?tcdl=1">
                 <i class="el-icon-switch-button"></i> 退出登录</a>
                
                </li>    ';
    }
    

}else{
    echo '  <li  @click.stop="loginOut()" class="dlzc" style="display: flex;flex-direction: row;position: relative" >
                    <a><i class="el-icon-s-custom"></i> 登录or注册</a>     <span class="dlzc" style="background: linear-gradient(to right,#ce9434,#fcb848);
                    font-size: 12px;padding: 1px 2px;border-radius: 4px;margin-left: 10px" >升级会员</span>';
}


    ?>
    
                </li>
                
                
                
<!--更多-->            
<?php
include_once('./tool/gengduo.php');
?>             
                




            </ul>
            
            <br><br>
            
        </div>
</div>
    </transition>



<?php


$user_agent = $_SERVER['HTTP_USER_AGENT'];

if (preg_match('/(iPhone|Android|Windows Phone)/i', $user_agent)) { ?>
   

<div style="z-index: 9; margin: 0px 0 0 0; height:100% " class="con-right" id="con-right" :style="'width: '+con_w+'px;left:'+left_w+'px;'" >
    
    
   <?php } else { ?>

<div style="z-index: 9; margin: 0px 0 0 0; height:100% " class="con-right" id="con-right" :style="'width: '+con_w+'px;left:'+left_w+'px;'" >
    

   <?php } ?> 



<?php

$sql = "select * from chat_wenzhang order by id desc";
$all = $mysql->getAll($sql);



if(empty($all)){
    echo '没有发布文章';
}


foreach ($all as $value) {

// print_r($value['wenzhangneirong']);

?>
  
  
  <div style=" position: relative;   border-radius: 5px;
    box-shadow: 0 0 5px #ccc;
    background-color: #fff;
    margin-bottom: 20px;
    padding: 20px 20px;    margin: 30px auto;
    width: 80%;
    background: rgb(255 255 255);" class="wzfbcl">
            
            
           <h1 style="    font-size: 18px;
    height: 40px;
    line-height: 40px;
    font-weight: 600;
    word-break: keep-all;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;"><?php echo strip_tags($value['wenzhangbiaoti']);?></h1>
           
           
           <p style="margin: 8px 0 0 0;overflow: hidden;
           
           color:black;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    font-size: 15px;
    line-height: 25px;"><?php echo ($value['wenzhangneirong']);?></p>
           
           
           
  <div style="font-size: 12px;color: rgb(204, 204, 204);float: right;position: absolute;right: 0;bottom: 0;padding: 15px;"></div>
           
        </div>



<?php } ?>



<div class="call-box"></div>

</div>

        <div class="call-box" style="display:;   " :style="'width: '+con_w+'px;left:'+left_w+'px;'" >

        
            <div class="sjdh" v-show="dw<=800" style="width: 100%;height: 60px;background: #474646;position: fixed;left: 0;top: 0;text-align: center;color: #fff;z-index: 100;line-height: 60px;">
        
                Ai Chat机器人   
        
        <div class="jzbb" v-if="left_show" style="width: 100%;height: 100vh;background: rgba(140,147,157,0.46);position: fixed;left: 0;top: 0" @click="left_show=false"></div>
        
        
        <span :class="left_show?'el-icon-s-fold fold-icon left_menu_icon':'el-icon-s-unfold fold-icon left_menu_icon sjdhdj'" :style="left_show?'left:'+lw+'px':'' " @click="left_show = !left_show"></span>

    </div>
        
        
								<input   style="    display:none;
    
             height: 25px;
    padding: 0px 5px;
    font-size: 15px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    border: 1px solid #000;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
    box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
    -webkit-transition: border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;" class="" type="text"  placeholder="sk-xxxxxxxxxx" maxlength="100" id="key" value="<?php echo $_COOKIE['key'];?>" style="    background-color: rgb(234, 235, 241);min-width:200px;max-width:280px">




		</div>

</div>
    


<?php
include_once('./tool/loginlist.php');
?>
<div style="display: none;" class="zuiwaimt"></div>



<div class="loading-wrap">
	<div class="balls">
			<div></div>
			<div></div>
			<div></div>
	</div>
</div>





</body>

<style>

.wzfbcl h1, h2, h3, h4, h5, h6, small {
    font-size: revert!important;
}

.wzfbcl ul li {
    list-style: disc!important;
}

.wzfbcl ol li{
    list-style: unset!important;
}

.wzfbcl img{
        margin: 10px 0px 10px 0px;
}

.wzfbcl p{
        margin: 10px 0px 10px 0px;
}

.wzfbcl hr{
 margin: 10px 0px 10px 0px;
}
 .wzfbcl p{
          color:black;
      }
      
      
  .wzfbcl img{
      width: 50%;
  }     
      
      
    .form-control{
            height: unset!important;
            -webkit-box-shadow:unset!important;
    }
    

    .con-right{
        position: relative;
    }
    
    .jzbb{
        background: white;
    }
    
    
    .containersrk{
        position: relative;
    }
    
    @media (min-width: 640px){
        .sjdh{
            display: none;
        }
 
    }
    
.dtsrk {
      padding: 0.7rem 0.5rem;
    line-height: 1.3 !important;
}
</style>

<script>

$(function() {
    setTimeout(function() {
if (!(isMobile())) {
  $(".con-right").css("top", '0px');
  

   
}else{
     $(".con-right").css("height", '90%');
    
    
    
}
  }, 1);

});
</script>  
<script src="/assets/bootstrap.min.js?id=<?php echo $banbenhao;?>"></script>
<script>
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="xiazatp"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl);
    })
</script> 
<script src="/assets/lm.js?id=<?php echo $banbenhao;?>">"></script>
<script src="/zidingyi.js?id=<?php echo $banbenhao;?>"></script>
<script src="js/remarkable.js?id=<?php echo $banbenhao;?>"></script>
<script src="js/jquery.min.js?id=<?php echo $banbenhao;?>"></script>
<script src="js/jquery.cookie.min.js?id=<?php echo $banbenhao;?>"></script>
<script src="js/layer.min.js" type="application/javascript"></script>
<script src="js/chat.js?id=<?php echo $banbenhao;?>"></script>
<script src="js/highlight.min.js?id=<?php echo $banbenhao;?>"></script>
<script src="js/showdown.min.js?id=<?php echo $banbenhao;?>"></script>

<script>
    $(window).on('load', function() {
       $('.zbsc').css('display','unset');
       $('.loading-wrap').css('display','none');
       
       
    });
</script>


<?php
include_once('./tool/tongji.php');
?>
</html>
<?php include_once('./tool/getend.php');?>