<?php
$sql = "select huihuahtml from chat_admin where id = 1";
$ggnr = $mysql->getOne($sql);
if($ggnr == ''){
    echo '<div class="content" style="margin: 0px auto;">
	<h4 onclick="resetHeight()" class="title syh4" style="">Midjourney绘图<span class="syplus"> Plus </span>
	</h4>
	<br>
	<br>
	<div style="width: 100%;">
<div class="info-box el-col el-col-24 el-col-xs-24 el-col-sm-24 el-col-md-8">
	<i class="el-icon-chat-dot-square" style="font-size: 24px; color: rgb(102, 102, 102);"></i>
	<span class="in-t">使用示例</span>
	<ul>
		<li>“Color mania, facial enhancement, beautiful girl, anime, pink hair, top lighting, cloud, castle, lovely face, girl, double horse tail, dusk”</li>
		<li>“Top-notch lighting, wonderland, clouds, flying birds, boy, young man, cute face”</li>
		<li>“Portrait of a super cute bunny, a carrot, pixar, zootopia, cgi, blade runner. trending on artstation”</li>
	</ul>
</div>
<div class="info-box el-col el-col-24 el-col-xs-24 el-col-sm-24 el-col-md-8">
	<i class="el-icon-cpu" style="font-size: 24px; color: rgb(102, 102, 102);"></i>
	<span class="in-t">能力</span>
	<ul>
		<li>超强Ai绘图模型 对接市面上最顶配的Midjourney绘图 使用对话模式绘画</li>
		<li>对话框可保存上次绘画生成的图片</li>
		<li>输入关键词可设置绘图风格类型</li>
	</ul>
</div>
<div class="info-box el-col el-col-24 el-col-xs-24 el-col-sm-24 el-col-md-8">
	<i class="el-icon-warning-outline" style="font-size: 24px; color: rgb(102, 102, 102);"></i>
	<span class="in-t">局限性</span>
	<ul>
		<li>关键词如果太少 效果可能会不太理想 建议输入10个关键词以上 总之越详细越多越好</li>
		<li>绘图暂时不支持连续对话修正</li>
		<li>绘图后的图片外链不可永久保存 自行存入本地 由于图片质量非常高 加载速度稍慢</li>
	</ul>
</div>';
}else{
    print_r($ggnr);
}
?>

