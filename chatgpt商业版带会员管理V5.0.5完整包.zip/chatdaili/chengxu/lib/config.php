<?php 

//配置数据库信息
$cfg = array(
'host' => 'localhost',
'user' => 'chatgpt', //数据库用户名
'pwd' => 'chatgpt',  //密码
'db' => 'chatgpt',  //数据库名
'charset' => 'utf8', 
'salt'=>'L&#7sd":Adfqef]', 
'zf'=>'wuxinyue'
);

return $cfg;


?>