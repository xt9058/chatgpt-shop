

<div>
    
<div class="gengduolb yincang" style="position: absolute; bottom: 60px; background-color: rgb(5, 5, 9); left: 0px; right: 0px; border-radius: 5px; transition: all 0.3s cubic-bezier(0.075, 0.82, 0.165, 1) 0s; overflow: hidden; z-index: 20; width: 92%; margin: 15px auto;">
    
    
    
<div class="additional-item-box guanyubenzhan" style="display: flex; transition: all 0.3s ease 0s; justify-content: flex-start; padding: 12px 19px; cursor: pointer; width: 100%; border-radius: 3px;" data-bs-toggle="modal" data-bs-target="#myModalgg">

<div class="animate__animated animate__infinite animate__pulse" style="margin-right: 11px; animation-name: pulse; animation-timing-function: ease-in-out; animation-duration: 1s; animation-fill-mode: both; animation-iteration-count: infinite;">
    
     <i style="color:white;" class="fa fa-hashtag" aria-hidden="true" /></i> 
     
</div>

<div style="color: white;">关于</div>

    
</div>    
    
    

       
    <div class="additional-item-box mianzesm" style="display: flex; transition: all 0.3s ease 0s; justify-content: flex-start; padding: 12px 19px; cursor: pointer; width: 100%; border-radius: 3px;">

<div class="animate__animated animate__infinite animate__pulse" style="margin-right: 11px; animation-name: pulse; animation-timing-function: ease-in-out; animation-duration: 1s; animation-fill-mode: both; animation-iteration-count: infinite;">
    
     <i style="color:white;" class="fa fa-hashtag" aria-hidden="true" /></i> 
     
</div>

<div style="color: white;">免责声明</div>

    
</div>    
    
    
    
    
        <div class="additional-item-box wzztz" style="display: flex; transition: all 0.3s ease 0s; justify-content: flex-start; padding: 12px 19px; cursor: pointer; width: 100%; border-radius: 3px;">

<div class="animate__animated animate__infinite animate__pulse" style="margin-right: 14px; animation-name: pulse; animation-timing-function: ease-in-out; animation-duration: 1s; animation-fill-mode: both; animation-iteration-count: infinite;">
    
     <i style="color:white;" class="fa fa-inbox" aria-hidden="true" /></i> 
     
</div>

<div style="color: white;">文章资讯</div>

    
</div>    
    

    
    
    
    <div class="additional-item-box fankuijy" style="display: flex; transition: all 0.3s ease 0s; justify-content: flex-start; padding: 12px 19px; cursor: pointer; width: 100%; border-radius: 3px;">


<div class="animate__animated animate__infinite animate__pulse" style="margin-right: 12px; animation-name: pulse; animation-timing-function: ease-in-out; animation-duration: 1s; animation-fill-mode: both; animation-iteration-count: infinite;">
    
     <i style="color:white;" class="fa fa-envira" aria-hidden="true" /></i> 
     
</div>

<div style="color: white;">反馈建议</div>

    
</div>



    <div class="additional-item-box zmkjjc" style="display: flex; transition: all 0.3s ease 0s; justify-content: flex-start; padding: 12px 19px; cursor: pointer; width: 100%; border-radius: 3px;">


<div class="animate__animated animate__infinite animate__pulse" style="margin-right: 12px; animation-name: pulse; animation-timing-function: ease-in-out; animation-duration: 1s; animation-fill-mode: both; animation-iteration-count: infinite;">
    
    <i style="    color: white;" class="fa fa-save"></i>
     
</div>

<div style="color: white;">桌面快捷教程</div>

    
</div>






    
    
    
    <input id="import-file" tabindex="-1" type="file" accept=".json" class="sr-only"></div> 
    
    
<div style="height: 1px;width: 110%;background-color: rgba(255, 255, 255, 0.2);--tw-space-y-reverse:0;margin: 6px 0px 0px -13px;"></div>
    
    <div class="gengduodj" style="position: relative; color: white; padding: 0px 7px; height: 25px;"><div class="user-info-box no-login" style="padding: 17px 13px; cursor: pointer; width: 100%; line-height: 23px; text-align: center; border-radius: 3px; display: flex; justify-content: space-between; --tw-space-y-reverse:0; margin-top: calc(0.25rem * calc(1 - var(--tw-space-y-reverse))); margin-bottom: calc(0.25rem * var(--tw-space-y-reverse));"><div>
    
<i style="vertical-align: middle;font-size: 15px;margin-right: 10px;display: inline-block;width: 1em;height: 1em;fill: currentcolor;position: relative;top: -1px;    margin-right: 12px;
    width: 12px;" class="fa fa-chain" aria-hidden="true" /></i> 更多功能</div> 

<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="tabler-icon tabler-icon-dots" style="display: block; vertical-align: middle;"><path d="M5 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"></path><path d="M12 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"></path><path d="M19 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"></path></svg></div></div></div>         
                
