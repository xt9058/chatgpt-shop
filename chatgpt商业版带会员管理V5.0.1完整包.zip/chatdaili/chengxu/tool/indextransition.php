<div  class="con-left" v-show="left_show||dw>800" style="height: 100%; 
    
    
  top: 0;
  bottom: 0;
  
  background-color: #fff;
  z-index: 999;">
        <div style="padding: 10px;position: relative;flex: 1;overflow: auto">
            <div style="display: flex;flex-direction: column">
                
    <?php
    
$sfyjdl = $_COOKIE['dengluname'];
if(!empty(uacc())){
    
    
    if($gpt35qd == '0'){
        if($shihuiyuan == '是会员'){
            echo '<div class="p-4 gmtc2" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
        height: var(--n-merged-size);
        color: #FFF;
        font-size: var(--n-font-size);
        display: inline-flex;
        position: relative;
        overflow: hidden;
        text-align: center;
        border: var(--n-border);
        border-radius: var(--n-border-radius);
        --n-merged-color: var(--n-color);
        background-color: var(--n-merged-color);
        transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
        height: 100%;" class="" loading="eager" src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1="" data-image-src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1=""><!----></span><p style="margin-top: 10px;"><span class="" style="color: white;"> Hi,'.$sfyjdl.'&nbsp;<span data-v-bf40dc81="" class="bg-yellow-200 text-yellow-900 py-0.5 px-1.5 text-xs md:text-sm rounded-md uppercase" style="text-transform: uppercase; font-size: 0.275rem; line-height: 1.25rem; --un-bg-opacity:1; background-color: rgba(254,240,138,var(--un-bg-opacity)); --un-text-opacity:1; color: rgba(113,63,18,var(--un-text-opacity)); padding: 0.125rem 0.375rem; border-radius: 0.375rem;"> 尊贵会员 </span></span></p></div>';
    
        
        }else{
            echo '<div class="p-4 gmtc2" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
        height: var(--n-merged-size);
        color: #FFF;
        font-size: var(--n-font-size);
        display: inline-flex;
        position: relative;
        overflow: hidden;
        text-align: center;
        border: var(--n-border);
        border-radius: var(--n-border-radius);
        --n-merged-color: var(--n-color);
        background-color: var(--n-merged-color);
        transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
        height: 100%;" class="" loading="eager" src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1="" data-image-src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1=""><!----></span><p style="margin-top: 10px;"><span class="" style="color: white;"> Hi,'.$sfyjdl.'&nbsp;<span data-v-bf40dc81="" class="bg-yellow-200 text-yellow-900 py-0.5 px-1.5 text-xs md:text-sm rounded-md uppercase" style="text-transform: uppercase; font-size: 0.275rem; line-height: 1.25rem; --un-bg-opacity:1; background-color: rgba(254,240,138,var(--un-bg-opacity)); --un-text-opacity:1; color: rgba(113,63,18,var(--un-text-opacity)); padding: 0.125rem 0.375rem; border-radius: 0.375rem;"> 升级会员 </span></span></p></div>';
        }
    }else{
        
        
        if($orqiandao == '已签到'){
            echo '<div class="p-4 weiqiandao" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
        height: var(--n-merged-size);
        color: #FFF;
        font-size: var(--n-font-size);
        display: inline-flex;
        position: relative;
        overflow: hidden;
        text-align: center;
        border: var(--n-border);
        border-radius: var(--n-border-radius);
        --n-merged-color: var(--n-color);
        background-color: var(--n-merged-color);
        transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
        height: 100%;" class="" loading="eager" src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1="" data-image-src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1=""><!----></span><p style="margin-top: 10px;"><span class="" style="color: white;"> Hi,'.$sfyjdl.'&nbsp;<span data-v-bf40dc81="" class="bg-yellow-200 text-yellow-900 py-0.5 px-1.5 text-xs md:text-sm rounded-md uppercase qdwz" style="text-transform: uppercase; font-size: 0.275rem; line-height: 1.25rem; --un-bg-opacity:1; background-color: rgba(254,240,138,var(--un-bg-opacity)); --un-text-opacity:1; color: rgba(113,63,18,var(--un-text-opacity)); padding: 0.125rem 0.375rem; border-radius: 0.375rem;"> 已签到 </span></span></p></div>';
        }else{
            echo '<div class="p-4 weiqiandao" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
        height: var(--n-merged-size);
        color: #FFF;
        font-size: var(--n-font-size);
        display: inline-flex;
        position: relative;
        overflow: hidden;
        text-align: center;
        border: var(--n-border);
        border-radius: var(--n-border-radius);
        --n-merged-color: var(--n-color);
        background-color: var(--n-merged-color);
        transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
        height: 100%;" class="" loading="eager" src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1="" data-image-src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1=""><!----></span><p style="margin-top: 10px;"><span class="" style="color: white;"> Hi,'.$sfyjdl.'&nbsp;<span data-v-bf40dc81="" class="bg-yellow-200 text-yellow-900 py-0.5 px-1.5 text-xs md:text-sm rounded-md uppercase qdwz" style="text-transform: uppercase; font-size: 0.275rem; line-height: 1.25rem; --un-bg-opacity:1; background-color: rgba(254,240,138,var(--un-bg-opacity)); --un-text-opacity:1; color: rgba(113,63,18,var(--un-text-opacity)); padding: 0.125rem 0.375rem; border-radius: 0.375rem;"> 未签到 </span></span></p></div>';
        }
    }
    
}else{
    echo '<div class="p-4 dlzc" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
    height: var(--n-merged-size);
    color: #FFF;
    font-size: var(--n-font-size);
    display: inline-flex;
    position: relative;
    overflow: hidden;
    text-align: center;
    border: var(--n-border);
    border-radius: var(--n-border-radius);
    --n-merged-color: var(--n-color);
    background-color: var(--n-merged-color);
    transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
    height: 100%;" class="dlzc" loading="eager" src="/assets/anonymous.jpg" data-image-src="/assets/anonymous.jpg"><!----></span><p style="margin-top: 10px;"><span class="dlzc" style="color: white;">点击登录</span></p></div>';
}
    
    ?>
               
               <div class="talk-add tjxhh"><i class="el-icon-plus all-talk-icon"></i>
                    新会话
                </div>
               
               
               
               <div id="xdh">
                   
        
                   
               </div>
               
 
               
               
            </div>
        </div>
        <div class="left-bottom" style="">
            <ul style="" >
    

          <?php
          
          $sql = "select sfkqaihh from chat_admin where id = 1";
$sfkqaihh = $mysql->getOne($sql);
         if($sfkqaihh == '开启'){
             echo ' <li class="huitutz">
                  <i class="fa fa-image" aria-hidden="true" /></i> 超强Ai绘图模式
                </li>';
         } 
          
          ?>
          
          
          <?php
if($jsbykq == '开启'){
    echo '<li class="juspyms">
                 <i class="fa fa-mortar-board" aria-hidden="true" /></i> 进入Prompt角色扮演
                </li>';
}
?>

 
    <?php
    
    $sql = "select sfkqkf from chat_admin where id = 1";
$sfkqkf = $mysql->getOne($sql);
    if($sfkqkf == '开启'){
        echo '<li class="lxkfyx">
    <i class="fa fa-wechat" aria-hidden="true" /></i> 联系客服
                </li>';
    }
    
    ?>
    
                    <?php

$sfyjdl = $_COOKIE['dengluname'];
if(!empty(uacc())){
    
    echo '
								
						<li class="cxsycs">
              <i class="el-icon-search"></i> 查询剩余次数
                </li>';
                
                
                if($sfkqyhyqgn == '开启'){
                    	echo	 ' <li class="dwyqhy">
              
<i class="fa fa-share-alt" aria-hidden="true" /></i> 邀请好友<span style="background: linear-gradient(to right, rgb(255, 0, 255), rgb(106, 90, 205)); font-size: 12px; padding: 2px; border-radius: 5px; margin-left: 10px;">赚佣金！</span>
                </li>	
                ';
                }
                
                
				
    
}else{
    
     if($sfkqyhyqgn == '开启'){
             echo '  <li class="dlzc">
              
<i class="fa fa-share-alt" aria-hidden="true" /></i> 邀请好友<span style="background: linear-gradient(to right, rgb(255, 0, 255), rgb(106, 90, 205)); font-size: 12px; padding: 2px; border-radius: 5px; margin-left: 10px;">赚佣金！</span>
                </li>';
         
     }
    
}


?>
     

                <?php
                
                
                if($ansems){
                    echo '         <li class="anhms">
             <i class="fa fa-moon-o"></i> 白天模式
           
                    
                </li>';
                }else{
                     echo '         <li class="anhms">
            <i class="fa fa-sun-o" aria-hidden="true" /></i> 暗黑模式
           
                    
                </li>';
                }
     
                
                ?>

                
              <?php

$sfyjdl = $_COOKIE['dengluname'];
if(!empty(uacc())){
    
    
    if($shihuiyuan == '是会员'){
        
          echo '<li  @click.stop="nydl()" class="" style="display: flex;flex-direction: row;position: relative" >
                    <a><i class="el-icon-s-custom"></i> Hi,'.$sfyjdl.'</a>';
                    
                  
                  
                   
                    
                      if($adminall['sfsf'] == '开启'){
                     echo     ' <span class="" style="background: linear-gradient(to right,#ce9434,#fcb848);
                    font-size: 12px;padding: 1px 2px;border-radius: 4px;margin-left: 10px" >尊贵会员</span>';
                }    
                 
                    
                    
                    
         echo   '<li>
            <a href="index.php?tcdl=gpt3">
                 <i class="el-icon-switch-button"></i> 退出登录</a>
                
                </li>    ';
        
    }else{
          echo '<li  @click.stop="nydl()" class="" style="display: flex;flex-direction: row;position: relative" >
                    <a><i class="el-icon-s-custom"></i> Hi,'.$sfyjdl.'</a>';
                    
                if($adminall['sfsf'] == '开启'){
                     echo     '<span class="" style="background: linear-gradient(to right,#ce9434,#fcb848);
                    font-size: 12px;padding: 1px 2px;border-radius: 4px;margin-left: 10px" >升级会员</span>';
                }    
                
                    
           echo '<li>
             <a href="index.php?tcdl=gpt3">
                 <i class="el-icon-switch-button"></i> 退出登录</a>
                
                </li>    ';
    }
    

}else{
    echo '  <li  @click.stop="loginOut()" class="dlzc" style="display: flex;flex-direction: row;position: relative" >
                    <a><i class="el-icon-s-custom"></i> 登录or注册</a>';
                    
                    
                    
                             if($adminall['sfsf'] == '开启'){
                     echo     ' <span class="dlzc" style="background: linear-gradient(to right,#ce9434,#fcb848);
                    font-size: 12px;padding: 1px 2px;border-radius: 4px;margin-left: 10px" >升级会员</span>';
                }    
                    
                    
}


    ?>
    
                </li>
                
                
                
<!--更多-->            
<?php
include_once('./tool/gengduo.php');
?>             
                




            </ul>
            
            <br><br>
            
        </div>
</div>