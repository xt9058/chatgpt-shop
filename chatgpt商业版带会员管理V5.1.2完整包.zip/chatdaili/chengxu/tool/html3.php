<?php

echo '<button style=" position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    
        z-index: 999999999999999999999;
        
        border: none;
        background-color: #FF5722;
        color: #fff;
        font-size: 16px;
        cursor: pointer;" type="button" class="btn btn-primary gmtc" data-bs-toggle="modal" data-bs-target="#exampleModal">
    		😊你已登录 你的会员已到期 👉点我重新购买
    	</button>';
    	    echo '<div style="top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: #000;
    opacity: 0.9;
    z-index: 9998;
    position: fixed;" class="close-btngb"></div>
    
     <div style="  position: fixed;
  top: 20px;
  right: 20px;
  width: 30px;
  height: 30px;
  border-radius: 50%;
  background-color: #333;
  color: #fff;
  font-size: 24px;
  text-align: center;
     line-height: 25px;
  cursor: pointer;
  z-index: 9999;" class="close-btngb">&times;</div>
  
     
    
';