<!-- 关于 -->
<div id="myModalgg" class="modal fade in">
    <div class="modal-dialog">
      <div class="modal-content" style="width: 100%;">
        <div class="modal-header">
          <h5 class="modal-title">关于</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" style="text-align: unset;">
          <p><?php echo $adminall['guanyu'];?></p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">关闭</button>
        </div>
      </div>
    </div>
  </div>

