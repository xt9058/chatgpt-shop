<?php include_once('./tool/get.php');?>
<?php
require('./gpt4code.php');
if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
    $ip = $_SERVER["HTTP_CF_CONNECTING_IP"];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
$expiration = time() + (30 * 24 * 60 * 60); 
setcookie("yhip", $ip, $expiration, "/");
require('./tool/coo.php');
require('./tool/pu.php');
if(($sfvip != '') || ($time2 < $time1)){
    $shihuiyuan = '是会员';
}
if($nsfkqgpt4 != '开启'){
    setcookie("gpt4", '0', $expiration, "/");  
    echo "<script>window.location.href='index.php';</script>";
    exit();
}else{
    if(empty($_COOKIE['gpt4'])){
        echo "<script>window.location.href='index.php';</script>";
        exit();
    }
}
$banbenhao = file_get_contents($banbenhlj.'admin/banben.php');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="google" content="notranslate">
    <title><?php echo $wzmc;?></title>
    <meta name="description" content="<?php echo $wzms;?>">
    
<script type="text/javascript" src="/jquery.js?id=<?php echo $banbenhao;?>"></script>
<script src="/assets/jquery.cookie.min.js?id=<?php echo $banbenhao;?>"></script>          
<div id="cssah"></div>
<div id="cssah2"></div>
<script src="/assets/anse.js?id=<?php echo $banbenhao;?>"></script>    
<style>
</style>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="/css/index.css?id=<?php echo $banbenhao;?>">
    <script src="/assets/vue@2.62.js?id=<?php echo $banbenhao;?>"></script>
    <!--<script src="/assets/index.js"></script>-->
    <link rel="stylesheet" href="/assets/css.css?id=<?php echo $banbenhao;?>">
    <link href="/assets/bootstrap.min.css?id=<?php echo $banbenhao;?>" rel="stylesheet">
	<link rel="stylesheet" href="/css/common.css?id=<?php echo $banbenhao;?>">
	<link rel="stylesheet" href="/css/wenda.css?id=<?php echo $banbenhao;?>">
	<link rel="stylesheet" href="/css/hightlight.css?id=<?php echo $banbenhao;?>">
	<link rel="stylesheet" href="/zidingyi.css?id=<?php echo $banbenhao;?>">
	<link href="/assets/font-awesome/css/font-awesome.min.css?id=<?php echo $banbenhao;?>" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="/assets/lm.css?id=<?php echo $banbenhao;?>">
    <link rel="stylesheet" href="/css/css/jiazai.css?id=<?php echo $banbenhao;?>">
    <link rel="stylesheet" href="/css/css/youhua.css?id=<?php echo $banbenhao;?>">
</head>
<?php
require('./tool/head.php');
?>
<body style="background: white;">
    
<div id="moxicon" class="zbsc" style="display:none;">

    
    <transition name="el-zoom-in-center">
    
    
<div  class="con-left" v-show="left_show||dw>800" style="height: 100%; 
    
    
    
  top: 0;
  bottom: 0;
  
  background-color: #fff;
  z-index: 999;">
        <div style="padding: 10px;position: relative;flex: 1;overflow: auto">
            <div style="display: flex;flex-direction: column">
            
               
               
    
    
    <?php
    
$sfyjdl = $_COOKIE['dengluname'];
if(!empty(uacc())){
    
    
    
    
    if($shihuiyuan == '是会员'){
        echo '<div class="p-4 gmtc2" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
    height: var(--n-merged-size);
    color: #FFF;
    font-size: var(--n-font-size);
    display: inline-flex;
    position: relative;
    overflow: hidden;
    text-align: center;
    border: var(--n-border);
    border-radius: var(--n-border-radius);
    --n-merged-color: var(--n-color);
    background-color: var(--n-merged-color);
    transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
    height: 100%;" class="" loading="eager" src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1="" data-image-src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1=""><!----></span><p style="margin-top: 10px;"><span class="" style="color: white;">Hi,'.$sfyjdl.'&nbsp;<span data-v-bf40dc81="" class="bg-yellow-200 text-yellow-900 py-0.5 px-1.5 text-xs md:text-sm rounded-md uppercase" style="text-transform: uppercase; font-size: 0.275rem; line-height: 1.25rem; --un-bg-opacity:1; background-color: rgba(254,240,138,var(--un-bg-opacity)); --un-text-opacity:1; color: rgba(113,63,18,var(--un-text-opacity)); padding: 0.125rem 0.375rem; border-radius: 0.375rem;"> 尊贵会员 </span></span></p></div>';
    }else{
        echo '<div class="p-4 gmtc2" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
    height: var(--n-merged-size);
    color: #FFF;
    font-size: var(--n-font-size);
    display: inline-flex;
    position: relative;
    overflow: hidden;
    text-align: center;
    border: var(--n-border);
    border-radius: var(--n-border-radius);
    --n-merged-color: var(--n-color);
    background-color: var(--n-merged-color);
    transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
    height: 100%;" class="" loading="eager" src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1="" data-image-src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1=""><!----></span><p style="margin-top: 10px;"><span class="" style="color: white;">Hi,'.$sfyjdl.'&nbsp;<span data-v-bf40dc81="" class="bg-yellow-200 text-yellow-900 py-0.5 px-1.5 text-xs md:text-sm rounded-md uppercase" style="text-transform: uppercase; font-size: 0.275rem; line-height: 1.25rem; --un-bg-opacity:1; background-color: rgba(254,240,138,var(--un-bg-opacity)); --un-text-opacity:1; color: rgba(113,63,18,var(--un-text-opacity)); padding: 0.125rem 0.375rem; border-radius: 0.375rem;"> 升级会员 </span></span></p></div>';
    }
    
    
    
    
    
    
}else{
    echo '<div class="p-4 dlzc" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
    height: var(--n-merged-size);
    color: #FFF;
    font-size: var(--n-font-size);
    display: inline-flex;
    position: relative;
    overflow: hidden;
    text-align: center;
    border: var(--n-border);
    border-radius: var(--n-border-radius);
    --n-merged-color: var(--n-color);
    background-color: var(--n-merged-color);
    transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
    height: 100%;" class="dlzc" loading="eager" src="/assets/anonymous.jpg" data-image-src="/assets/anonymous.jpg"><!----></span><p style="margin-top: 10px;"><span class="dlzc" style="color: white;">点击登录</span></p></div>';
}
    
    
    
    ?>
    
    <!--<a href="" target="_blank" style="background-color: green; color: white; padding: 5px; border-radius: 5px; text-align: center;">切换ChatGPT4.0</a>-->
          
   
               <div class="talk-add tjxhh"><i class="el-icon-plus all-talk-icon"></i>
                    新会话
                </div>
               
               
               
               <div id="xdh">
                   
        
                   
               </div>

               
            </div>
        </div>
        <div class="left-bottom" style="">
            <ul style="" >
       
          
          
          <?php
          
          $sql = "select sfkqaihh from chat_admin where id = 1";
$sfkqaihh = $mysql->getOne($sql);
         if($sfkqaihh == '开启'){
             echo ' <li class="huitutz">
                  <i class="fa fa-image" aria-hidden="true" /></i> 超强Ai绘图模式
                </li>';
         } 
          
          ?>

    <?php
    if($jsbykq == '开启'){
        echo '<li class="juspyms">
                 <i class="fa fa-mortar-board" aria-hidden="true" /></i> 进入Prompt角色扮演
                </li>';
    }
    
    ?>
    
    <?php
    
    $sql = "select sfkqkf from chat_admin where id = 1";
$sfkqkf = $mysql->getOne($sql);
    if($sfkqkf == '开启'){
        echo '<li class="lxkfyx">
    <i class="fa fa-wechat" aria-hidden="true" /></i> 联系客服
                </li>';
    }
    
    ?>
    
    
               

          
          
          
          
                    <?php

$sfyjdl = $_COOKIE['dengluname'];
if(!empty(uacc())){
    
    echo '
								
						<li class="cxsycs">
              <i class="el-icon-search"></i> 查询剩余次数
                </li>';
						
						
						
		if($sfkqyhyqgn == '开启'){
		    		echo  '<li class="dwyqhy"><i class="fa fa-share-alt" aria-hidden="true" /></i> 邀请好友<span style="background: linear-gradient(to right, rgb(255, 0, 255), rgb(106, 90, 205)); font-size: 12px; padding: 2px; border-radius: 5px; margin-left: 10px;">赚佣金！</span>
                </li>		';
		}				
						
						

    
}else{
    
    if($sfkqyhyqgn == '开启'){
        
          echo '  <li class="dlzc"><i class="fa fa-share-alt" aria-hidden="true" /></i> 邀请好友<span style="background: linear-gradient(to right, rgb(255, 0, 255), rgb(106, 90, 205)); font-size: 12px; padding: 2px; border-radius: 5px; margin-left: 10px;">赚佣金！</span>
                </li>';
    }
  
    
}


?>
     

       
                
                <?php
                
                
                if($ansems){
                    echo '         <li class="anhms">
             <i class="fa fa-moon-o"></i> 白天模式
           
                    
                </li>';
                }else{
                     echo '         <li class="anhms">
            <i class="fa fa-sun-o" aria-hidden="true" /></i> 暗黑模式
           
                    
                </li>';
                }
                
                
                
                ?>

              
    
                
              <?php

$sfyjdl = $_COOKIE['dengluname'];
if(!empty(uacc())){
    
    
    if($shihuiyuan == '是会员'){
        
          echo '<li  @click.stop="nydl()" class="" style="display: flex;flex-direction: row;position: relative" >
                    <a><i class="el-icon-s-custom"></i> Hi,'.$sfyjdl.'</a>     <span class="" style="background: linear-gradient(to right,#ce9434,#fcb848);
                    font-size: 12px;padding: 1px 2px;border-radius: 4px;margin-left: 10px" >尊贵会员</span>
                    
            <li>
                 <a href="gpt4.php?tcdl=gpt4"><i class="el-icon-switch-button"></i> 退出登录</a>
                
                </li>    ';
        
    }else{
          echo '<li  @click.stop="nydl()" class="" style="display: flex;flex-direction: row;position: relative" >
                    <a><i class="el-icon-s-custom"></i> Hi,'.$sfyjdl.'</a>     <span class="" style="background: linear-gradient(to right,#ce9434,#fcb848);
                    font-size: 12px;padding: 1px 2px;border-radius: 4px;margin-left: 10px" >升级会员</span>
                    
            <li>
                <a href="gpt4.php?tcdl=gpt4"> <i class="el-icon-switch-button"></i> 退出登录</a>
                
                </li>    ';
    }
    
    
  
    
    
    
}else{
    echo '  <li  @click.stop="loginOut()" class="dlzc" style="display: flex;flex-direction: row;position: relative" >
                    <a><i class="el-icon-s-custom"></i> 登录or注册</a>     <span class="dlzc" style="background: linear-gradient(to right,#ce9434,#fcb848);
                    font-size: 12px;padding: 1px 2px;border-radius: 4px;margin-left: 10px" >升级会员</span>';
}


    ?>
    
  




                </li>
<!--更多-->            
<?php
include_once('./tool/gengduo.php');
?>             
      

            </ul>
            
            <br><br>
            
        </div>
    </div>

    </transition>


<?php


$user_agent = $_SERVER['HTTP_USER_AGENT'];

if (preg_match('/(iPhone|Android|Windows Phone)/i', $user_agent)) { ?>
   
   
   
<div style="z-index: 9;
    width: 910px;
    left: 250px;
    position: fixed;
    height: unset;
    top: 35%;    height: 200px;" class="con-right" id="con-right" :style="'width: '+con_w+'px;left:'+left_w+'px;'" >
    
    
   <?php } else { ?>

<div style="z-index: 9;
    width: 910px;
    left: 250px;
    position: fixed;
    height: unset;
    top: 35%;    height: 200px;" class="con-right" id="con-right" :style="'width: '+con_w+'px;left:'+left_w+'px;'" >
    
    
    
   <?php } ?> 


    
    
    
    <div class="content" style="margin: 0px auto;"><h4 onclick="resetHeight()" class="title syh4" style="">ChatGPT4.0<span style="text-transform: uppercase;font-size: .875rem;
    line-height: 1.25rem;    --un-bg-opacity: 1;
    background-color: rgba(254,240,138,var(--un-bg-opacity));--un-text-opacity: 1;
    color: rgba(113,63,18,var(--un-text-opacity));    padding-top: .125rem;
    padding-bottom: .125rem;    padding-left: .375rem;
    padding-right: .375rem;border-radius: .375rem;" class="bg-yellow-200 text-yellow-900 py-0.5 px-1.5 text-xs md:text-sm rounded-md uppercase" data-v-bf40dc81=""> Plus </span></h4> 
<br><br>

<div style="width: 100%; display:none;"><div class="info-box el-col el-col-24 el-col-xs-24 el-col-sm-24 el-col-md-8"><i class="el-icon-chat-dot-square" style="font-size: 24px; color: rgb(102, 102, 102);"></i> <span class="in-t">使用示例</span> <ul><li>“用简单的术语解释量子计算”</li> <li>“对于一个10岁的孩子的生日，有什么创意吗”</li> <li>“如何用Javascript发出HTTP请求?”</li></ul></div> <div class="info-box el-col el-col-24 el-col-xs-24 el-col-sm-24 el-col-md-8"><i class="el-icon-cpu" style="font-size: 24px; color: rgb(102, 102, 102);"></i> <span class="in-t">能力</span> <ul><li>记住用户之前在对话中说过的话</li> <li>允许用户提供后续修正</li> <li>接受或拒绝不适当请求的培训</li></ul></div> <div class="info-box el-col el-col-24 el-col-xs-24 el-col-sm-24 el-col-md-8"><i class="el-icon-warning-outline" style="font-size: 24px; color: rgb(102, 102, 102);"></i> <span class="in-t">局限性</span> <ul><li>可能偶尔会产生不正确的信息</li> <li>可能偶尔会产生有害的指令或有偏见的内容</li> <li>对2021年后的世界和事件的了解有限</li></ul></div></div></div> <div class="call-box"></div></div>



        
        <div class="call-box" style="display:;   " :style="'width: '+con_w+'px;left:'+left_w+'px;'" >

        
            <div class="sjdh" v-show="dw<=800" style="width: 100%;height: 60px;background: #474646;position: fixed;left: 0;top: 0;text-align: center;color: #fff;z-index: 100;line-height: 60px;">
        
        ChatGPT   
        
        
        
        <div class="jzbb" v-if="left_show" style="width: 100%;height: 100vh;background: rgba(140,147,157,0.46);position: fixed;left: 0;top: 0" @click="left_show=false"></div>
        
        
        <span :class="left_show?'el-icon-s-fold fold-icon left_menu_icon':'el-icon-s-unfold fold-icon left_menu_icon sjdhdj'" :style="left_show?'left:'+lw+'px':'' " @click="left_show = !left_show"></span>

    </div>
        
        
        
<div name="content-query" >

	<div class="layout-content" style="    background: white; color:white; ">
			<div class="">
				<article class="article" id="article">
					<div class="article-box">
				
				
						<div  style="    display:none;" class="precast-block" data-flex="main:left">
							<div class="input-group">
							
								<!--<span style="text-align: center;color:#9ca2a8">&nbsp;&nbsp;连续对话：</span>-->
								<!--<input  type="checkbox" id="keep"  checked style="min-width:220px;display:none;">-->
								<!--<label for="keep"></label>-->
								
								
								<span style="   display:none; text-align: center;color:#9ca2a8">&nbsp;&nbsp;输入你的APIKEY(输入之后即可使用)：👉</span>
						
		
						
								<input   style="    display:none;
    
             height: 25px;
    padding: 0px 5px;
    font-size: 15px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    border: 1px solid #000;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
    box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
    -webkit-transition: border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;" class="" type="text"  placeholder="sk-xxxxxxxxxx" maxlength="100" id="key" value="<?php echo $_COOKIE['key'];?>" style="    background-color: rgb(234, 235, 241);min-width:200px;max-width:280px">



<?php

$sfyjdl = $_COOKIE['dengluname'];
if(!empty(uacc())){
    
    echo '<div style="" class="right-btn layout-bar">
								    
									<p style="    width: 100px;
    margin: 0px 0 0 40px;    width: 100px;
    margin-left: 14px;
    text-align: center;
    height: 24px;
    line-height: 24px;
    font-size: 14px;
    border-radius: var(--zhuluan-primary-border-radius);
  
    cursor: pointer;
    transition: all .4s;" class="cxsycs  bright-btn" id=""  data-flex="main:center cross:center"> 查询剩余次数</p>
    

    
								</div>';
    
}


?>




							</div>
						</div>
				


<ul id="article-wrapper" class="ztsc">



</ul>



						
	
						<div class="creating-loading" data-flex="main:center dir:top cross:center">
							<div class="semi-circle-spin"></div>
						</div>
		
					</div>
				</article>
			</div>
		</div>
		
		
				</div>

<div class="containersrk" :style="'width: '+con_w+'px;left:'+left_w+'px;'">
  



  <div class="childsrk">
      <div class="input-containersrk shurk40" style="    position: absolute;
    bottom: 10px;">
          
          


          
        
            
     <?php
     
  
         echo '<button type="button" data-toggle="dropdown" aria-expanded="false" class="btn btn-secondary qhgpt3" style="margin: 0px 10px 0px 0px;background-color: rgb(52 53 65/var(--tw-bg-opacity)) !important;border: 1px solid rgb(140, 147, 157);    background-color: rgb(52, 53, 65) !important;
    border: 1px solid rgb(96, 96, 96) !important;
    border-radius: 4px;">GPT3.5</button>';
     
     
     ?> 
        
         <?php
     if($adminall['sfkqyuyin'] == '1'){
      echo '<i id="record-btn" style="margin: 0 5px 0px 0px;font-size: 20px;" class="fa fa-microphone  lyyintb" aria-hidden="true"></i>';   
     }
     
     ?>
        
          
          
           <textarea oninput="autoHeight(this)" type="text" autocomplete="off" id="kw-target" placeholder="您好，想问点什么？" class="el-input__inner form-controltw dtsrk" rows="1"></textarea>
       
       
        <div class="button-containersrk">
              <span onclick="resetHeight()" style="   " @click.stop="fasong(event)" id="ai-btn" class="fasong ai-btn ">
        <i class="el-tooltip el-icon-s-promotion item" aria-describedby="el-tooltip-6447" tabindex="0" style="color: rgb(167, 161, 161); cursor: pointer;"></i>
      </span> 
        </div>
        
        
        
        <button class="btn-primary gnann" data-bs-toggle="modal" data-bs-target="#myModal" style=" outline: none;justify-content: center;align-items: center;width: 2.5rem;height: 2.5rem;margin: 0px 0px 0px 5px;background-color: rgb(52, 53, 65) !important;border: 1px solid rgb(96, 96, 96) !important;border-radius: 4px;"><span class="text-base text-slate-500 dark:text-slate-400">
    
    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" viewBox="0 0 24 24" class=" iconify iconify–material-symbols" style="top: -2px; position: relative; color: white;"><path fill="currentColor" d="M12 8.6l6 6-1.4 1.4-4.6-4.6-4.6 4.6L6 14.6l6-6Z"></path></svg>
    
    
 
    </span>

</button>
        
        
        
      </div>
      
      

    </div>
    

  
</div>

				
		</div>

</div>
    


<?php
include_once('./tool/loginlist.php');
?>
	

<div style="display: none;" class="zuiwaimt"></div>

<?php
        $sql = "select gglx from chat_admin where id = 1";
        $gglx = $mysql->getOne($sql);
 
 
        $sql = "select gpt4cs from chat_yonghu where yhmc = '$sfyjdl'";
        $gpt4cs = $mysql->getOne($sql);
 
 
        if($gglx == '1'){
            
            if(empty(uacc())){
                echo '<div class="popup" id="note" style="display:none;"> <div class="popup-header" style="margin: 0px 0 40px 0;"> <h3 class="popup-title">同一个世界，同一个梦想</h3> </div> <div class="popup-main">';
                $file = $dangqianlj.'admin/ggnr.php';
                require($file);
                echo '</div> <div class="popup-footer"><span style="padding: unset;" class="popup-btn" onclick="closeclick()">我记住啦</span></div> </div>';
            }
            
      
        }else if($gglx == '2'){
            
            if(!empty(uacc())){
                echo '<div class="popup" id="note" style="display:none;"> <div class="popup-header" style="margin: 0px 0 40px 0;"> <h3 class="popup-title">同一个世界，同一个梦想</h3> </div> <div class="popup-main">';
                 $file = $dangqianlj.'admin/ggnr.php';
                require($file);
                echo '</div> <div class="popup-footer"><span style="padding: unset;" class="popup-btn" onclick="closeclick()">我记住啦</span></div> </div>';
             
            }
            
            
        }else if($gglx == '3'){
            
            if(!empty(uacc())){
                
          
               
                if($gpt4cs != '0'){
                    
                    echo '<div class="popup" id="note" style="display:none;"> <div class="popup-header" style="margin: 0px 0 40px 0;"> <h3 class="popup-title">同一个世界，同一个梦想</h3> </div> <div class="popup-main">';
                    $file = $dangqianlj.'admin/ggnr.php';
                    require($file);
                    echo '</div> <div class="popup-footer"><span style="padding: unset;" class="popup-btn" onclick="closeclick()">我记住啦</span></div> </div>';
       
                     
                     
                }else{
                    
                    if(($sfvip != '') || ($time2 < $time1)){
                        echo '<div class="popup" id="note" style="display:none;"> <div class="popup-header" style="margin: 0px 0 40px 0;"> <h3 class="popup-title">同一个世界，同一个梦想</h3> </div> <div class="popup-main">';
                         $file = $dangqianlj.'admin/ggnr.php';
                        require($file);
                        
                        echo '</div> <div class="popup-footer"><span style="padding: unset;" class="popup-btn" onclick="closeclick()">我记住啦</span></div> </div>';
                           
                    }   
                    
                }
      
            }
            
        }
?>

<!--公告-->

<!--加载-->

    
<!--菜单 -->
   <div class="modal fade in" id="myModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog cdltc">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">菜单功能栏</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body cdlgn">
              
     <button data-bs-toggle="xiazatp" title="导出本页为图片" class="gnann gnanntu" style="border-radius: 4px;outline: none;justify-content: center;align-items: center;width: 2.5rem;height: 2.5rem;margin: 0px 0px 0px 5px;border: 1px solid rgb(255 255 255) !important;"><span class="text-base text-slate-500 dark:text-slate-400">


<i class="fa fa-download" aria-hidden="true" /></i>


</span>

 

</button>
            
            
<button data-bs-toggle="xiazatp" title="导出当前对话为Word文档" class="gnann xiazwd" style="border-radius: 4px;outline: none;justify-content: center;align-items: center;width: 2.5rem;height: 2.5rem;margin: 0px 0px 0px 5px;border: 1px solid rgb(255 255 255) !important;"><span class="text-base text-slate-500 dark:text-slate-400">

</span>


 <i class="fa fa-file-word-o" aria-hidden="true" /></i>

</button>  

<button data-bs-toggle="xiazatp" title="删除所有对话信息" class="gnann scsydhxx" style="border-radius: 4px;outline: none;justify-content: center;align-items: center;width: 2.5rem;height: 2.5rem;margin: 0px 0px 0px 5px;border: 1px solid rgb(255 255 255) !important;"><span class="text-base text-slate-500 dark:text-slate-400">

</span>

<i class="fa fa-trash"></i>
</button>  




            
            
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">关闭</button>
          </div>
        </div>
      </div>
    </div>

    
<div class="loading-wrap">
	<div class="balls">
			<div></div>
			<div></div>
			<div></div>
	</div>
</div>

<!--录音-->
<div id="overlay" class="overlay">

  <div id="recording-indicator" class="card" style="width: 140px;">
    <div class="card-body" style="text-align: center;">
      <h5 style="color: black;text-align: center;" class="card-title"><i id="record-btn" aria-hidden="true" class="fa fa-microphone" style="margin: 0px 5px 0px 0px; font-size: 20px;"></i>实时录音中...</h5>
    
      <button id="stop-btn" class="btn btn-danger">结束</button>
   
        <p class="daojishisss" style="margin: 5px 0 0 0;">60</p>
        
         <p id="fixed-txt" style="margin: 5px 0 0 0;max-height: 100px; overflow: auto;"></p>
        
    </div>
  </div>
</div>




<button style="display:none;"  id="inviteBtn" class="btn btn-primary">邀请好友</button>
<!--邀请-->
<?php
if(!empty($_GET)){
    if($_GET['id'] == '邀请'){
        require_once('./yaoqinghtml.php');
    }
}
?>




<?php
require('./tool/kefu.php');
?>



</body>

<style>

    .form-control{
            height: unset!important;
            -webkit-box-shadow:unset!important;
    }
    

    .con-right{
        position: relative;
    }
    
    .jzbb{
        background: white;
    }
    
    
    .containersrk{
        position: relative;
    }
    
    @media (min-width: 640px){
        .sjdh{
            display: none;
        }
 
    }
    
.dtsrk {
      padding: 0.7rem 0.5rem;
    line-height: 1.3 !important;
}
</style>




<script>
setTimeout(function() {
  $.ajax({
  url: "tool/ip.php",
  type: "POST",
  data:{ip:$.cookie("yhip")},
  success: function(response) {
        console.log(1)
  }
});
}, 200);
$(function() {
    setTimeout(function() {
if (!(isMobile())) {
  $(".con-right").css("height", 'unset');
   
}
  }, 1);

});
</script>  
<script src="/assets/bootstrap.min.js?id=<?php echo $banbenhao;?>"></script>
<script>
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="xiazatp"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl);
    })
</script> 
<script src="/assets/lm.js?id=<?php echo $banbenhao;?>"></script>
<script src="/zidingyi.js?id=<?php echo $banbenhao;?>"></script>
<script src="js/remarkable.js?id=<?php echo $banbenhao;?>"></script>
<script src="js/jquery.min.js?id=<?php echo $banbenhao;?>"></script>
<script src="js/jquery.cookie.min.js?id=<?php echo $banbenhao;?>"></script>
<script src="js/layer.min.js?id=<?php echo $banbenhao;?>" type="application/javascript"></script>
<script src="js/chat.js?id=<?php echo $banbenhao;?>"></script>
<script src="js/highlight.min.js?id=<?php echo $banbenhao;?>"></script>
<script src="js/showdown.min.js?id=<?php echo $banbenhao;?>"></script>

<script>
    $(window).on('load', function() {
       $('.zbsc').css('display','unset');
       $('.loading-wrap').css('display','none');
       
       
    });
</script>


<?php
include_once('./tool/tongji.php');
?>

</html>
<?php include_once('./tool/getend.php');?>