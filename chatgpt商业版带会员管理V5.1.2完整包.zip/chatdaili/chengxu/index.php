<?php include_once('./tool/get.php');?>
<?php
$filename = './install/install.lock';
if (!file_exists($filename)) {
    echo "<script>window.location.href='./install/index.php';</script>";
    exit();
}
require('./code.php');
if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
    $ip = $_SERVER["HTTP_CF_CONNECTING_IP"];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
$expiration = time() + (30 * 24 * 60 * 60); 
setcookie("yhip", $ip, $expiration, "/");
require('./tool/coo.php');
require('./tool/pu.php');
if(($sfvip != '') || ($time2 < $time1)){
    $shihuiyuan = '是会员';
}
if (version_compare(PHP_VERSION, '7.3.0', '>') && version_compare(PHP_VERSION, '7.4.0', '<')) {
} else {
    echo '当前运行的PHP版本不符合要求 请切换PHP7.3版本';
    exit();
}
if(empty($_COOKIE['gpt4'])){
    setcookie("gpt4", '0', $expiration, "/");  
}
if($nsfkqgpt4 == '开启'){
   if(!empty($_COOKIE['gpt4'])){
        if($_COOKIE['gpt4'] == '1'){
            echo "<script>window.location.href='gpt4.php';</script>";
            exit();
        }
    } 
}else{
   setcookie("gpt4", '0', $expiration, "/");  
}
$banbenhao = file_get_contents($banbenhlj.'admin/banben.php');
?>
<!doctype html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport"
			  content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<meta name="google" content="notranslate">
		<title>
			<?php echo $wzmc;?>
		</title>
		<meta name="description" content="<?php echo $wzms;?>">

		<script type="text/javascript" src="/jquery.js?id=<?php echo $banbenhao;?>"></script>
		<script src="/assets/jquery.cookie.min.js?id=<?php echo $banbenhao;?>"></script>
		<div id="cssah"></div>
		<div id="cssah2"></div>
		<script src="/assets/anse.js?id=<?php echo $banbenhao;?>"></script>
		<style>
		</style>
		<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
		<link rel="stylesheet" href="/css/index.css?id=<?php echo $banbenhao;?>">
		<script src="/assets/vue@2.62.js?id=<?php echo $banbenhao;?>"></script>
		<link rel="stylesheet" href="/assets/css.css?id=<?php echo $banbenhao;?>">
		<link href="/assets/bootstrap.min.css?id=<?php echo $banbenhao;?>" rel="stylesheet">
		<link rel="stylesheet" href="/css/common.css?id=<?php echo $banbenhao;?>">
		<link rel="stylesheet" href="/css/wenda.css?id=<?php echo $banbenhao;?>">
		<link rel="stylesheet" href="/css/hightlight.css?id=<?php echo $banbenhao;?>">
		<link rel="stylesheet" href="/zidingyi.css?id=<?php echo $banbenhao;?>">
		<link href="/assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="/assets/lm.css?id=<?php echo $banbenhao;?>">
		<link rel="stylesheet" href="/css/css/jiazai.css?id=<?php echo $banbenhao;?>">
		<link rel="stylesheet" href="/css/css/youhua.css?id=<?php echo $banbenhao;?>">
	</head>
	<?php
include_once('./tool/head.php');
?>
	<body style="background: white;">

		<div id="moxicon" class="zbsc" style="display:none;">

			<transition name="el-zoom-in-center">


				<?php
include_once('./tool/indextransition.php');
?>
			</transition>

			<?php

$user_agent = $_SERVER['HTTP_USER_AGENT'];

if (preg_match('/(iPhone|Android|Windows Phone)/i', $user_agent)) { ?>


			<div style="z-index: 9;" class="con-right" id="con-right" :style="'width: '+con_w+'px;left:'+left_w+'px;height: '+(dh-70)+'px;'">


				<?php } else { ?>

				<div style="z-index: 9;" class="con-right" id="con-right" :style="'width: '+con_w+'px;left:'+left_w+'px;height: '+(dh-75)+'px;'">


					<?php } ?>
					
					    
					
				    <?php require_once('./admin/gpt3html.php');?>


							<?php
                            if($jsbykq == '开启'){
                                echo '<div style="padding: 10px;margin: 0 auto;text-align: center;color: #acacac;
                                font-size: 11px;"><a style="color: #acacac;" href="./aichat.php?id=角色扮演">点我进入Prompt角色扮演-&gt;</a></div>';
                            }
                            ?>
                            

						</div>

					</div>

					<div class="call-box"></div>
				</div>

				<div class="call-box" style="display:;   " :style="'width: '+con_w+'px;left:'+left_w+'px;'">


					<div class="sjdh" v-show="dw<=800" style="width: 100%;height: 60px;background: #474646;position: fixed;left: 0;top: 0;text-align: center;color: #fff;z-index: 100;line-height: 60px;">

						Ai Chat机器人

						<div class="jzbb" v-if="left_show" style="width: 100%;height: 100vh;background: rgba(140,147,157,0.46);position: fixed;left: 0;top: 0" @click="left_show=false"></div>


						<span :class="left_show?'el-icon-s-fold fold-icon left_menu_icon':'el-icon-s-unfold fold-icon left_menu_icon sjdhdj'" :style="left_show?'left:'+lw+'px':'' " @click="left_show = !left_show"></span>

					</div>


					<div name="content-query">

						<?php
include_once('./tool/indexquery.php');
?>

					</div>


					<div class="containersrk" :style="'width: '+con_w+'px;left:'+left_w+'px;'">


						<div class="childsrk">
							<div class="input-containersrk shurk40" style="    position: absolute;
    bottom: 10px;">



								<?php
     
     if($nsfkqgpt4 == '开启'){
         echo '<button type="button" data-toggle="dropdown" aria-expanded="false" class="btn btn-secondary qhgpt4" style="    white-space: nowrap; margin: 0px 10px 0px 0px;background-color: rgb(52 53 65/var(--tw-bg-opacity)) !important;border: 1px solid rgb(140, 147, 157);    background-color: rgb(52, 53, 65) !important;
    border: 1px solid rgb(96, 96, 96) !important;
    border-radius: 4px;">换GPT4</button>';
     }
     
     ?>

								<?php
     if($adminall['sfkqyuyin'] == '1'){
      echo '<i id="record-btn" style="margin: 0 5px 0px 0px;font-size: 20px;" class="fa fa-microphone  lyyintb" aria-hidden="true"></i>';   
     }
     
     ?>

								<textarea style="padding: 10px 24px 7px 10px;" oninput="autoHeight(this)" type="text" autocomplete="off" id="kw-target" placeholder="您好，想问点什么？" class="el-input__inner form-controltw dtsrk" rows="1"></textarea>


								<div class="button-containersrk">
									<span onclick="resetHeight()" style="   " @click.stop="fasong(event)" id="ai-btn" class="fasong ai-btn ">
										<i class="el-tooltip el-icon-s-promotion item" aria-describedby="el-tooltip-6447" tabindex="0" style="color: rgb(167, 161, 161); cursor: pointer;"></i>
									</span>
								</div>


								<button class="btn-primary gnann" data-bs-toggle="modal" data-bs-target="#myModal" style=" outline: none;justify-content: center;align-items: center;width: 2.5rem;height: 2.5rem;margin: 0px 0px 0px 5px;background-color: rgb(52, 53, 65) !important;border: 1px solid rgb(96, 96, 96) !important;border-radius: 4px;">
									<span class="text-base text-slate-500 dark:text-slate-400">

										<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" width="1em" height="1em" viewBox="0 0 24 24" class=" iconify iconify–material-symbols" style="top: -2px; position: relative; color: white;">
											<path fill="currentColor" d="M12 8.6l6 6-1.4 1.4-4.6-4.6-4.6 4.6L6 14.6l6-6Z"></path>
										</svg>



									</span>

								</button>

							</div>




						</div>

					</div>

				</div>

			</div>


			<?php
include_once('./tool/loginlist.php');
?>



			<div style="display: none;" class="zuiwaimt"></div>

			<?php
        $sql = "select gglx from chat_admin where id = 1";
        $gglx = $mysql->getOne($sql);
 
        //公告标题
        $sql = "select ggbtzdy from chat_admin where id = 1";
        $ggbtzdy = $mysql->getOne($sql);
 
 
        if($gglx == '1'){
            
            if(empty(uacc())){
                echo '<div class="popup" id="note" style="display:none;"> <div class="popup-header" style="margin: 0px 0 40px 0;"> <h3 class="popup-title">'.$ggbtzdy.'</h3> </div> <div class="popup-main">';
                $file = $dangqianlj.'admin/ggnr.php';
                require($file);
                echo '</div> <div class="popup-footer"><span style="padding: unset;" class="popup-btn" onclick="closeclick()">我记住啦</span></div> </div>';
            }
            
      
        }else if($gglx == '2'){
            
            if(!empty(uacc())){
                echo '<div class="popup" id="note" style="display:none;"> <div class="popup-header" style="margin: 0px 0 40px 0;"> <h3 class="popup-title">'.$ggbtzdy.'</h3> </div> <div class="popup-main">';
                 $file = $dangqianlj.'admin/ggnr.php';
                require($file);
                echo '</div> <div class="popup-footer"><span style="padding: unset;" class="popup-btn" onclick="closeclick()">我记住啦</span></div> </div>';
             
            }
            
            
        }else if($gglx == '3'){
            
            if(!empty(uacc())){
                
     
               
                if($sycs != '0'){
                    
                    echo '<div class="popup" id="note" style="display:none;"> <div class="popup-header" style="margin: 0px 0 40px 0;"> <h3 class="popup-title">'.$ggbtzdy.'</h3> </div> <div class="popup-main">';
                    $file = $dangqianlj.'admin/ggnr.php';
                    require($file);
                    echo '</div> <div class="popup-footer"><span style="padding: unset;" class="popup-btn" onclick="closeclick()">我记住啦</span></div> </div>';
       
                     
                     
                }else{
                    
                    if(($sfvip != '') || ($time2 < $time1)){
                        echo '<div class="popup" id="note" style="display:none;"> <div class="popup-header" style="margin: 0px 0 40px 0;"> <h3 class="popup-title">'.$ggbtzdy.'</h3> </div> <div class="popup-main">';
                         $file = $dangqianlj.'admin/ggnr.php';
                        require($file);
                        
                        echo '</div> <div class="popup-footer"><span style="padding: unset;" class="popup-btn" onclick="closeclick()">我记住啦</span></div> </div>';
                           
                    }   
                    
                }
      
            }
            
        }
?>

			<!--公告-->

			<!--加载-->


			<!--菜单 -->
			<div class="modal fade in" id="myModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
				<div class="modal-dialog cdltc">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="exampleModalLabel">菜单功能栏</h5>
							<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
						</div>
						<div class="modal-body cdlgn">

							<button data-bs-toggle="xiazatp" title="导出本页为图片" class="gnann gnanntu" style="border-radius: 4px;outline: none;justify-content: center;align-items: center;width: 2.5rem;height: 2.5rem;margin: 0px 0px 0px 5px;border: 1px solid rgb(255 255 255) !important;">
								<span class="text-base text-slate-500 dark:text-slate-400">


									<i class="fa fa-download" aria-hidden="true" />
									</i>


								</span>



							</button>


							<button data-bs-toggle="xiazatp" title="导出当前对话为Word文档" class="gnann xiazwd" style="border-radius: 4px;outline: none;justify-content: center;align-items: center;width: 2.5rem;height: 2.5rem;margin: 0px 0px 0px 5px;border: 1px solid rgb(255 255 255) !important;">
								<span class="text-base text-slate-500 dark:text-slate-400">

								</span>


								<i class="fa fa-file-word-o" aria-hidden="true" />
								</i>

							</button>

							<button data-bs-toggle="xiazatp" title="删除所有对话信息" class="gnann scsydhxx" style="border-radius: 4px;outline: none;justify-content: center;align-items: center;width: 2.5rem;height: 2.5rem;margin: 0px 0px 0px 5px;border: 1px solid rgb(255 255 255) !important;">
								<span class="text-base text-slate-500 dark:text-slate-400">

								</span>

								<i class="fa fa-trash"></i>
							</button>
							
							
							
							
							<div style="display:none;" class="gptlwpd">0</div>
							
							
							<button data-bs-toggle="xiazatp" title="开启GPT联网功能" class="gnann kaiqilwgn" style="border-radius: 4px;outline: none;justify-content: center;align-items: center;width: 2.5rem;height: 2.5rem;margin: 0px 0px 0px 5px;border: 1px solid rgb(255 255 255) !important;">
								<span class="text-base text-slate-500 dark:text-slate-400">

								</span>

								<i class="fa fa-internet-explorer" aria-hidden="true" /></i>
							</button>
							
							     
                           
                           
                           
                 	
							<div style="display:none;" class="sflxdhgn">1</div>
							
							
							<button data-bs-toggle="xiazatp" title="是否保留连续对话" class="gnann sfkqlxdh" style="border-radius: 4px;outline: none;justify-content: center;align-items: center;width: 2.5rem;height: 2.5rem;margin: 0px 0px 0px 5px;border: 1px solid rgb(255 255 255) !important;">
								<span class="text-base text-slate-500 dark:text-slate-400">

								</span>

								<i class="fa fa-history"></i>
							</button>
							
							     
                           
                           
                            
							
							
							
							
							
							
							
							


						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">关闭</button>
						</div>
					</div>
				</div>
			</div>

			<div class="loading-wrap">
				<div class="balls">
					<div></div>
					<div></div>
					<div></div>
				</div>
			</div>


			<!--录音-->
			<div id="overlay" class="overlay">

				<div id="recording-indicator" class="card" style="width: 140px;">
					<div class="card-body" style="text-align: center;">
						<h5 style="color: black;text-align: center;" class="card-title">
							<i id="record-btn" aria-hidden="true" class="fa fa-microphone" style="margin: 0px 5px 0px 0px; font-size: 20px;"></i>实时录音中...
						</h5>

						<button id="stop-btn" class="btn btn-danger">结束</button>

						<p class="daojishisss" style="margin: 5px 0 0 0;">60</p>

						<p id="fixed-txt" style="margin: 5px 0 0 0;max-height: 100px; overflow: auto;"></p>

					</div>
				</div>
			</div>





			<button style="display:none;" id="inviteBtn" class="btn btn-primary">邀请好友</button>
			<!--邀请-->
			<?php
if(!empty($_GET)){
    if($_GET['id'] == '邀请'){
        require_once('./yaoqinghtml.php');
    }
}
?>






			<?php
require('./tool/kefu.php');
?>

	</body>

	<style>

		.form-control{
            height: unset!important;
            -webkit-box-shadow:unset!important;
    }
    

    .con-right{
        position: relative;
    }
    
    .jzbb{
        background: white;
    }
    
    
    .containersrk{
        position: relative;
    }
    
    @media (min-width: 640px){
        .sjdh{
            display: none;
        }
 
    }
    
.dtsrk {
      padding: 0.7rem 0.5rem;
    line-height: 1.3 !important;
}
</style>

	<script>
		$(function() {
		    setTimeout(function() {
		if (!(isMobile())) {
		  $(".con-right").css("height", 'unset');
		   
		}
		  }, 1);
		
		});
	</script>
	<script src="/assets/bootstrap.min.js?id=<?php echo $banbenhao;?>"></script>
	<script>
		var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="xiazatp"]'));
		    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
		      return new bootstrap.Tooltip(tooltipTriggerEl);
		    })
	</script>
	<script src="/assets/lm.js?id=<?php echo $banbenhao;?>"></script>
	<script src="/zidingyi.js?id=<?php echo $banbenhao;?>"></script>
	<script src="js/remarkable.js?id=<?php echo $banbenhao;?>"></script>
	<script src="js/jquery.min.js?id=<?php echo $banbenhao;?>"></script>
	<script src="js/jquery.cookie.min.js?id=<?php echo $banbenhao;?>"></script>
	<script src="js/layer.min.js" type="application/javascript"></script>
	<script src="js/chat.js?id=<?php echo $banbenhao;?>"></script>
	<script src="js/highlight.min.js?id=<?php echo $banbenhao;?>"></script>
	<script src="js/showdown.min.js?id=<?php echo $banbenhao;?>"></script>

	<script>
		$(window).on('load', function() {
		       $('.zbsc').css('display','unset');
		       $('.loading-wrap').css('display','none');
		       
		       
		    });
	</script>
	<?php
include_once('./tool/tongji.php');
include_once('./tool/getend.php');
?>
</html>