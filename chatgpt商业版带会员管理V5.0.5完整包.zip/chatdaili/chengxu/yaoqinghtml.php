<?php

error_reporting(0);

$dqyh = $_COOKIE['dengluname'];

$letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
$rand_letters = substr(str_shuffle($letters), 0, 10);


$sql = "select * from chat_yonghu where shangjiyaoqingma = '$rand_letters'";
$sfczzz = $mysql->getAll($sql);

while(count($sfczzz) == 1){
    $letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $rand_letters = substr(str_shuffle($letters), 0, 10);
    $sql = "select * from chat_yonghu where shangjiyaoqingma = '$rand_letters'";
    $sfczzz = $mysql->getAll($sql);
}



$current_url = "http://" . $_SERVER['HTTP_HOST'] . '/?code=';


//判断是否有跳板域名
$sql = "select tiaobanurl from chat_admin where id = 1";
if($mysql->getOne($sql)){
    $tbym = $mysql->getOne($sql);
    $current_url = "http://" . $tbym . '/?code=';
}

$sql = "select shangjiyaoqingma from chat_yonghu where yhmc = '$dqyh'";
if(!($mysql->getOne($sql))){
    $sql = "update chat_yonghu set shangjiyaoqingma='$rand_letters' where yhmc = '$dqyh'";
    $mysql->query($sql);
    $current_url = $current_url . $rand_letters;
    $yqm = $rand_letters;
}else{
    $yqm = $mysql->getOne($sql);
    $current_url = $current_url . $yqm;
}

?>

<div class="yaoqingym">
    
<style>
  
   #inviteModal2 #overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      z-index: 999;
      display: none;
    }

   #inviteModal2 #overlay.show {
      display: block;
    }

   #inviteModal2 #invitedUsersTable {
      max-height: 200px;
      overflow-y: auto;
    }

   #inviteModal2 .info-card {
      border: 1px solid #ccc;
      border-radius: 5px;
      padding: 10px;
      margin-bottom: 10px;
    }
    
  </style>

        

 <style>
      #inviteModal2  .modal-backdrop {
            opacity: 0.5 !important;
        }
    </style>

<style>
 
 
#inviteModal2 textarea {
    resize: vertical!important;
}
 
 
#inviteModal2 label {
    display: unset;
    width: unset;
    height: unset;
    border-radius: unset;
    background: unset;
    border: unset;
    cursor: unset;
    position: unset;
    overflow: unset;
}
 
#inviteModal2 .form-control {
    display: block!important;
    /*width: 100%!important;*/
    padding: .375rem .75rem!important;
    font-size: 1rem!important;
    font-weight: 400!important;
    line-height: 1.5!important;
    color: #212529!important;
    background-color: #fff!important;
    background-clip: padding-box!important;
    border: 1px solid #ced4da!important;
    -webkit-appearance: none!important;
    -moz-appearance: none!important;
    appearance: none!important;
    border-radius: .25rem!important;
    transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out!important;
}



  #inviteModal2 .modal-content {
 position: relative!important;
    display: flex!important;
    flex-direction: column!important;
    width: 200%!important;
    pointer-events: auto!important;
    background-color: #fff!important;
    background-clip: padding-box!important;
    border: 1px solid rgba(0,0,0,.2)!important;
    border-radius: .3rem!important;
    outline: 0!important;
    right: 50%;
}


@media (max-width: 640px){
    #inviteModal2 .modal-content {
 position: relative!important;
    display: flex!important;
    flex-direction: column!important;
    width: 100%!important;
    pointer-events: auto!important;
    background-color: #fff!important;
    background-clip: padding-box!important;
    border: 1px solid rgba(0,0,0,.2)!important;
    border-radius: .3rem!important;
    outline: 0!important;
    right: 0%;

}

}


#inviteModal2 .modal-body {
    position: relative!important;
    flex: 1 1 auto!important;
    padding: 1rem!important;
}
#inviteModal2 .modal-body {
    text-align: unset;
    background: unset;
    border-radius: unset;
    /* margin: 45% 0 0 0; */
    /* position: absolute; */
}
#inviteModal2 .card p{
         overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
 }
 
#inviteModal2 .btn{
    border: 1px solid transparent!important;
        border-color: #6c757d!important;
}
    
</style>



  <div id="inviteModal2" class="modal fade in" tabindex="-1" >
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">邀请好友</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
              
            <label for="inviteLink" class="form-label">邀请链接</label>
            <div class="input-group">
              <input type="text" class="form-control" id="inviteLink" readonly value="<?php echo $current_url;?>">
              <button class="btn btn-outline-secondary" type="button" id="copyBtn">复制</button>
            </div>
          </div>
          
          		    <?php
																		    
					$sql = "select dsktxye from chat_admin where id = 1";
					$kexyee = $mysql->getOne($sql);
					$dqyhss = $_COOKIE['dengluname'];						    
					$sql = "select ketixian from chat_yonghu where yhmc='$dqyhss'";
							
					$hqsyyq = $mysql->getOne($sql);	
						  							    ?>
          <div class="mb-3">
              
            <label for="inviteLink" class="form-label">可提余额(满<?php echo $kexyee;?>可提现)，<b style="color:red;">当前你已有：<span class="ketje"><?php echo $hqsyyq;?>元</span></b></label>
            <div class="input-group">
                
                
                
              <!--<input type="text" class="form-control" id="inviteLink" readonly>-->
              
              	<input id="yqljzfb" value="" type="text" class="n-input__input-el zfbhm form-control" placeholder="请输入支付宝账户"  size="20">
			
              
              <button class="btn btn-outline-secondary txhtml" type="button" id="txyx">提现</button>
            </div>
          </div>
          
          
          
          <div class="mb-3">
            <label for="activityDescription" class="form-label">活动介绍</label>
            <p id="activityDescription">	<?php
					//获取佣金比例
						$sql = "select fanli from chat_admin where id = '1'";
						$yjbl = $mysql->getOne($sql);
				
				?>
				
				
				邀请用户下单返利高达百分之<?php echo $yjbl;?>的奖励，例如你邀请一个人充值10元，你就获得<?php echo round(10*$yjbl/100) ?>元，充值100你就获得<?php echo round(100*$yjbl/100) ?>元，下级关系永久绑定，下级回购依然有奖励，余额你可以自己购买提问次数或者提现！</p>
          </div>
          <div class="row">
            <div class="col-md-4">
              <div class="info-card">
                <h5>已邀请：</h5>
                <p id="inviteCount">				<?php
																	
																						
						$sql = "select * from chat_yonghu where orshangji='$yqm'";
							
						$hqsyyq = $mysql->getAll($sql);	
							
											$hqsyyq = count($hqsyyq);						
																	echo $hqsyyq;
																	?>	</p>
              </div>
            </div>
            <div class="col-md-4">
              <div class="info-card">
                <h5>邀请总消费：</h5>
                <p id="totalSpending">			<?php
												
																						
						$sql = "select SUM(zongxiaofei) from chat_yonghu where orshangji='$yqm'";
							
						$hqsyyq = $mysql->getOne($sql);	
							
													
																	echo $hqsyyq;
																	?>元</p>
              </div>
            </div>
            <div class="col-md-4">
              <div class="info-card">
                <h5>返利积分(元)：</h5>
                
                <p id="rebatePoints">	<?php
							
							$dqyhss = $_COOKIE['dengluname'];					
						//获取佣金比例
						$sql = "select fanli from chat_admin where id = '1'";
						$yjbl = $mysql->getOne($sql);	
						
						
																						
						$sql = "select ketixian from chat_yonghu where yhmc='$dqyhss'";
							
						$hqsyyq = $mysql->getOne($sql);	
						
						
					print_r($hqsyyq." 积分");
																	?>	</p>
              </div>
            </div>
          </div>      <br>
          <!--<h5>邀请的用户数据</h5>-->
           <label for="inviteLink" class="form-label">邀请的用户数据(最新十条)</label>
             
          <div id="invitedUsersTable" class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>用户名</th>
                  <th>注册时间</th>
                  <th>Ta总消费</th>
                  <th>返利积分</th>
                </tr>
              </thead>
              <tbody id="invitedUsers">
                  
                  
       
                  
                  							<?php
							
							
							
// 获取总记录数
$sql = "SELECT COUNT(*) FROM chat_yonghu WHERE orshangji = '$yqm' ORDER BY id DESC LIMIT 10";
$zsss = $mysql->getOne($sql);



// 计算总页数
$pageSize = 10;
$totalPage = ceil($zsss / $pageSize);


// 获取当前页码
$page = isset($_GET["page"]) ? intval($_GET["page"]) : 1;
if ($page < 1) {
    $page = 1;
} elseif ($page > $totalPage) {
    $page = $totalPage;
}


if($zsss != 0){
    // 获取当前页的数据
$offset = ($page - 1) * $pageSize;
$sql = "SELECT * FROM chat_yonghu where orshangji='$yqm' order by id desc LIMIT $offset, $pageSize";
$result = $mysql->getAll($sql);
}







if($result != ''){
    foreach ($result as $value) {
							   echo '									
														<tr>
															<td>
														'.$value['yhmc'].'
														
														</td>
														
														
														<td colspan="1" rowspan="1" data-col-key="registerTime" class="n-data-table-td n-data-table-td--last-row"><!---->
														
													'.$value['time'].'
														
														</td>
														
														
														<td>
														
												'.$value['zongxiaofei'].'
														
														
														</td>
														
														
														
														<td>
														
									
									'.round($value['zongxiaofei']*$yjbl/100).'					
													
														
														</td>
														
														</tr>';
							}
							
}
							

			
					
							
							?>										
											
	
                  
                  
              </tbody>
            </table>
            
            
            
            
          </div>
          
          <br>
          
          
          <label for="inviteLink" class="form-label">提现记录</label>
 
          <div id="invitedUsersTable" class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>提现支付宝</th>
                  <th>提现时间</th>
                  <th>提现金额</th>
                  <th>是否成功</th>
                </tr>
              </thead>
              <tbody id="invitedUsers">
                  
                		<?php
							
							
							
// 获取总记录数
$sql = "SELECT COUNT(*) FROM chat_tixian where txyh='$dqyhss' order by id desc";
$zsss = $mysql->getOne($sql);



// 计算总页数
$pageSize = 10;
$totalPage = ceil($zsss / $pageSize);


// 获取当前页码
$page = isset($_GET["pagetx"]) ? intval($_GET["pagetx"]) : 1;
if ($page < 1) {
    $page = 1;
} elseif ($page > $totalPage) {
    $page = $totalPage;
}


if($zsss != 0){
    // 获取当前页的数据
$offset = ($page - 1) * $pageSize;
$sql = "SELECT * FROM chat_tixian where txyh='$dqyhss' order by id desc LIMIT $offset, $pageSize";
$result2 = $mysql->getAll($sql);
}


if($result2 != ''){
    foreach ($result2 as $value) {
        
        
        if($value['sfcl'] == '0'){
            $txxx = '待处理';
        }else if($value['sfcl'] == '1'){
            $txxx = '提现成功';
        }else if($value['sfcl'] == '2'){
            $txxx = '驳回';
        }
        
        
        
							   echo '									
														<tr>
														
														<td>
														'.$value['txsjh'].'
														
														</td>
														
														
														<td>
														
													'.$value['time'].'
														
														</td><td>
														
														
												'.$value['txje'].'
														
														
														</td>
														
														
														
														<td>
														
									
									'.$txxx.'				
													
												
														</td>
														
														</tr>';
							}
							
}
							

			
					
							
							?>										
		
                  
              </tbody>
            </table>
          </div>
          
          <!--<div class="mb-3">-->
          <!--  <label for="username" class="form-label">用户名</label>-->
          <!--  <div class="input-group">-->
          <!--    <input type="text" class="form-control" id="username">-->
          <!--    <button class="btn btn-primary" type="button" id="addUserBtn">Add User</button>-->
          <!--  </div>-->
          <!--</div>-->
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">关闭</button>
          <!--<button type="button" class="btn btn-primary">Send Invitation</button>-->
        </div>
      </div>
    </div>
  </div>

  <div id="overlay2"></div>

</div>
