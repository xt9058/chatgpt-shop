<?php
$sql = "select gpt3html from chat_admin where id = 1";
$ggnr = $mysql->getOne($sql);
if($ggnr == ''){
    echo '<div class="content" style="margin: 0px auto;">
	<h4 onclick="resetHeight()" class="title syh4" style="">Ai Chat机器人<span class="syplus"> Plus </span>
	</h4>
	<br>
	<br>
<div style="width: 100%;">    
<div class="info-box el-col el-col-24 el-col-xs-24 el-col-sm-24 el-col-md-8">
	<i class="el-icon-chat-dot-square" style="font-size: 24px; color: rgb(102, 102, 102);"></i>
	<span class="in-t">使用示例</span>
	<ul>
		<li>“用简单的术语解释量子计算”</li>
		<li>“对于一个10岁的孩子的生日，有什么创意吗”</li>
		<li>“如何用Javascript发出HTTP请求?”</li>
	</ul>
</div>
<div class="info-box el-col el-col-24 el-col-xs-24 el-col-sm-24 el-col-md-8">
	<i class="el-icon-cpu" style="font-size: 24px; color: rgb(102, 102, 102);"></i>
	<span class="in-t">能力</span>
	<ul>
		<li>直观感受第四次工业革命</li>
		<li>记住用户之前在对话中说过的话</li>
		<li>允许用户提供后续修正，接受或拒绝不适当请求的培训</li>
	</ul>
</div>
<div class="info-box el-col el-col-24 el-col-xs-24 el-col-sm-24 el-col-md-8">
	<i class="el-icon-warning-outline" style="font-size: 24px; color: rgb(102, 102, 102);"></i>
	<span class="in-t">局限性</span>
	<ul>
		<li>可能偶尔会产生不正确的信息</li>
		<li>可能偶尔会产生有害的指令或有偏见的内容</li>
		<li>对2023年后的世界和事件的了解有限</li>
	</ul>
</div>';
}else{
    print_r($ggnr);
}
?>

