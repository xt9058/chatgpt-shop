<?php include_once('./tool/get.php');?>
<?php
require('./tool/code.php');
if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
    $ip = $_SERVER["HTTP_CF_CONNECTING_IP"];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
    
}
$expiration = time() + (30 * 24 * 60 * 60); 
setcookie("yhip", $ip, $expiration, "/");
require('./tool/coo.php');
require('./tool/pu.php');
$banbenhao = file_get_contents($banbenhlj.'admin/banben.php');
?>
<!doctype html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport"
			  content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<meta name="google" content="notranslate">
		<title>
			<?php echo $wzmc;?>
		</title>
		<meta name="description" content="<?php echo $wzms;?>">

		<script type="text/javascript" src="/jquery.js?id=<?php echo $banbenhao;?>"></script>
		<script src="/assets/jquery.cookie.min.js?id=<?php echo $banbenhao;?>"></script>
		<div id="cssah"></div>
		<div id="cssah2"></div>
		<script src="/assets/ansehuihua.js?id=<?php echo $banbenhao;?>"></script>
		<style>
		</style>
		<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
		<link rel="stylesheet" href="/css/index.css?id=<?php echo $banbenhao;?>">
		<script src="/assets/vue@2.62.js?id=<?php echo $banbenhao;?>"></script>
		<!--<script src="/assets/index.js"></script>-->
		<link rel="stylesheet" href="/assets/css.css?id=<?php echo $banbenhao;?>">
		<link href="/assets/bootstrap.min.css?id=<?php echo $banbenhao;?>" rel="stylesheet">
		<link rel="stylesheet" href="/css/common.css?id=<?php echo $banbenhao;?>">
		<link rel="stylesheet" href="/css/wenda.css?id=<?php echo $banbenhao;?>">
		<link rel="stylesheet" href="/css/hightlight.css?id=<?php echo $banbenhao;?>">
		<link rel="stylesheet" href="/zidingyi.css?id=<?php echo $banbenhao;?>">
		<link href="/assets/font-awesome/css/font-awesome.min.css?id=<?php echo $banbenhao;?>" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="/assets/lmhuihua.css?id=<?php echo $banbenhao;?>">
		<link rel="stylesheet" href="/css/css/jiazai.css?id=<?php echo $banbenhao;?>">
	</head>
	<?php
require('./tool/head.php');
?>
	<body style="background: white;">
		<div id="moxicon" class="zbsc" style="display:none;">

			<!--<el-tooltip class="item" effect="dark" content="导出文档" placement="left" v-if="talkId">-->
			<!--<a class="el-icon-document daochu" download="talk.pdf" :href="'/index/talk/pdf?id='+talkId" ></a>-->
			<!--</el-tooltip>-->
			<transition name="el-zoom-in-center">

				<div class="con-left" v-show="left_show||dw>800" style="height: 100%; 
    
    
    
  top: 0;
  bottom: 0;
  
  background-color: #fff;
  z-index: 999;">
					<div style="padding: 10px;position: relative;flex: 1;overflow: auto">
						<div style="display: flex;flex-direction: column">

							<?php
    
$sfyjdl = $_COOKIE['dengluname'];
if(!empty(uacc())){
    
    
    if($shihuiyuan == '是会员'){
        echo '
        <div class="p-4 gmtc2" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
    height: var(--n-merged-size);
    color: #FFF;
    font-size: var(--n-font-size);
    display: inline-flex;
    position: relative;
    overflow: hidden;
    text-align: center;
    border: var(--n-border);
    border-radius: var(--n-border-radius);
    --n-merged-color: var(--n-color);
    background-color: var(--n-merged-color);
    transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
    height: 100%;" class="" loading="eager" src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1="" data-image-src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1=""><!----></span><p style="margin-top: 10px;"><span class="" style="color: white;">Hi,'.$sfyjdl.'&nbsp;<span data-v-bf40dc81="" class="bg-yellow-200 text-yellow-900 py-0.5 px-1.5 text-xs md:text-sm rounded-md uppercase" style="text-transform: uppercase; font-size: 0.275rem; line-height: 1.25rem; --un-bg-opacity:1; background-color: rgba(254,240,138,var(--un-bg-opacity)); --un-text-opacity:1; color: rgba(113,63,18,var(--un-text-opacity)); padding: 0.125rem 0.375rem; border-radius: 0.375rem;"> 尊贵会员 </span></span></p></div>';
    }else{
        echo '
        <div class="p-4 gmtc2" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
    height: var(--n-merged-size);
    color: #FFF;
    font-size: var(--n-font-size);
    display: inline-flex;
    position: relative;
    overflow: hidden;
    text-align: center;
    border: var(--n-border);
    border-radius: var(--n-border-radius);
    --n-merged-color: var(--n-color);
    background-color: var(--n-merged-color);
    transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
    height: 100%;" class="" loading="eager" src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1="" data-image-src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1=""><!----></span><p style="margin-top: 10px;"><span class="" style="color: white;">Hi,'.$sfyjdl.'&nbsp;<span data-v-bf40dc81="" class="bg-yellow-200 text-yellow-900 py-0.5 px-1.5 text-xs md:text-sm rounded-md uppercase" style="text-transform: uppercase; font-size: 0.275rem; line-height: 1.25rem; --un-bg-opacity:1; background-color: rgba(254,240,138,var(--un-bg-opacity)); --un-text-opacity:1; color: rgba(113,63,18,var(--un-text-opacity)); padding: 0.125rem 0.375rem; border-radius: 0.375rem;"> 升级会员 </span></span></p></div>';
    }
    

}else{
    echo '<div class="p-4 dlzc" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
    height: var(--n-merged-size);
    color: #FFF;
    font-size: var(--n-font-size);
    display: inline-flex;
    position: relative;
    overflow: hidden;
    text-align: center;
    border: var(--n-border);
    border-radius: var(--n-border-radius);
    --n-merged-color: var(--n-color);
    background-color: var(--n-merged-color);
    transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
    height: 100%;" class="dlzc" loading="eager" src="/assets/anonymous.jpg" data-image-src="/assets/anonymous.jpg"><!----></span><p style="margin-top: 10px;"><span class="dlzc" style="color: white;">点击登录</span></p></div>';
}
    
    
    
    ?>


							<div class="talk-add tjxhh">
								<i class="el-icon-plus all-talk-icon"></i>
								新会话
							</div>



							<div id="xdh">



							</div>





						</div>
					</div>
					<div class="left-bottom" style="">
						<ul style="">



							<li class="indextz">
								<i class="fa fa-send" aria-hidden="true" />
								</i>
								<a href="index.php"> 提问ChatGPT模式</a>
							</li>






							<?php
    
    $sql = "select sfkqkf from chat_admin where id = 1";
$sfkqkf = $mysql->getOne($sql);
    if($sfkqkf == '开启'){
        echo '<li class="lxkfyx">
    <i class="fa fa-wechat" aria-hidden="true" /></i>
                    <a> 联系客服</a>
                </li>';
    }
    
    ?>





							<?php

$sfyjdl = $_COOKIE['dengluname'];
if(!empty(uacc())){
    
    echo '
								
						<li class="cxsycs">
              <i class="el-icon-search"></i>
                    <a></i>查询剩余次数</a>
                </li>';
						
					
				if($sfkqyhyqgn == '开启'){
				    	echo '	  <li class="dwyqhy">
              
<i class="fa fa-share-alt" aria-hidden="true" /></i> 邀请好友<span style="background: linear-gradient(to right, rgb(255, 0, 255), rgb(106, 90, 205)); font-size: 12px; padding: 2px; border-radius: 5px; margin-left: 10px;">赚佣金！</span></a>
                </li>		';
				}	
						
				
    
}else{
    
    
    if($sfkqyhyqgn== '开启'){
           echo '  <li class="dlzc">
              
<i class="fa fa-share-alt" aria-hidden="true" /></i> 邀请好友<span style="background: linear-gradient(to right, rgb(255, 0, 255), rgb(106, 90, 205)); font-size: 12px; padding: 2px; border-radius: 5px; margin-left: 10px;">赚佣金！</span></a>
                </li>';
    }
    
 
    
}


?>


							<?php
                
                if($ansems){
                    echo '         <li class="anhms">
             <i class="fa fa-moon-o"></i>

                    <a> 白天模式</a>
           
                    
                </li>';
                
                
                }else{
                     echo '         <li class="anhms">
            <i class="fa fa-sun-o" aria-hidden="true" /></i>

                    <a> 暗黑模式</a>
           
                    
                </li>';
                }
                
                
                
                ?>



							<?php

$sfyjdl = $_COOKIE['dengluname'];
if(!empty(uacc())){
    
    
    if($shihuiyuan == '是会员'){
        
        echo '<li  @click.stop="nydl()" class="" style="display: flex;flex-direction: row;position: relative" >
                    <a><i class="el-icon-s-custom"></i> Hi,'.$sfyjdl.'</a>     <span class="" style="background: linear-gradient(to right,#ce9434,#fcb848);
                    font-size: 12px;padding: 1px 2px;border-radius: 4px;margin-left: 10px" >尊贵会员</span>
                    
            <li>
                 <i class="el-icon-switch-button"></i>
                  <a href="huihua.php?tcdl=huihua"></i>退出登录</a>
                
                </li>         
                    
        
                    ';
        
    }else{
        echo '<li  @click.stop="nydl()" class="" style="display: flex;flex-direction: row;position: relative" >
                    <a><i class="el-icon-s-custom"></i> Hi,'.$sfyjdl.'</a>     <span class="" style="background: linear-gradient(to right,#ce9434,#fcb848);
                    font-size: 12px;padding: 1px 2px;border-radius: 4px;margin-left: 10px" >升级会员</span>
                    
            <li>
                 <i class="el-icon-switch-button"></i>
                  <a href="huihua.php?tcdl=huihua"></i>退出登录</a>
                
                </li>         
                    
        
                    ';
    }
    
    
    
}else{
    echo '  <li  @click.stop="loginOut()" class="dlzc" style="display: flex;flex-direction: row;position: relative" >
                    <a><i class="el-icon-s-custom"></i> 登录or注册</a>     <span class="dlzc" style="background: linear-gradient(to right,#ce9434,#fcb848);
                    font-size: 12px;padding: 1px 2px;border-radius: 4px;margin-left: 10px" >升级会员</span>';
}


    ?>




							</li>


							<!--更多-->
							<?php
include_once('./tool/gengduo.php');
?>



						</ul>

						<br>
						<br>

					</div>
				</div>

			</transition>

			<div style="z-index: 9;" class="con-right" id="con-right" :style="'width: '+con_w+'px;left:'+left_w+'px;height: '+(dh-70)+'px;'">

			    	<?php require_once('./admin/huihuahtml.php');?>

                    </div>
				</div>
				<div class="call-box"></div>
			</div>



			<div class="call-box" style="display:;   " :style="'width: '+con_w+'px;left:'+left_w+'px;'">


				<div class="sjdh" v-show="dw<=800" style="width: 100%;height: 60px;background: #474646;position: fixed;left: 0;top: 0;text-align: center;color: #fff;z-index: 100;line-height: 60px;">

					ChatGPT绘图版



					<div class="jzbb" v-if="left_show" style="width: 100%;height: 100vh;background: rgba(140,147,157,0.46);position: fixed;left: 0;top: 0" @click="left_show=false"></div>


					<span :class="left_show?'el-icon-s-fold fold-icon left_menu_icon':'el-icon-s-unfold fold-icon left_menu_icon sjdhdj'" :style="left_show?'left:'+lw+'px':'' " @click="left_show = !left_show"></span>

				</div>










				<div name="content-query">

					<div class="layout-content" style="    background: white; color:white; ">
						<div class="">
							<article class="article" id="article">
								<div class="article-box">


									<div style="    display:none;" class="precast-block" data-flex="main:left">
										<div class="input-group">

											<!--<span style="text-align: center;color:#9ca2a8">&nbsp;&nbsp;连续对话：</span>-->
											<!--<input  type="checkbox" id="keep"  checked style="min-width:220px;display:none;">-->
											<!--<label for="keep"></label>-->


											<span style="   display:none; text-align: center;color:#9ca2a8">&nbsp;&nbsp;输入你的APIKEY(输入之后即可使用)：👉</span>



											<input style="    display:none;
    
             height: 25px;
    padding: 0px 5px;
    font-size: 15px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    border: 1px solid #000;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
    box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
    -webkit-transition: border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;" class="" type="text" placeholder="sk-xxxxxxxxxx" maxlength="100" id="key" value="<?php echo $_COOKIE['key'];?>" style="    background-color: rgb(234, 235, 241);min-width:200px;max-width:280px">



											<?php

$sfyjdl = $_COOKIE['dengluname'];
if(!empty(uacc())){
    
    echo '<div style="" class="right-btn layout-bar">
								    
									<p style="    width: 100px;
    margin: 0px 0 0 40px;    width: 100px;
    margin-left: 14px;
    text-align: center;
    height: 24px;
    line-height: 24px;
    font-size: 14px;
    border-radius: var(--zhuluan-primary-border-radius);
  
    cursor: pointer;
    transition: all .4s;" class="cxsycs  bright-btn" id=""  data-flex="main:center cross:center">查询剩余次数</p>
    

    
								</div>';
    
}


?>




										</div>
									</div>



									<ul id="article-wrapper" class="ztsc">



									</ul>





									<div class="creating-loading" data-flex="main:center dir:top cross:center">
										<div class="semi-circle-spin"></div>
									</div>

								</div>
							</article>
						</div>
					</div>


				</div>





				<div class="containersrk" :style="'width: '+con_w+'px;left:'+left_w+'px;'">



					<div class="hhfanyi" style="position: absolute; right: 15.1%; top: -25px; z-index: 10;">
						<div role="none" class="n-space" style="display: flex; flex-flow: row wrap; justify-content: flex-start;">
							<div role="none" style="max-width: 100%;">
								<div data-v-6c51b16a="" class="n-tag n-tag--round" style="--n-font-weight-strong:500;--n-avatar-size-override:calc(22px - 8px);--n-bezier:cubic-bezier(0.4, 0, 0.2, 1);--n-border-radius:2px;--n-border:1px solid rgba(99, 226, 183, 0.3);--n-close-icon-size:12px;--n-close-color-pressed:rgba(99, 226, 183, 0.12);--n-close-color-hover:rgba(99, 226, 183, 0.16);--n-close-border-radius:2px;--n-close-icon-color:rgba(99, 226, 183, 0.7);--n-close-icon-color-hover:rgba(99, 226, 183, 0.7);--n-close-icon-color-pressed:rgba(99, 226, 183, 0.7);--n-close-icon-color-disabled:rgba(99, 226, 183, 0.7);--n-close-margin:0 0 0 4px;--n-close-margin-rtl:0 4px 0 0;--n-close-size:16px;--n-color:rgba(99, 226, 183, 0.16);--n-color-checkable:#0000;--n-color-checked:#63e2b7;--n-color-checked-hover:#7fe7c4;--n-color-checked-pressed:#5acea7;--n-color-hover-checkable:rgba(255, 255, 255, 0.12);--n-color-pressed-checkable:rgba(255, 255, 255, 0.08);--n-font-size:12px;--n-height:22px;--n-opacity-disabled:0.38;--n-padding:0 7px;--n-text-color:#63e2b7;--n-text-color-checkable:rgba(255, 255, 255, 0.82);--n-text-color-checked:#000;--n-text-color-hover-checkable:rgba(255, 255, 255, 0.82);--n-text-color-pressed-checkable:rgba(255, 255, 255, 0.82);cursor: pointer;white-space: nowrap;position: relative;box-sizing: border-box;cursor: default;display: inline-flex;align-items: center;flex-wrap: nowrap;padding: var(--n-padding);border-radius: var(--n-border-radius);color: var(--n-text-color);background-color: var(--n-color);transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier), box-shadow .3s var(--n-bezier), opacity .3s var(--n-bezier);line-height: 1;height: var(--n-height);font-size: var(--n-font-size);border-radius: calc(var(--n-height) / 2);">翻译输入框</div>
							</div>
						</div>
					</div>




					<div class="childsrk">
						<div class="input-containersrk shurk40" style="    position: absolute;
    bottom: 10px;">



							<button data-bs-toggle="modal" data-bs-target="#myModal" type="button" data-toggle="dropdown" aria-expanded="false" class="btn btn-secondary qhgpt4" style="margin: 0 10px 0 0; background-color: rgb(52, 53, 65); border: 1px solid rgb(96, 96, 96); border-radius: 4px; white-space: nowrap;


">绘画广场</button>


							<!--<button type="button" data-toggle="dropdown" aria-expanded="false" class="btn btn-secondary qhgpt4" style="white-space: nowrap;">绘画广场</button>-->




							<textarea oninput="autoHeight(this)" type="text" autocomplete="off" id="kw-target" placeholder="您好，想画点什么？必须英文" class="el-input__inner form-controltw dtsrk" rows="1"></textarea>


							<div class="button-containersrk">
								<span onclick="resetHeight()" style="   " @click.stop="fasong(event)" id="ai-btn" class="fasong ai-btn ">
									<i class="el-tooltip el-icon-s-promotion item" aria-describedby="el-tooltip-6447" tabindex="0" style="color: rgb(167, 161, 161); cursor: pointer;"></i>
								</span>
							</div>
						</div>






					</div>



				</div>





			</div>

		</div>



		<?php
include_once('./tool/loginlist.php');
?>




		<div style="display: none;" class="zuiwaimt"></div>

		<?php
        $sql = "select gglx from chat_admin where id = 1";
        $gglx = $mysql->getOne($sql);
 
 
        $sql = "select huihuacs from chat_yonghu where yhmc = '$sfyjdl'";
        $huihuacs = $mysql->getOne($sql);
 
        
        //公告标题
        $sql = "select ggbtzdy from chat_admin where id = 1";
        $ggbtzdy = $mysql->getOne($sql);
        
 
        if($gglx == '1'){
            
            if(empty(uacc())){
                echo '<div class="popup" id="note" style="display:none;"> <div class="popup-header" style="margin: 0px 0 40px 0;"> <h3 class="popup-title">'.$ggbtzdy.'</h3> </div> <div class="popup-main">';
                $file = $dangqianlj.'admin/ggnr.php';
                require($file);
                echo '</div> <div class="popup-footer"><span style="padding: unset;" class="popup-btn" onclick="closeclick()">我记住啦</span></div> </div>';
            }
            
      
        }else if($gglx == '2'){
            
            if(!empty(uacc())){
                echo '<div class="popup" id="note" style="display:none;"> <div class="popup-header" style="margin: 0px 0 40px 0;"> <h3 class="popup-title">'.$ggbtzdy.'</h3> </div> <div class="popup-main">';
                 $file = $dangqianlj.'admin/ggnr.php';
                require($file);
                echo '</div> <div class="popup-footer"><span style="padding: unset;" class="popup-btn" onclick="closeclick()">我记住啦</span></div> </div>';
             
            }
            
            
        }else if($gglx == '3'){
            
            if(!empty(uacc())){
                

                if($huihuacs != '0'){
                    
                    echo '<div class="popup" id="note" style="display:none;"> <div class="popup-header" style="margin: 0px 0 40px 0;"> <h3 class="popup-title">'.$ggbtzdy.'</h3> </div> <div class="popup-main">';
                    $file = $dangqianlj.'admin/ggnr.php';
                    require($file);
                    echo '</div> <div class="popup-footer"><span style="padding: unset;" class="popup-btn" onclick="closeclick()">我记住啦</span></div> </div>';
       
                     
                     
                }
      
            }
            
        }
?>


		<!--广场-->
		<?php
include_once('./aigc.php');
?>



		<!--加载-->
		<div class="loading-wrap">
			<div class="balls">
				<div></div>
				<div></div>
				<div></div>
			</div>
		</div>




		<button style="display:none;" id="inviteBtn" class="btn btn-primary">邀请好友</button>
		<!--邀请-->
		<?php
if(!empty($_GET)){
    if($_GET['id'] == '邀请'){
        require_once('./yaoqinghtml.php');
    }
}
?>



		<?php
require('./tool/kefu.php');
?>



	</body>


	<style>

		.form-control{
            height: unset!important;
            -webkit-box-shadow:unset!important;
    }
    
    .con-right{
        position: relative;
    }
    
    .jzbb{
        background: white;
    }
    
    
    .containersrk{
        position: relative;
    }
    
    @media (min-width: 640px){
        .sjdh{
            display: none;
        }
 
    }
    

.dtsrk {
      padding: 0.7rem 0.5rem;
    line-height: 1.3 !important;
}
</style>

	<script>
		$(function() {
		    setTimeout(function() {
		if (!(isMobile())) {
		  $(".con-right").css("height", 'unset');
		   
		}
		  }, 1);
		
		});
	</script>
	<!--<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>-->
	<!--<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>-->
	<script src="/assets/bootstrap.min.js?id=<?php echo $banbenhao;?>"></script>
	<script src="/js/draw.js?id=<?php echo $banbenhao;?>"></script>
	<script src="/assets/lmhuihua.js?id=<?php echo $banbenhao;?>"></script>
	<script src="/zidingyi.js?id=<?php echo $banbenhao;?>"></script>
	<script src="js/remarkable.js?id=<?php echo $banbenhao;?>"></script>
	<script src="js/jquery.min.js?id=<?php echo $banbenhao;?>"></script>
	<script src="js/jquery.cookie.min.js?id=<?php echo $banbenhao;?>"></script>
	<script src="js/layer.min.js?id=<?php echo $banbenhao;?>" type="application/javascript"></script>
	<script src="js/huihua.js?id=<?php echo $banbenhao;?>"></script>
	<script src="js/highlight.min.js?id=<?php echo $banbenhao;?>"></script>
	<script src="js/showdown.min.js?id=<?php echo $banbenhao;?>"></script>
	<script>
		$(window).on('load', function() {
		        
		       $('.zbsc').css('display','unset');
		       $('.loading-wrap').css('display','none');
		       
		       setTimeout(function() {
		        var lazyImages = $('.huitujz');
		          console.log(lazyImages);
		          for (var i = 0; i < lazyImages.length; i++) {
		            lazyImages[i].src = lazyImages[i].getAttribute('data-src');
		          }
		        }, 100);
		        
		        setTimeout(function() {
		        var lazyImages = $('.huitujz');
		          console.log(lazyImages);
		          for (var i = 0; i < lazyImages.length; i++) {
		            lazyImages[i].src = lazyImages[i].getAttribute('data-src');
		          }
		        }, 2000);
		        
		    });
	</script>
	<?php
include_once('./tool/tongji.php');
?>
	<?php
include_once('./tool/getend.php');
?>
</html>