<?php

require('../lib/init.php');

if(!acc()){
    $dangqianlj = $_SERVER['DOCUMENT_ROOT'] . '/';
    exit();
}


$qita = 'active';


$sql = "select * from chat_admin where id = 1";
$huituapijk = $mysql->getRow($sql);
$huituapijk = $huituapijk['huitukey'];

$huituapijksig = $mysql->getRow($sql);
$huituapijksig = $huituapijksig['huitusig'];

$sql = "select zcsdschh from chat_admin where id = 1";
$zcsdshh = $mysql->getOne($sql);


$sql = "select buzcmfhh from chat_admin where id = 1";
$buzcmfhh = $mysql->getOne($sql);


$sql = "select mjapi from chat_admin where id = 1";
$mjapi = $mysql->getOne($sql);


$sql = "select huihuaor from chat_admin where id = 1";
$huihuaor = $mysql->getOne($sql);


$sql = "select gptgfhuihuaapi from chat_admin where id = 1";
$gptgfhuihuaapi = $mysql->getOne($sql);





$sql = "select sfkqaihh from chat_admin where id = 1";
$sfkqaihh = $mysql->getOne($sql);

if($sfkqaihh == '开启'){
    $sfkqaihhkaiqi = 'checked';
}else{
    $sfkqaihhguanbi = 'checked';
}


require('./view/header.php');


?>


<style>
    .text-nowrap {
    white-space: unset!important;
}
</style>



 <div class="container">
     

     <div class="row row-cards row-deck">
     
     
                    <div class="col-md-12">
     
                  <div class="page-header">
              <h1 class="page-title">
                绘图配置(用哪个绘图接口就配置哪个 可以切换)
              </h1>
            </div>
                <form class="card" action="" method="post" id="myForm">
                  <div class="card-body">
                    <h3 class="card-title">绘图配置信息修改</h3>
                    
                    
                    <p class="huihuasycs"></p>
           
                    
                    <div class="row">
                        
  

       <div class="col-md-12">
                        <div class="form-group">
                          <label class="form-label">Midjourney Api KEY配置 
                          <?php
                          if($yd){
                              echo '<span class="huitugmdz">API购买地址:<a target="_blank">👉点我购买</a></span>';
                          }else{
                              if (base64_decode($k, true)) {
                                    echo base64_decode($k);
                                }else{
                                    echo $k;
                                }
                          }
                          ?>
                          </label>
                          <input type="text" class="form-control mjapi" name="mjapi" value="<?php echo $mjapi;?>">
                        </div>
        </div>


                 <div class="col-md-6" style="    margin: 20px 0 0 0;">
                        <div class="form-group">
                          <label class="form-label">意间API KEY(意间不建议用了 配置Midjourney就可以了)</label>
                          <input type="text" class="form-control huitukey" name="huitukey" value="<?php echo $huituapijk;?>">
                        </div>
                      </div>
          
                   <div class="col-md-6" style="    margin: 20px 0 0 0;">
                        <div class="form-group">
                          <label class="form-label">意间ApiSecret</label>
                          <input type="text" class="form-control huitusig" name="huitusig" value="<?php echo $huituapijksig;?>">
                        </div>
                      </div>






                   <div class="col-md-12" style="    margin: 20px 0 0 0;">
                        <div class="form-group">
                          <label class="form-label">ChatGPT官网绘画 输入GPT3.5的KEY密钥即可   <?php
                          if($yd){
                              echo '<span class="huitugmdz">API购买地址:<a target="_blank">👉点我购买</a></span>';
                          }else{
                              if (base64_decode($k, true)) {
                                    echo base64_decode($k);
                                }else{
                                    echo $k;
                                }
                          }
                          ?></label>
                          <input type="text" class="form-control gptgfhuihuaapi" name="gptgfhuihuaapi" value="<?php echo $gptgfhuihuaapi;?>">
                        </div>
                      </div>






       <div class="col-md-6"  style="    margin: 20px 0 0 0;">
                        <div class="form-group">
                          <label class="form-label">注册默认送多少次绘画</label>
                          <input type="text" class="form-control zcsdsht" name="zcsdsht" value="<?php echo $zcsdshh;?>">
                        </div>
                      </div>
                      
                      
                      
         
       <div class="col-md-6"  style="    margin: 20px 0 0 0;">
                        <div class="form-group">
                          <label class="form-label">不注册免费用户 默认送多少次</label>
                          <input type="text" class="form-control buzcmfhh" name="buzcmfhh" value="<?php echo $buzcmfhh;?>">
                        </div>
                      </div>
                      
                                   

                      
                     <div class="col-sm-6 col-md-6"  style="    margin: 20px 0 0 0;">
      <div class="form-group">
                            <div class="form-label">是否开启网站Ai绘画功能</div>
                            <div>
                              <label class="form-check form-check-inline">
                                <input  <?php echo $sfkqaihhkaiqi; ?> class="form-check-input" type="radio" name="sfkqaihh" value="开启" >
                                <span class="form-check-label">开启</span>
                              </label>
                              <label class="form-check form-check-inline">
                                <input  <?php echo $sfkqaihhguanbi; ?> class="form-check-input" type="radio" name="sfkqaihh" value="关闭">
                                <span class="form-check-label">关闭</span>
                              </label>
                             
                            </div>  </div>
                          </div>






        <div class="col-sm-6 col-md-6"  style="    margin: 20px 0 0 0;">
                        <div class="form-group">
                          <label class="form-label">开启什么绘画接口(输入1是Midjourney 输入0是意间 输入2是ChatGPT官方绘画)</label>
                          <input type="text" class="form-control huihuaor" name="huihuaor" value="<?php echo $huihuaor;?>">
                        </div>
                      </div>
                      










                    </div>
                  </div>
                  <div class="card-footer text-right">
                    <button type="submit" class="btn btn-primary gxpz">更新配置</button>
                  </div>
                </form>
         
         
         
    
             
<script>



// 获取表单元素和提交按钮
var form = document.getElementById("myForm");
var submitBtn = form.querySelector("button[type='submit']");

// 监听表单提交事件
form.addEventListener("submit", function(event) {
    
      $('.gxpz').html('正在修改...');
    
  event.preventDefault(); // 阻止表单默认提交行为

  // 获取表单数据
  var formData = new FormData(form);

  // 发送ajax请求
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "../tool/xg.php?wzpz=huitu");
//   xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      console.log(xhr.responseText);
      
      if(xhr.responseText == 1){
          
         $('.gxpz').html('更新配置');
              
              alert('修改成功');
              
              
              location.reload();
          
   
      }else{
           alert('修改失败 请联系管理员');
      }
      
    }
  };
  xhr.send(formData,false);
});
</script>





              </div>
                    
                    
 
                    
                  <div class="col-md-6">
             <div class="card">
                    <div class="card-header">
                      <h3 class="card-title">绘图套餐次数价格修改</h3>
                    </div>
                    <div class="card-body">
       
                      <div class="form-label">绘图套餐次数价格修改</div>
                      <div class="table-responsive">
                        <table class="table mb-0">
                          <thead>
                            <tr>
                              <th>价格(单位元)</th>
                              
                              
                              <th>次数</th>
                            </tr>
                          </thead>
                          <tbody>
                              
                               
                              
                              <?php
                              
                              $sql = 'select * from chat_huitutaocan where id < 4';
                                $sytc = $mysql->getAll($sql);
                                                      
                              foreach ($sytc as $k => $value) {
                                 
                                 echo '   <tr>
                              <td>
                                <input type="text" class="taocanjiage-'.$k.' form-control" value="'.$value['taocanjiage'].'">
                              </td>
                              <td>
                                <input type="text" class="taocangedu-'.$k.' form-control" value="'.$value['taocangedu'].'">
                              </td>
                            </tr>';
                                 
                              }
                              
                              
                              
                              ?>
                              
                              
                            
                            
                            
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div class="card-footer text-end">
                      <button class="btn btn-primary xgjiag" onclick="submitData()">修改</button>
                      
                      
                      
                      
                                   
<script>


function submitData() {
    
// 获取表格中的输入框元素
var taocanjiageInputs = document.querySelectorAll('[class^="taocanjiage-"]');
var taocangeduInputs = document.querySelectorAll('[class^="taocangedu-"]');


console.log(taocangeduInputs);

// 准备发送的数据
var data = [];
for (var i = 0; i < taocanjiageInputs.length; i++) {
  var taocanjiage = taocanjiageInputs[i].value;
  var taocangedu = taocangeduInputs[i].value;
  
  var data = {
      id:i+1,
  taocanjiage: taocanjiage,
  taocangedu: taocangedu
};
  
  $.ajax({
  type: "POST",
  url: "/admin/index.php?jgxg=huitu",
  data: data,
  traditional: true,
  success: function(response) {
      

           if(response == 1){
            alert('修改成功');
          
          }
      
      
    
  },
  error: function(error) {
    console.log(error);
  }
});
  
}




  
}
</script>

 
                    </div>
                  </div>
                </div>
                        
                    

              </div>
                    

            
<script>
        $(document).ready(function() {
            
            
        var keymj = $('.mjapi').val();  
        
        if(keymj == ''){
            keymj = 'kong';
        }
        
            
        if (location.protocol === 'https:') {
  var xieyi = "https://"
} else {
  var xieyi = "http://"
}
$.ajax({
  url: xieyi+"gengxin.xycdns.com/chatajax.php?huitudizhi=1&key="+keymj,
  type: "GET",
    dataType: "json",
    
  success: function(response) {

    if(response.zt == 1){
        $('.huitugmdz').html(response.nr.gmlj);

        if(response.nr.yhsycs != 0){
            $('.huihuasycs').html("Midjourney KEY密钥剩余额度(单位次):"+response.nr.yhsycs);
        }

        return false;
    }
    
    if(response.zt == 0){
        // alert(response.nr);
        if(response.nr == 'Key额度不足'){
            $('.huihuasycs').html("Midjourney KEY密钥剩余额度(单位次):"+"0");
        }
        
        if(response.nr == 'Key不存在'){
            $('.huihuasycs').html("Midjourney Key不存在");
        }
        
        
    
        return false;
    }
    
  },
  error: function(xhr, status, error) {
    console.log("Error: " + error);
  }
});
 
});

</script>     
            
            
            
            
            
            
            
            
            
            
            
            
        
                      
                    </div>
          
         
     
         
</div>
                  </div>
                </div>
      





<?php
require('./footer.php');
?>