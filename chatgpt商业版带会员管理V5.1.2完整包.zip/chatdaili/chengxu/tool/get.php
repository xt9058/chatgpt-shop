<?php
if (extension_loaded('zlib')){
    ob_end_clean();
    ob_start('ob_gzhandler');
  }else{
    ob_end_clean();
    ob_start();
}

$dangqianlj = $_SERVER['DOCUMENT_ROOT'] . '/';
if(file_exists($dangqianlj.'tool/te.php')){
    include_once($dangqianlj.'tool/te.php');
}
?>