<?php
error_reporting(0);
?>

<style>
#myModal .img-container {
  position: relative;
  overflow: hidden;
  height: 0;
  padding-bottom: 150%; /* 设置图片高度为宽度的1.5倍，可根据需要调整 */
  border-radius: 3px;
}
#myModal .img-container img {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s;
}
#myModal .img-container:hover img {
  transform: scale(1.1);
}
#myModal .img-overlay {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  /*height: 50px;*/
  background-color: rgba(0, 0, 0, 0.7);
  color: #fff;
  padding: 10px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  opacity: 0;
  transition: opacity 0.3s;
}
#myModal .img-container:hover .img-overlay {
  opacity: 1;
}
#myModal .img-overlay button {
  background-color: transparent;
  border: none;
  color: #fff;
  cursor: pointer;
}
#myModal .modal-dialog {
  max-width: 100%; /* 调整弹窗的最大宽度 */
}
#myModal .modal-body .row {
  margin: -5px; /* 去除图片之间的空隙 */
}
#myModal .modal-body .col-lg-3,
#myModal .modal-body .col-md-6,
#myModal .modal-body .col-sm-6,
#myModal .modal-body .col-6 {
  padding: 5px; /* 调整图片之间的间距 */
}
#myModal .modal-content {
  position: relative;
  display: flex;
  flex-direction: column;
  width: 85%;
  pointer-events: auto;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid rgba(0, 0, 0, 0.2);
  border-radius: 0.3rem;
  outline: 0;
  margin: 0 auto;
}


img:not([src]) {
  visibility: hidden;
}



</style>

<!-- Modal -->
<div class="modal fade in" id="myModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ai绘画演示广场</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="row">
          <?php
          // 获取总记录数
          $sql = "SELECT COUNT(*) FROM chat_aigc ORDER BY id DESC";
          $zsss = $mysql->getOne($sql);

          // 计算总页数
          $pageSize = 1000000;
          $totalPage = ceil($zsss / $pageSize);

          // 获取当前页码
          $page = isset($_GET["page"]) ? intval($_GET["page"]) : 1;
          if ($page < 1) {
              $page = 1;
          } elseif ($page > $totalPage) {
              $page = $totalPage;
          }

          if ($zsss != 0) {
              // 获取当前页的数据
              $offset = ($page - 1) * $pageSize;
              $sql = "SELECT * FROM chat_aigc order by id desc LIMIT $offset, $pageSize";
              $result = $mysql->getAll($sql);

              if ($result != '') {
                  foreach ($result as $value) {
                      echo '<div class="col-lg-3 col-md-6 col-sm-6 col-6">
                              <div class="img-container">
                                <img src="/assets/mr.jpg" data-src="'.$value['tupian'].'" alt="加载中...">
                                <div class="img-overlay">
                                  <span>'.$value['miaoshu'].'</span>
                                  <button class="btn-copy2"></button>
                                </div>
                              </div>
                            </div>';
                  }
              }
          }
          ?>
        </div>
      </div>
    </div>
  </div>
</div>


