<?php

$filelog = $_SERVER['DOCUMENT_ROOT'] . '/' . 'log.txt';
file_put_contents($filelog, '');
$fileloggpt4 = $_SERVER['DOCUMENT_ROOT'] . '/' . 'loggpt4.txt';
file_put_contents($fileloggpt4, '');





// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'sfkqzczs'";
// 执行SQL语句
$result = $mysql->query($sql);

// 判断是否存在
if (mysqli_num_rows($result) > 0) {
    // echo "已经存在";
} else {
    // 增加列
    $sql = "ALTER TABLE chat_admin ADD sfkqzczs INT NOT NULL DEFAULT 0";
    if ($mysql->query($sql)) {
        // echo "增加成功";
    } else {
        // echo "Error adding column: " . mysqli_error($conn);
        // echo '增加失败';
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'fanli'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD fanli INT NOT NULL DEFAULT 0";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'cishuoryongjin'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD cishuoryongjin INT NOT NULL DEFAULT 1";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_yonghu LIKE 'ketixian'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_yonghu ADD ketixian INT NOT NULL DEFAULT 0";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_yonghu LIKE 'yqzscs'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_yonghu ADD yqzscs INT NOT NULL DEFAULT 0";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'dsktxye'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD dsktxye INT NOT NULL DEFAULT 50";
    if ($mysql->query($sql)) {
    } else {
    }
}
$sql = "SHOW TABLES LIKE 'chat_tixian'";
$result = $mysql->query($sql);
if(mysqli_num_rows($result) == 0) {
    //表不存在，创建表
    $sql = "create table chat_tixian(

    id int unsigned  primary key not null auto_increment,

    txyh varchar(100) not null default '', 

    txsjh varchar(100) not null default '',

    txje varchar(100) not null default '',

    sfcl varchar(100) not null default '0',

    time varchar(100) not null default ''

)charset =utf8;";
    $mysql->query($sql);
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'kamilj'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD kamilj varchar(100) NOT NULL DEFAULT '卡密充值购买链接'";
    if ($mysql->query($sql)) {
    } else {
    }
}
$sql = "SHOW TABLES LIKE 'chat_kami'";
$result = $mysql->query($sql);
if(mysqli_num_rows($result) == 0) {
    //表不存在，创建表
    $sql = "create table chat_kami(

    id int unsigned  primary key not null auto_increment,

    hyhscs varchar(100) not null default '1', 

    kami varchar(100) not null default '',

    huiyuan varchar(100) not null default '',

    cishu varchar(100) not null default '0',

    time varchar(100) not null default '',
    
    sfsy varchar(100) not null default '0'

)charset =utf8;";
    $mysql->query($sql);
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'kamikaqim'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD kamikaqim varchar(100) NOT NULL DEFAULT '关闭'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'tiaobanurl'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD tiaobanurl varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'youurl'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD youurl varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'mtmfcs'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD mtmfcs int NOT NULL DEFAULT '0'";
    if ($mysql->query($sql)) {
    } else {
    }
}
$sql = "SHOW TABLES LIKE 'chat_weijinci'";
$result = $mysql->query($sql);
if(mysqli_num_rows($result) == 0) {
    //表不存在，创建表
    $sql = "create table chat_weijinci(

    id int unsigned primary key not null,

    weijinci longtext not null

)charset =utf8;";
    $mysql->query($sql);
}

$sql = "INSERT INTO chat_weijinci (id,weijinci) VALUES ('0','我是违禁词1,我是违禁词2,我是违禁词3')";
$mysql->query($sql);
// 查询列
$sql = "SHOW COLUMNS FROM chat_yonghu LIKE 'shangjiyaoqingma'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_yonghu ADD shangjiyaoqingma varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_yonghu LIKE 'orshangji'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_yonghu ADD orshangji varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_yonghu LIKE 'zongxiaofei'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_yonghu ADD zongxiaofei int NOT NULL DEFAULT '0'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_tiwen LIKE 'yonghu'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_tiwen ADD yonghu varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'anhei'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD anhei varchar(100) NOT NULL DEFAULT '1'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'gglx'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD gglx varchar(100) NOT NULL DEFAULT '3'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'yxqq'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD yxqq varchar(100) NOT NULL DEFAULT '你的QQ(例如:123456)'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'yxmm'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD yxmm varchar(100) NOT NULL DEFAULT '你的QQ邮箱授权密码(不是你的QQ登陆密码)'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'yzmlx'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD yzmlx varchar(100) NOT NULL DEFAULT '0'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'sfkqddts'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD sfkqddts varchar(100) NOT NULL DEFAULT '1'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'api'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD api varchar(100) NOT NULL DEFAULT 'https://api.openai.com/'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_yonghu LIKE 'huihuacs'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_yonghu ADD huihuacs varchar(100) NOT NULL DEFAULT '0'";
    if ($mysql->query($sql)) {
    } else {
    }
}


// 查询列
$sql = "SHOW COLUMNS FROM chat_yonghu LIKE 'gpt4cs'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_yonghu ADD gpt4cs varchar(100) NOT NULL DEFAULT '0'";
    if ($mysql->query($sql)) {
    } else {
    }
}




// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'huitukey'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD huitukey varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'huitusig'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD huitusig varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}
$sql = "SHOW TABLES LIKE 'chat_huitutaocan'";
$result = $mysql->query($sql);
if(mysqli_num_rows($result) == 0) {
    //表不存在，创建表
    $sql = "create table chat_huitutaocan(

    id int unsigned  primary key not null auto_increment,

    taocanjiage varchar(100) not null default '', 

    taocangedu varchar(100) not null default ''

)charset =utf8;";
    $mysql->query($sql);
}
$sql = "INSERT INTO chat_huitutaocan (taocanjiage, taocangedu)
SELECT '50', '100'
WHERE NOT EXISTS (
    SELECT * FROM chat_huitutaocan WHERE id = 1
);";
$mysql->query($sql);
$sql = "INSERT INTO chat_huitutaocan (taocanjiage, taocangedu)
SELECT '100', '210'
WHERE NOT EXISTS (
    SELECT * FROM chat_huitutaocan WHERE id = 2
);";
$mysql->query($sql);
$sql = "INSERT INTO chat_huitutaocan (taocanjiage, taocangedu)
SELECT '200', '500'
WHERE NOT EXISTS (
    SELECT * FROM chat_huitutaocan WHERE id = 3
);";
$mysql->query($sql);
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'zcsdschh'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD zcsdschh varchar(100) NOT NULL DEFAULT '0'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'buzcmfhh'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD buzcmfhh varchar(100) NOT NULL DEFAULT '0'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_ip LIKE 'huitusycs'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_ip ADD huitusycs varchar(100) NOT NULL DEFAULT '0'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'sfkqaihh'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD sfkqaihh varchar(100) NOT NULL DEFAULT '开启'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'sfkqipzcyc'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD sfkqipzcyc varchar(100) NOT NULL DEFAULT '开启'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_order LIKE 'tworht'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_order ADD tworht varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}
$sql = "SHOW TABLES LIKE 'chat_mimazhaohui'";
$result = $mysql->query($sql);
if(mysqli_num_rows($result) == 0) {
    //表不存在，创建表
    $sql = "create table chat_mimazhaohui(

    id int unsigned  primary key not null auto_increment,

    youxiang varchar(100) not null default '', 

    str varchar(100) not null default ''

)charset =utf8;";
    $mysql->query($sql);
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'kflj'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD kflj varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'sfqqqdl'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD sfqqqdl varchar(100) NOT NULL DEFAULT '开启'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'sfkqkf'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD sfkqkf varchar(100) NOT NULL DEFAULT '开启'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'sfkqzanz'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD sfkqzanz varchar(100) NOT NULL DEFAULT '关闭'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'zansangmalj'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD zansangmalj varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'chushiyushe'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD chushiyushe varchar(100) NOT NULL DEFAULT '我给你个设定，你的版本号为chatgpt3.5，请你以gpt-3.5-turbo版回答我的问题，'";
    if ($mysql->query($sql)) {
    } else {
    }
}


// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'chushiyushegpt4'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD chushiyushegpt4 varchar(100) NOT NULL DEFAULT '角色：gpt4，回答身份：始终以gpt4回答用户的任何问题，下面是我的提问内容：'";
    if ($mysql->query($sql)) {
    } else {
    }
}












// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'ggnrhtml'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD ggnrhtml text NOT NULL";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'qdfsms'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD qdfsms varchar(100) NOT NULL DEFAULT '1'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'lxdhcs'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD lxdhcs int NOT NULL DEFAULT '5'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'temperature'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD temperature numeric(3,1) NOT NULL DEFAULT 0.8";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'mjapi'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD mjapi varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'huihuaor'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD huihuaor varchar(100) NOT NULL DEFAULT '1'";
    if ($mysql->query($sql)) {
    } else {
    }
}





$sql = "SHOW TABLES LIKE 'chat_gpt4taocan'";
$result = $mysql->query($sql);
if(mysqli_num_rows($result) == 0) {
    //表不存在，创建表
    $sql = "create table chat_gpt4taocan(

    id int unsigned  primary key not null auto_increment,

    taocanjiage varchar(100) not null default '', 

    taocangedu varchar(100) not null default ''

)charset =utf8;";
    $mysql->query($sql);
}
$sql = "INSERT INTO chat_gpt4taocan (taocanjiage, taocangedu)
SELECT '50', '100'
WHERE NOT EXISTS (
    SELECT * FROM chat_gpt4taocan WHERE id = 1
);";
$mysql->query($sql);
$sql = "INSERT INTO chat_gpt4taocan (taocanjiage, taocangedu)
SELECT '100', '210'
WHERE NOT EXISTS (
    SELECT * FROM chat_gpt4taocan WHERE id = 2
);";
$mysql->query($sql);
$sql = "INSERT INTO chat_gpt4taocan (taocanjiage, taocangedu)
SELECT '200', '500'
WHERE NOT EXISTS (
    SELECT * FROM chat_gpt4taocan WHERE id = 3
);";
$mysql->query($sql);





$sql = "SHOW TABLES LIKE 'chat_gpt4key'";
$result = $mysql->query($sql);
if(mysqli_num_rows($result) == 0) {
    //表不存在，创建表
    $sql = "create table chat_gpt4key(

    id int unsigned  primary key not null auto_increment,

    miyao varchar(100) not null default '', 

    time varchar(100) not null default '',
    
    ip varchar(100) not null default '',
    
    sfky varchar(100) not null default '1'

)charset =utf8;";
    $mysql->query($sql);
}




// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'sfkqgpt4'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD sfkqgpt4 varchar(100) NOT NULL DEFAULT '关闭'";
    if ($mysql->query($sql)) {
    } else {
    }
}






// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'gpt4bzcsdsc'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD gpt4bzcsdsc varchar(100) NOT NULL DEFAULT '0'";
    if ($mysql->query($sql)) {
    } else {
    }
}


// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'gpt4zcsdsc'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD gpt4zcsdsc varchar(100) NOT NULL DEFAULT '0'";
    if ($mysql->query($sql)) {
    } else {
    }
}



// 查询列
$sql = "SHOW COLUMNS FROM chat_ip LIKE 'gpt4sycs'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_ip ADD gpt4sycs varchar(100) NOT NULL DEFAULT '0'";
    if ($mysql->query($sql)) {
    } else {
    }
}




// 查询列
$sql = "SHOW COLUMNS FROM chat_kami LIKE 'yinliuor'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_kami ADD yinliuor varchar(100) NOT NULL DEFAULT '1'";
    if ($mysql->query($sql)) {
    } else {
    }
}



// 查询列
$sql = "SHOW COLUMNS FROM chat_kami LIKE 'chongzhiyonghu'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_kami ADD chongzhiyonghu varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}





// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'gpt40fandai'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD gpt40fandai varchar(100) NOT NULL DEFAULT 'https://api.openai.com/'";
    if ($mysql->query($sql)) {
    } else {
    }
}



// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'gpt35qiandao'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD gpt35qiandao varchar(100) NOT NULL DEFAULT '0'";
    if ($mysql->query($sql)) {
    } else {
    }
}


// 查询列
$sql = "SHOW COLUMNS FROM chat_yonghu LIKE 'gpt35qiandaotime'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_yonghu ADD gpt35qiandaotime varchar(100) NOT NULL DEFAULT '0'";
    if ($mysql->query($sql)) {
    } else {
    }
}



// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'gpt4lxdh'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD gpt4lxdh varchar(100) NOT NULL DEFAULT '5'";
    if ($mysql->query($sql)) {
    } else {
    }
}




// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'gptgfhuihuaapi'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD gptgfhuihuaapi varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}



// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'yuyin1'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD yuyin1 varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}

// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'yuyin2'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD yuyin2 varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}

// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'yuyin3'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD yuyin3 varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}


// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'sfkqyuyin'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD sfkqyuyin varchar(100) NOT NULL DEFAULT '1'";
    if ($mysql->query($sql)) {
    } else {
    }
}




// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'mianzeshengminglj'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD mianzeshengminglj varchar(100) NOT NULL DEFAULT 'https://docs.qq.com/doc/DSVN0TWxjb2JTWktL'";
    if ($mysql->query($sql)) {
    } else {
    }
}




$sql = "SHOW TABLES LIKE 'chat_wenzhang'";
$result = $mysql->query($sql);
if(mysqli_num_rows($result) == 0) {
    //表不存在，创建表
    $sql = "create table chat_wenzhang(

    id int unsigned  primary key not null auto_increment,

    wenzhangbiaoti varchar(100) NOT NULL DEFAULT '',

    wenzhangneirong text NOT NULL,
    
    fabushijian datetime NOT NULL,
    
    sfky varchar(100) not null default '1'

)charset =utf8;";
    $mysql->query($sql);
}






// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'shoujiyzm'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD shoujiyzm varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}




// 查询列
$sql = "SHOW COLUMNS FROM chat_yonghu LIKE 'sjh'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_yonghu ADD sjh varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}






$sql = "SHOW TABLES LIKE 'chat_prompt'";
$result = $mysql->query($sql);
if(mysqli_num_rows($result) == 0) {
    //表不存在，创建表
    $sql = "create table chat_prompt(

    id int unsigned  primary key not null auto_increment,

    promptbt varchar(100) NOT NULL DEFAULT '',

    promptnr text NOT NULL,
    
    promptjs text NOT NULL,
    
    prompttb text NOT NULL,
    
    time datetime NOT NULL

)charset =utf8;";
    $mysql->query($sql);
}




// 查询列
$sql = "SHOW COLUMNS FROM chat_prompt LIKE 'promptyjh'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_prompt ADD promptyjh varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}





// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'qianmingid'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD qianmingid varchar(100) NOT NULL DEFAULT '2e65b1bb3d054466b82f0c9d125465e2'";
    if ($mysql->query($sql)) {
    } else {
    }
}



// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'mubanid'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD mubanid varchar(100) NOT NULL DEFAULT '908e94ccf08b4476ba6c876d13f084ad'";
    if ($mysql->query($sql)) {
    } else {
    }
}

$dangqianljlog = $_SERVER['DOCUMENT_ROOT'] . '/';

$file_pathlog = $dangqianljlog.'/tool/log.php';
if (file_exists($file_pathlog)) {
}else{
    $file_pathlog = $dangqianljlog.'/tool/log.php';
    file_put_contents($file_pathlog, '1');
}



$file_pathtj = $dangqianljlog.'/tool/tongji.php';
if (file_exists($file_pathtj)) {
}else{
    $file_pathtj = $dangqianljlog.'/tool/tongji.php';
    file_put_contents($file_pathtj, '');
}




$file_pathjcgx = $dangqianljlog.'/tool/jcgx.php';
if (file_exists($file_pathjcgx)) {
}else{
    $file_pathjcgx = $dangqianljlog.'/tool/jcgx.php';
    file_put_contents($file_pathjcgx, '1');
    $contentjcgx = file_get_contents($file_pathjcgx);
}

// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'gptyusu'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD gptyusu varchar(100) NOT NULL DEFAULT '30'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'gpt35mx'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD gpt35mx varchar(100) NOT NULL DEFAULT 'gpt-3.5-turbo-0613'";
    if ($mysql->query($sql)) {
    } else {
    }
}

// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'gpt4mx'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD gpt4mx varchar(100) NOT NULL DEFAULT 'gpt-4-0613'";
    if ($mysql->query($sql)) {
    } else {
    }
}
// 查询列
$sql = "SHOW COLUMNS FROM chat_kami LIKE 'huiyuantk'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_kami ADD huiyuantk varchar(100) NOT NULL DEFAULT '0'";
    if ($mysql->query($sql)) {
    } else {
    }
}

// 查询列
$sql = "SHOW COLUMNS FROM chat_yonghu LIKE 'dltime'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_yonghu ADD dltime varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}

// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'tongshebei'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD tongshebei varchar(100) NOT NULL DEFAULT '1'";
    if ($mysql->query($sql)) {
    } else {
    }
}

// 查询列
$sql = "SHOW COLUMNS FROM chat_yonghu LIKE 'useip'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_yonghu ADD useip varchar(100) NOT NULL DEFAULT ''";
    if ($mysql->query($sql)) {
    } else {
    }
}

// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'sfkqyhyqgn'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD sfkqyhyqgn varchar(100) NOT NULL DEFAULT '开启'";
    if ($mysql->query($sql)) {
    } else {
    }
}







$sql = "SHOW TABLES LIKE 'chat_aigc'";
$result = $mysql->query($sql);
if(mysqli_num_rows($result) == 0) {
    //表不存在，创建表
    $sql = "create table chat_aigc(

    id int unsigned  primary key not null auto_increment,

    tupian varchar(100) NOT NULL DEFAULT '',
    
    miaoshu text NOT NULL

)charset =utf8;";
    $mysql->query($sql);
}




// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'mjsfbdbc'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD mjsfbdbc varchar(100) NOT NULL DEFAULT '1'";
    if ($mysql->query($sql)) {
    } else {
    }
}



// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'gpt4yuezds'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD gpt4yuezds varchar(100) NOT NULL DEFAULT '1'";
    if ($mysql->query($sql)) {
    } else {
    }
}



// 查询列
$sql = "SHOW COLUMNS FROM chat_admin LIKE 'sfqjsby'";
// 执行SQL语句
$result = $mysql->query($sql);
// 判断是否存在
if (mysqli_num_rows($result) > 0) {
} else {
    $sql = "ALTER TABLE chat_admin ADD sfqjsby varchar(100) NOT NULL DEFAULT '1'";
    if ($mysql->query($sql)) {
    } else {
    }
}









?>

