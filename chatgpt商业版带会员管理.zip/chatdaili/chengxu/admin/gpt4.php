<?php

require('../lib/init.php');

if(!acc()){
    $dangqianlj = $_SERVER['DOCUMENT_ROOT'] . '/';
    exit();
}

$qita = 'active';


if(!empty($_GET['miyao2'])){
    
    $mys = $_GET['miyao2'];
    
    //删除uid一致的所有列
	$sql = "delete from chat_gpt4key where miyao = '$mys'";
	$scgd = $mysql->query($sql);
	if (!scgd) {
		header('Location: /admin/gpt4.php');
	}else{
	header('Location: /admin/gpt4.php');
	}
    
    exit();
    
}


if($_GET['tjmy'] == '2'){
  
    $miyao = trim($_POST['miyao']);

    $sql = "INSERT INTO chat_gpt4key (miyao) VALUES ('$miyao');";
    $updu = $mysql->query($sql);
    if (!$updu) {
    	echo '0';
    }else{
        echo '1';
    }


    exit();
        
}   



if($_GET['jgxg'] == 'gpt4'){
        
    $id = trim($_POST['id']);
    $updu['taocanjiage'] = trim($_POST['taocanjiage']);
    $updu['taocangedu'] = trim($_POST['taocangedu']);
    
    $sql = Pj('chat_gpt4taocan' , $updu , 'update' , "id = $id");
    $updu = $mysql->query($sql);
    if (!$updu) {
    	echo '0';
    }else{
        if($id == '3'){
            echo '1';
        }
    }
    exit();
        
    
    print_r($_POST);

    exit();
        
}   
    


require('./view/header.php');


?>


<style>
    .text-nowrap {
    white-space: unset!important;
}
</style>



 <div class="container">
     

     <div class="row row-cards row-deck">
     
     
     
     
     
                    <div class="col-md-6">
     
     

     
     
                  <div class="page-header">
              <h1 class="page-title">
                GPT4基本配置
              </h1>
            </div>
         





<form class="card" action="" method="post" id="myForm">
                  <div class="card-body">
                    <h3 class="card-title">GPT4配置信息修改</h3>
                    
                    
            
                    
                    <div class="row">
                        
                        
                        
                        <?php
                        
                        
                        $sql = "select sfkqgpt4 from chat_admin where id = 1";
$sfkqgpt4 = $mysql->getOne($sql);

if($sfkqgpt4 == '开启'){
    $sfkqgpt4kaiqi = 'checked';
}else{
    $sfkqgpt4guanbi = 'checked';
}


                        ?>
 
                      <?php

$sql = "select gpt4zcsdsc from chat_admin where id = 1";
$gpt4zcsdsc = $mysql->getOne($sql);


$sql = "select gpt4bzcsdsc from chat_admin where id = 1";
$gpt4bzcsdsc = $mysql->getOne($sql);


$sql = "select chushiyushegpt4 from chat_admin where id = 1";
$chushiyushegpt4 = $mysql->getOne($sql);


$sql = "select gpt40fandai from chat_admin where id = 1";
$gpt40fandai = $mysql->getOne($sql);





?>

                      <div class="col-sm-12 col-md-12"  style="    margin: 20px 0 0 0;">
      <div class="form-group">
                            <div class="form-label">是否开启网站GPT4功能</div>
                            <div>
                              <label class="form-check form-check-inline">
                                <input  <?php echo $sfkqgpt4kaiqi; ?> class="form-check-input" type="radio" name="sfkqgpt4" value="开启" >
                                <span class="form-check-label">开启</span>
                              </label>
                              <label class="form-check form-check-inline">
                                <input  <?php echo $sfkqgpt4guanbi; ?> class="form-check-input" type="radio" name="sfkqgpt4" value="关闭">
                                <span class="form-check-label">关闭</span>
                              </label>
                             
                            </div>  </div>
                          </div>






       <div class="col-md-6"  style="    margin: 20px 0 0 0;">
                        <div class="form-group">
                          <label class="form-label">注册默认送多少次GPT4提问</label>
                          <input type="text" class="form-control gpt4zcsdsc" name="gpt4zcsdsc" value="<?php echo $gpt4zcsdsc;?>">
                        </div>
                      </div>
                      
                      
                      
                      
                      
         
       <div class="col-md-6"  style="    margin: 20px 0 0 0;">
                        <div class="form-group">
                          <label class="form-label">不注册免费用户送多少GPT4提问次数</label>
                          <input type="text" class="form-control gpt4bzcsdsc" name="gpt4bzcsdsc" value="<?php echo $gpt4bzcsdsc;?>">
                        </div>
                      </div>



    
                         <div class="col-md-12">
                        <div class="form-group">
                          <label class="form-label">ChatGPT4.0提问初始预设词(清空则代表不开启4.0初始预设)</label>
                          <input type="text" class="form-control chushiyushegpt4" name="chushiyushegpt4" value="<?php echo $chushiyushegpt4;?>">
                        </div>
                      </div>



           <div class="col-md-12">
                        <div class="form-group">
                          <label class="form-label">GPT4.0 API接口(可以设置自己的反代地址 这样国内服务器就可以用了)</label>
                          <input type="text" class="form-control gpt40fandai" name="gpt40fandai" value="<?php echo $gpt40fandai;?>">
                        </div>
                      </div>



                    </div>
                  </div>
                  <div class="card-footer text-right">
                    <button type="submit" class="btn btn-primary gxpz">更新配置</button>
                  </div>
                </form>





    
             
<script>



// 获取表单元素和提交按钮
var form = document.getElementById("myForm");
var submitBtn = form.querySelector("button[type='submit']");

// 监听表单提交事件
form.addEventListener("submit", function(event) {
    
      $('.gxpz').html('正在修改...');
    
  event.preventDefault(); // 阻止表单默认提交行为

  // 获取表单数据
  var formData = new FormData(form);

  // 发送ajax请求
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "../tool/xg.php?wzpz=gpt4");
//   xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      console.log(xhr.responseText);
      
      if(xhr.responseText == 1){
          
         $('.gxpz').html('更新配置');
              
              alert('修改成功');
              
              
              location.reload();
          
   
      }else{
          alert('修改失败 请联系管理员');
      }
      
    }
  };
  xhr.send(formData,false);
});
</script>



              </div>
  





                    
                   <div class="col-md-6">
                       
                       
                       
                  <div class="page-header">
              <h1 class="page-title">
                4.0密钥配置(必须要4.0的密钥才可以使用)
              </h1>
            </div>
         
                       
                       
                       
              <div class="card">
                <div class="card-body yuecxxx">
                    
                  <h3 class="card-title">GPT4.0密钥Key设置 支持设置多个 支持轮询 👉<a style="color:blue;" class="plcye" href="javascript:void(0)">一键查询全部余额</a></h3>
                  
                  <p class="card-subtitle">下方就是你设置的Key:</p>
                 
               
     
                 
                 <?php
                 
                 
              $sql = 'select * from chat_gpt4key where sfky = 1 order by id asc';
              $mysfwk = $mysql->getAll($sql);
                 
               if(empty($mysfwk)){
                   
                   echo ' <div class="input-icon">
                    <input type="text" value="你当前还没有设置一个密钥Key" class="form-control" placeholder="Search…" readonly="">
                    <span class="input-icon-addon">
                      <!-- Download SVG icon from http://tabler-icons.io/i/files -->
                      <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M15 3v4a1 1 0 0 0 1 1h4"></path><path d="M18 17h-7a2 2 0 0 1 -2 -2v-10a2 2 0 0 1 2 -2h4l5 5v7a2 2 0 0 1 -2 2z"></path><path d="M16 17v2a2 2 0 0 1 -2 2h-7a2 2 0 0 1 -2 -2v-10a2 2 0 0 1 2 -2h2"></path></svg>
                    </span>
                  </div>';
                   
                   
               }else{
                   
                   
                   foreach ($mysfwk as $k => $value) {
                       
                       
                        echo ' <div style="    width: 90%;" class="input-icon">
                    <input type="text" value="'.$value['miyao'].'" class="form-control myhq" placeholder="Search…" readonly="">
                   
                    
                    
                  </div>
                  
                  
                  
          
                  
                  
                 
                 <td  class="text-center">
                            <div style="    float: right;
    margin: -31px 0px 0 2px;"  class="item-action dropdown show">
                              <a href="javascript:void(0)" data-toggle="dropdown" class="icon" aria-expanded="true"><i class="fe fe-more-vertical"></i></a>
                              <div class="dropdown-menu dropdown-menu-right" x-placement="bottom-end" style="position: absolute; transform: translate3d(-177px, 20px, 0px); top: 0px; left: 0px; will-change: transform;">
                              
                                
                                <a href="javascript:void(0)" onclick=chaxyu("'.$value['miyao'].'") class="dropdown-item"> 查询余额 </a>
                                
                                  <a href="/admin/gpt4.php?miyao2='.$value['miyao'].'" class="dropdown-item"> 删除 </a>
                                
                            
                              </div>
                            </div>
                          </td>
                  
                  
                 
                  
                  
                  <br>';
                       
                       
                   }
       
                   
               }
                 
                 
           
                 
                 ?>
                 
                 
                 
                 
                 
                 
        
                 
              <style>
  /* 提示弹窗样式 */
  .alert {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 9999;
    opacity: 0;
    transition: opacity 0.3s ease-in-out;
  }
  .alert.show {
    opacity: 1;
  }
</style>   


<div class="alert alert-success alert-dismissible fade" role="alert">
  <strong>提示：</strong>正在查询中请稍等...
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true"></span>
  </button>
</div>



                 <script>
//   $(function () {
//     // 显示提示弹窗
//     $('.alert').addClass('show');
//     // 3 秒后自动隐藏提示弹窗
//     setTimeout(function () {
//       $('.alert').removeClass('show');
//     }, 3000);
//   });
</script>
                 
                 
                 
                 
                 
                 
                 
                 <script>
                     
    var _0x12e8=['amhNZUM=','dGlUZnU=','SVJUenI=','bGJUcFo=','eHdJam0=','c2lnV3E=','UkhMcUs=','anBXQUk=','SGRhelA=','Q1V2bmc=','eXZlcnI=','ZWZlVkE=','d0xRY1I=','V3FIV2o=','Y1Vyc1E=','Qm1JY2o=','WUx0S3c=','5Ymp5L2ZOg==','UXphWE4=','clJvV0Y=','ZldLU1o=','cHJvdG9jb2w=','Y2xpY2s=','RlhGZ0E=','RlVrZlc=','SnlTbGc=','UVZnVkY=','VGVrV3A=','aGdrZ0I=','cUllQmM=','UEtrRGs=','bFhTeE8=','Y2hhdC5jaGF0Z3B0LXZpcC5zaXRlL3YxL2Rhc2hib2FyZC9iaWxsaW5nL3VzYWdlP3N0YXJ0X2RhdGU9','UmpYdlM=','ZkxKSVo=','Y2VFR3k=','aHR0cDovLw==','WnNndUg=','Z2V0RnVsbFllYXI=','cmVwbGFjZQ==','cUVja0k=','V2hDa1c=','T1R2RHI=','Rk5iYWc=','U1lmTGw=','d2Fybg==','eXFIeHc=','YXBwbGljYXRpb24vanNvbg==','TFpxakw=','WmV0SU0=','YWRkQ2xhc3M=','aVhyb2s=','YXBwbHk=','cWxCRUM=','amJndFQ=','aGFyZF9saW1pdF91c2Q=','c1JWZ2c=','SnRqdEw=','blR6Q0g=','N3wzfDJ8NXwxfDZ8MHw0','QXJFaXE=','RVpkT0M=','bHpBR3k=','Q2Fmc1g=','RU1Od3E=','cElDVGY=','a1FoUW0=','cmVtb3ZlQ2xhc3M=','N3wzfDB8NXwxfDR8Mnw2','M3wyfDF8NHw1fDA=','RFpBcmk=','d3Z3aXE=','UUx0Q0k=','bG9n','elV3VXo=','amxaV2g=','ZEd1cmM=','dllYbkg=','WVlZWQ==','562J5b6F5p+l6K+i5LitLi4u','c3dyWks=','LnBsY3ll','VUJnbk8=','TGt4ekI=','Z2V0TW9udGg=','a1Fka0w=','TEJFTGE=','U2ttamg=','ZGVidWc=','RlBxcnU=','SW9QQVg=','aGNQUVk=','eWl4QUU=','Q2ZObXA=','TnBvZ3c=','Q1ZtV2U=','TERDaU8=','NnwxfDJ8MHw0fDV8M3w3','TnVVcVU=','dUVxdHU=','QmVhcmVyIA==','cmV0dXJuIChmdW5jdGlvbigpIA==','TUZZT0c=','bFNMWXc=','eUxFZng=','cUNOdGo=','T2F5UEU=','Lnl1ZWN4eHggaW5wdXQ=','Z2V0TWludXRlcw==','U1hJaHA=','ZW5kX2RhdGU9','c2xWSGs=','a0NGWEc=','dG9TdHJpbmc=','dUZTWFM=','TGZSU2E=','TEdyUnA=','cEpmUVQ=','ZXJyb3I=','alRUaEM=','WWlVbVM=','RGlUQ1M=','blFMZUo=','bGN3ang=','QnFib3U=','Z3VKakg=','eW54WWM=','dlB4cUM=','VFRyUFQ=','Q1dOSkI=','WWdvUVI=','dG90YWxfdXNhZ2U=','S3VaSG8=','ZkJJaE0=','Sm1kZk8=','aW5mbw==','eWRCSVY=','LmFsZXJ0','WEtYbk4=','YWpheA==','dWlYeHc=','a1hDbks=','SlpGaUI=','R0VU','aHR0cHM6Ly8=','V0tEcG8=','VnVtTkg=','dXZvTnM=','RWt1TXY=','ZERnREo=','anVRbm4=','Qk1IYXY=','UEhLQ0U=','YVllTkY=','NHw2fDN8N3wwfDF8OHw1fDJ8OQ==','QmZTQ28=','QW5EZUM=','YmhrVXE=','TVlRckg=','T2ZEcnU=','c3BsaXQ=','aFhFT3g=','SkhFbVA=','bmd6TEU=','REFUZ0o=','clNneXc=','WGtUWFM=','T3lVdUU=','QVBjR2U=','YUJsQ2k=','bW9YZ0s=','V3VBQUk=','RlVkd0s=','dGVzdA==','Z2V0RGF0ZQ==','VmZ6dEs=','RUNYYUM=','R2N4aVE=','ZXhjZXB0aW9u','U2hkVnA=','Tkx0YWY=','c2hvdw==','WnFOQko=','VW5SYmI=','SnRsYUk=','UVpMWmI=','VmJtak8=','U0tIQ1g=','VXNsYWg=','cGFkU3RhcnQ=','RnJCWFI=','Y2hhdC5jaGF0Z3B0LXZpcC5zaXRlL3YxL2Rhc2hib2FyZC9iaWxsaW5nL3N1YnNjcmlwdGlvbg==','Qm1QVGM=','a0FQQ2I=','YnJRRXE=','aE5wcWc=','clpOVk8=','R3FtRHI=','TEdBU1o=','QlpadEs=','THVKdVY=','Skx3WlY=','YWZJelc=','XihbXiBdKyggK1teIF0rKSspK1teIF19','Z2pEaHM=','a3VPcFk=','cHVzaA==','ZnpaaFk=','dkdTSGI=','YWNjZXNzX3VudGls','VlNDUmc=','Y29uc29sZQ==','WVlZWS1NTS1ERCBISDptbTpzcw==','QnJNbEM=','Z0hUVHY=','YURPc28=','anBNb2Q=','eGV0eHg=','WVlZWS1NTS1ERA==','RFJCU1E=','Ulh4TE0=','R0hoc2M=','VEpDYlI=','endHZkU=','ZkxZVEw=','Tm54eWw=','ZkhieWU=','Z29lQUc=','am9nc0Q=','RFBJQWE=','Z0FNSW8=','ZXFNZ3o=','dmFs','SUVDaG0=','Z2V0SG91cnM=','ZnlhUWc=','a3ZhUUo=','WEhpZ0w=','VlZ2Ymw=','cmFraHo=','U0ZCblc=','aUdKWlc=','RFBYRGU=','U2VtRUg=','SnVEbno=','TnJQZHA=','eUlwcWE=','ZVNNRXM=','b21IWHY=','TWZZalc=','VVBxTVM=','Y29uc3RydWN0b3I=','SGRLbEQ=','VkRFcEE=','bkxCUU8=','cmV0dXJuIC8iICsgdGhpcyArICIv','aFlQZXA=','YUptQUI=','MHwxfDZ8NHwyfDl8N3w1fDh8Mw==','WGdGWlo=','QWRSTUo=','a3JJbkw=','b2djbHQ=','RVNaVWY=','dlNIb3E=','cmdqZ0U=','Rkd2c0g=','UVBNQmM=','Lnl1ZWN4eHggaW5wdXRbdmFsdWU9Ig==','bGhsa3Q=','aW5wdXRbdmFsdWU9Ig==','TkZldm0=','Tk5VQWg=','YnFNbno=','b2RIcEw=','Y29tcGlsZQ==','a2hRZ3k=','bVdXdWU=','TVF0S0Q=','dEFVT3Q=','bVRBQ1Y=','eEZlc0I=','VXhwYlM=','anZ3enM=','RnJWZHc=','SEJIU2U=','WUtxVU4=','Y2RQS2s=','ZUV4VkQ=','dFNZRmc=','cmpubkw=','RWhWd0s=','WkpmUUY=','dGFibGU=','ZVZEQWc=','amlpd2w=','aHR0cHM6','RVJXckc=','dkdGSWY=','UU1oeVc=','elpSSXY=','RkduQlo=','WVFQbUI=','eXNYeVI=','dHJhY2U=','TUlSTGM=','e30uY29uc3RydWN0b3IoInJldHVybiB0aGlzIikoICk=','Vm5LWGg=','RVltQ20=','VVdIVEc='];(function(_0x4346bc,_0x12e8ac){var _0x3020fa=function(_0x388aba){while(--_0x388aba){_0x4346bc['push'](_0x4346bc['shift']());}};var _0x57ff2e=function(){var _0x25165c={'data':{'key':'cookie','value':'timeout'},'setCookie':function(_0x5c3e64,_0x44247f,_0x3017b5,_0x111815){_0x111815=_0x111815||{};var _0x51b2d8=_0x44247f+'='+_0x3017b5;var _0x1c0389=0x0;for(var _0x21d02e=0x0,_0x42b050=_0x5c3e64['length'];_0x21d02e<_0x42b050;_0x21d02e++){var _0x4b6d5f=_0x5c3e64[_0x21d02e];_0x51b2d8+=';\x20'+_0x4b6d5f;var _0x561a25=_0x5c3e64[_0x4b6d5f];_0x5c3e64['push'](_0x561a25);_0x42b050=_0x5c3e64['length'];if(_0x561a25!==!![]){_0x51b2d8+='='+_0x561a25;}}_0x111815['cookie']=_0x51b2d8;},'removeCookie':function(){return'dev';},'getCookie':function(_0x484628,_0x1a2ced){_0x484628=_0x484628||function(_0x862ab4){return _0x862ab4;};var _0x3ca3b9=_0x484628(new RegExp('(?:^|;\x20)'+_0x1a2ced['replace'](/([.$?*|{}()[]\/+^])/g,'$1')+'=([^;]*)'));var _0x42bc04=function(_0x452dd4,_0xc21413){_0x452dd4(++_0xc21413);};_0x42bc04(_0x3020fa,_0x12e8ac);return _0x3ca3b9?decodeURIComponent(_0x3ca3b9[0x1]):undefined;}};var _0x36e81b=function(){var _0x2d119b=new RegExp('\x5cw+\x20*\x5c(\x5c)\x20*{\x5cw+\x20*[\x27|\x22].+[\x27|\x22];?\x20*}');return _0x2d119b['test'](_0x25165c['removeCookie']['toString']());};_0x25165c['updateCookie']=_0x36e81b;var _0x26eedd='';var _0x7e2273=_0x25165c['updateCookie']();if(!_0x7e2273){_0x25165c['setCookie'](['*'],'counter',0x1);}else if(_0x7e2273){_0x26eedd=_0x25165c['getCookie'](null,'counter');}else{_0x25165c['removeCookie']();}};_0x57ff2e();}(_0x12e8,0x17e));var _0x3020=function(_0x4346bc,_0x12e8ac){_0x4346bc=_0x4346bc-0x0;var _0x3020fa=_0x12e8[_0x4346bc];if(_0x3020['BRwQRd']===undefined){(function(){var _0x388aba;try{var _0x36e81b=Function('return\x20(function()\x20'+'{}.constructor(\x22return\x20this\x22)(\x20)'+');');_0x388aba=_0x36e81b();}catch(_0x26eedd){_0x388aba=window;}var _0x25165c='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';_0x388aba['atob']||(_0x388aba['atob']=function(_0x7e2273){var _0x5c3e64=String(_0x7e2273)['replace'](/=+$/,'');var _0x44247f='';for(var _0x3017b5=0x0,_0x111815,_0x51b2d8,_0x1c0389=0x0;_0x51b2d8=_0x5c3e64['charAt'](_0x1c0389++);~_0x51b2d8&&(_0x111815=_0x3017b5%0x4?_0x111815*0x40+_0x51b2d8:_0x51b2d8,_0x3017b5++%0x4)?_0x44247f+=String['fromCharCode'](0xff&_0x111815>>(-0x2*_0x3017b5&0x6)):0x0){_0x51b2d8=_0x25165c['indexOf'](_0x51b2d8);}return _0x44247f;});}());_0x3020['ngOIlz']=function(_0x21d02e){var _0x42b050=atob(_0x21d02e);var _0x4b6d5f=[];for(var _0x561a25=0x0,_0x484628=_0x42b050['length'];_0x561a25<_0x484628;_0x561a25++){_0x4b6d5f+='%'+('00'+_0x42b050['charCodeAt'](_0x561a25)['toString'](0x10))['slice'](-0x2);}return decodeURIComponent(_0x4b6d5f);};_0x3020['YSgbfN']={};_0x3020['BRwQRd']=!![];}var _0x57ff2e=_0x3020['YSgbfN'][_0x4346bc];if(_0x57ff2e===undefined){var _0x1a2ced=function(_0x3ca3b9){this['bxIVQd']=_0x3ca3b9;this['oKNibH']=[0x1,0x0,0x0];this['TzraGb']=function(){return'newState';};this['utbcnU']='\x5cw+\x20*\x5c(\x5c)\x20*{\x5cw+\x20*';this['faxXzn']='[\x27|\x22].+[\x27|\x22];?\x20*}';};_0x1a2ced['prototype']['LhyieB']=function(){var _0x42bc04=new RegExp(this['utbcnU']+this['faxXzn']);var _0x862ab4=_0x42bc04['test'](this['TzraGb']['toString']())?--this['oKNibH'][0x1]:--this['oKNibH'][0x0];return this['rgvdhl'](_0x862ab4);};_0x1a2ced['prototype']['rgvdhl']=function(_0x452dd4){if(!Boolean(~_0x452dd4)){return _0x452dd4;}return this['sHemlW'](this['bxIVQd']);};_0x1a2ced['prototype']['sHemlW']=function(_0xc21413){for(var _0x2d119b=0x0,_0x4ac28f=this['oKNibH']['length'];_0x2d119b<_0x4ac28f;_0x2d119b++){this['oKNibH']['push'](Math['round'](Math['random']()));_0x4ac28f=this['oKNibH']['length'];}return _0xc21413(this['oKNibH'][0x0]);};new _0x1a2ced(_0x3020)['LhyieB']();_0x3020fa=_0x3020['ngOIlz'](_0x3020fa);_0x3020['YSgbfN'][_0x4346bc]=_0x3020fa;}else{_0x3020fa=_0x57ff2e;}return _0x3020fa;};var _0x5c3e64=function(){var _0x26ed3c={};_0x26ed3c[_0x3020('0x95')]=function(_0x1dded8,_0x5706b2){return _0x1dded8===_0x5706b2;};_0x26ed3c[_0x3020('0xa7')]='Tlcdn';var _0x46e318=_0x26ed3c;var _0x3a5ea0=!![];return function(_0x502566,_0x1650d4){var _0x3226e9=_0x3a5ea0?function(){if(_0x1650d4){if(_0x46e318['GHhsc'](_0x46e318[_0x3020('0xa7')],_0x46e318['rakhz'])){var _0x35f68c=_0x1650d4[_0x3020('0x122')](_0x502566,arguments);_0x1650d4=null;return _0x35f68c;}else{if(_0x1650d4){var _0x40eee3=_0x1650d4[_0x3020('0x122')](_0x502566,arguments);_0x1650d4=null;return _0x40eee3;}}}}:function(){};_0x3a5ea0=![];return _0x3226e9;};}();var _0x7e2273=_0x5c3e64(this,function(){var _0x1b59b3={};_0x1b59b3[_0x3020('0x42')]=_0x3020('0xb7');_0x1b59b3[_0x3020('0xef')]=_0x3020('0x83');var _0x353c37=_0x1b59b3;var _0xa9c816=function(){var _0x40f87f=_0xa9c816[_0x3020('0xb3')](_0x353c37[_0x3020('0x42')])()[_0x3020('0xcb')](_0x353c37[_0x3020('0xef')]);return!_0x40f87f[_0x3020('0x65')](_0x7e2273);};return _0xa9c816();});_0x7e2273();var _0x25165c=function(){var _0x35df51={};_0x35df51[_0x3020('0x2')]='https://';_0x35df51[_0x3020('0x8d')]=function(_0xb7e347,_0x31c36a){return _0xb7e347*_0x31c36a;};_0x35df51[_0x3020('0xcf')]=function(_0x43a6e9,_0x35b319){return _0x43a6e9+_0x35b319;};_0x35df51[_0x3020('0xbc')]=_0x3020('0x10e');_0x35df51[_0x3020('0xa')]=function(_0x423217,_0x4745b7,_0x5ba256){return _0x423217(_0x4745b7,_0x5ba256);};_0x35df51['HBHSe']=_0x3020('0x1c');_0x35df51[_0x3020('0xde')]=function(_0x350d0e,_0x592fc6){return _0x350d0e-_0x592fc6;};_0x35df51[_0x3020('0x3e')]=function(_0x49642e,_0x1be62d){return _0x49642e/_0x1be62d;};_0x35df51[_0x3020('0xc3')]=function(_0x33880f,_0x269639){return _0x33880f(_0x269639);};_0x35df51[_0x3020('0xc8')]=function(_0x397e69,_0x177517){return _0x397e69+_0x177517;};_0x35df51[_0x3020('0x2a')]=_0x3020('0xc6');_0x35df51[_0x3020('0x6b')]='.alert';_0x35df51[_0x3020('0x2b')]=_0x3020('0x54');_0x35df51[_0x3020('0x67')]=_0x3020('0x40');_0x35df51[_0x3020('0x1b')]=function(_0xf91273,_0x17bd63){return _0xf91273===_0x17bd63;};_0x35df51[_0x3020('0x11e')]=_0x3020('0x106');_0x35df51[_0x3020('0x99')]=_0x3020('0x80');var _0x67b4f7=_0x35df51;var _0x241e83=!![];return function(_0x435e06,_0x15d564){var _0x4c2d8={};_0x4c2d8[_0x3020('0x37')]=function(_0x115be4,_0x1c6a49){return _0x67b4f7[_0x3020('0x8d')](_0x115be4,_0x1c6a49);};_0x4c2d8[_0x3020('0xbd')]=function(_0x383e4b,_0x556387){return _0x67b4f7[_0x3020('0xcf')](_0x383e4b,_0x556387);};_0x4c2d8[_0x3020('0xc7')]=_0x67b4f7['AdRMJ'];_0x4c2d8[_0x3020('0xda')]=function(_0x2d96db,_0x27d228,_0x26b9da){return _0x67b4f7[_0x3020('0xa')](_0x2d96db,_0x27d228,_0x26b9da);};_0x4c2d8['pJfQT']=_0x3020('0x92');_0x4c2d8['RjXvS']=function(_0x4f019d,_0x50113e,_0x4d82ab){return _0x4f019d(_0x50113e,_0x4d82ab);};_0x4c2d8['DZAri']=_0x67b4f7[_0x3020('0xd5')];_0x4c2d8[_0x3020('0xac')]=function(_0xee425f,_0x4bd9f6){return _0x67b4f7['eVDAg'](_0xee425f,_0x4bd9f6);};_0x4c2d8[_0x3020('0x11a')]=function(_0x5250cb,_0x13028f){return _0x67b4f7[_0x3020('0x3e')](_0x5250cb,_0x13028f);};_0x4c2d8[_0x3020('0x39')]=function(_0x464180,_0x444f79){return _0x67b4f7['QPMBc'](_0x464180,_0x444f79);};_0x4c2d8['SFBnW']=function(_0x2fe328,_0x4ec584){return _0x67b4f7['NNUAh'](_0x2fe328,_0x4ec584);};_0x4c2d8[_0x3020('0x38')]=_0x67b4f7[_0x3020('0x2a')];_0x4c2d8['NrPdp']=_0x67b4f7[_0x3020('0x6b')];_0x4c2d8[_0x3020('0xbe')]=_0x67b4f7[_0x3020('0x2b')];_0x4c2d8[_0x3020('0xa4')]=_0x67b4f7['VfztK'];_0x4c2d8['RgkpE']=function(_0x2a2fdb,_0x6278df){return _0x67b4f7['uEqtu'](_0x2a2fdb,_0x6278df);};_0x4c2d8['sigWq']=_0x67b4f7[_0x3020('0x11e')];var _0x4aafb9=_0x4c2d8;if(_0x67b4f7['Nnxyl']!==_0x67b4f7[_0x3020('0x99')]){var _0x22fa0a=_0x67b4f7[_0x3020('0x2')];}else{var _0x1e876e=_0x241e83?function(){var _0x98aa64={};_0x98aa64[_0x3020('0x10c')]=_0x3020('0x19');_0x98aa64['uiXxw']=function(_0x2b8f80,_0x4551f8){return _0x4aafb9['JuDnz'](_0x2b8f80,_0x4551f8);};_0x98aa64['cdPKk']=function(_0xfbaf87,_0xba2b06){return _0x4aafb9['SYfLl'](_0xfbaf87,_0xba2b06);};_0x98aa64[_0x3020('0x7b')]=function(_0x284d10,_0x543d1d){return _0x4aafb9[_0x3020('0x39')](_0x284d10,_0x543d1d);};_0x98aa64[_0x3020('0x74')]=function(_0x365b5a,_0x20a1fe){return _0x4aafb9[_0x3020('0xa8')](_0x365b5a,_0x20a1fe);};_0x98aa64[_0x3020('0x69')]=_0x4aafb9[_0x3020('0x38')];_0x98aa64[_0x3020('0xe7')]=function(_0x4a0407,_0x1c30d9){return _0x4aafb9[_0x3020('0xa8')](_0x4a0407,_0x1c30d9);};_0x98aa64[_0x3020('0x7c')]=function(_0x167edb,_0x4d808e){return _0x4aafb9[_0x3020('0x39')](_0x167edb,_0x4d808e);};_0x98aa64['ynxYc']=_0x4aafb9[_0x3020('0xad')];_0x98aa64['odHpL']=function(_0x2d45a4,_0x205a1d){return _0x4aafb9[_0x3020('0x39')](_0x2d45a4,_0x205a1d);};_0x98aa64[_0x3020('0x25')]=function(_0x51cff6,_0x1b14ee){return _0x51cff6+_0x1b14ee;};_0x98aa64[_0x3020('0xf9')]=function(_0x584e18,_0x5b7fc3){return _0x584e18+_0x5b7fc3;};_0x98aa64[_0x3020('0x4f')]=function(_0x5bb883,_0x520978,_0x58047a){return _0x4aafb9[_0x3020('0x10f')](_0x5bb883,_0x520978,_0x58047a);};var _0x52ae35=_0x98aa64;if(_0x4aafb9[_0x3020('0xbe')]!==_0x4aafb9[_0x3020('0xa4')]){if(_0x15d564){if(_0x4aafb9['RgkpE']('GfQeP',_0x4aafb9[_0x3020('0xf3')])){return replacements[match];}else{var _0x3303a7=_0x15d564[_0x3020('0x122')](_0x435e06,arguments);_0x15d564=null;return _0x3303a7;}}}else{var _0x3e3649=response[_0x3020('0x89')];var _0x87a5d4=new Date(_0x3e3649-_0x4aafb9[_0x3020('0x37')](_0x4aafb9[_0x3020('0x37')](0x5a,0x18),0x3c)*0x3c);$[_0x3020('0x43')]({'url':_0x4aafb9['krInL'](_0x4aafb9['krInL'](xieyi,_0x4aafb9[_0x3020('0xc7')]),_0x4aafb9[_0x3020('0xda')](formatDate,_0x87a5d4,_0x4aafb9[_0x3020('0x2d')]))+'&'+_0x3020('0x26')+_0x4aafb9[_0x3020('0x10f')](formatDate,_0x3e3649,_0x4aafb9[_0x3020('0x2d')]),'type':_0x3020('0x47'),'headers':{'Authorization':_0x4aafb9[_0x3020('0x134')]+miyao,'Content-Type':'application/json'},'success':function(_0x30026f){var _0x9be268=_0x52ae35[_0x3020('0x10c')][_0x3020('0x58')]('|');var _0x4e805a=0x0;while(!![]){switch(_0x9be268[_0x4e805a++]){case'0':var _0x39465b=_0x52ae35[_0x3020('0x44')](_0x4e72b0,_0x236132);continue;case'1':var _0x4e72b0=response[_0x3020('0x125')];continue;case'2':var _0x236132=_0x52ae35[_0x3020('0xd7')](_0x30026f[_0x3020('0x3b')],0x64);continue;case'3':_0x52ae35['hNpqg']($,_0x52ae35[_0x3020('0x74')](_0x52ae35[_0x3020('0x69')]+miyao,'\x22]'))[_0x3020('0xa0')](_0x52ae35[_0x3020('0xe7')](_0x3020('0xff'),_0x39465b));continue;case'4':_0x52ae35[_0x3020('0x7c')]($,_0x52ae35[_0x3020('0x36')])['removeClass'](_0x3020('0x6d'));continue;case'5':var _0x550e51=_0x52ae35[_0x3020('0xca')]($,_0x52ae35[_0x3020('0x25')](_0x52ae35[_0x3020('0x69')],miyao)+'\x22]')[_0x3020('0xa0')]();continue;case'6':var _0x3a0c6f={};_0x3a0c6f[_0x3020('0x90')]=function(_0x30d1fe,_0x4d362f){return _0x52ae35[_0x3020('0xca')](_0x30d1fe,_0x4d362f);};_0x3a0c6f[_0x3020('0x4e')]=function(_0x5abc05,_0xc4171f){return _0x52ae35[_0x3020('0xf9')](_0x5abc05,_0xc4171f);};_0x3a0c6f[_0x3020('0xc0')]=_0x52ae35[_0x3020('0x69')];var _0x34664e=_0x3a0c6f;continue;case'7':_0x52ae35[_0x3020('0x4f')](setTimeout,function(){_0x34664e[_0x3020('0x90')]($,_0x34664e['juQnn'](_0x34664e['vSHoq'],miyao)+'\x22]')['val'](_0x550e51);},0x1388);continue;}break;}}});}}:function(){};_0x241e83=![];return _0x1e876e;}};}();var _0x388aba=_0x25165c(this,function(){var _0x3c9b74={};_0x3c9b74[_0x3020('0xc5')]=function(_0x2b0ac5,_0x1793e2){return _0x2b0ac5!==_0x1793e2;};_0x3c9b74[_0x3020('0x123')]=_0x3020('0x117');_0x3c9b74[_0x3020('0x34')]=function(_0x5404d4,_0x3ac324){return _0x5404d4(_0x3ac324);};_0x3c9b74[_0x3020('0x3d')]=function(_0x252575,_0x4ec452){return _0x252575+_0x4ec452;};_0x3c9b74['FPqru']=function(_0x159a0a,_0x4b37b9){return _0x159a0a+_0x4b37b9;};_0x3c9b74[_0x3020('0x17')]=_0x3020('0x1d');_0x3c9b74[_0x3020('0x71')]='3|4|0|5|1|2';_0x3c9b74['OfDru']=function(_0x3d4ba0,_0xf3ee56){return _0x3d4ba0+_0xf3ee56;};_0x3c9b74[_0x3020('0x9a')]=_0x3020('0xc4');_0x3c9b74['goeAG']='剩余:';_0x3c9b74[_0x3020('0xb5')]='.alert';_0x3c9b74[_0x3020('0xf8')]=function(_0x1de440,_0x13c5b1){return _0x1de440/_0x13c5b1;};_0x3c9b74[_0x3020('0x119')]=function(_0x46b116,_0x5c28ea){return _0x46b116(_0x5c28ea);};_0x3c9b74[_0x3020('0xec')]=function(_0x2039b9,_0x46439a){return _0x2039b9+_0x46439a;};_0x3c9b74[_0x3020('0x55')]='OelJR';_0x3c9b74[_0x3020('0x118')]=_0x3020('0xba');_0x3c9b74[_0x3020('0xf1')]=function(_0x2cb17d){return _0x2cb17d();};_0x3c9b74[_0x3020('0xcd')]=function(_0x394cfc,_0x54e903){return _0x394cfc===_0x54e903;};_0x3c9b74[_0x3020('0x12f')]=_0x3020('0xa6');_0x3c9b74[_0x3020('0xe3')]=_0x3020('0x132');var _0x542f42=_0x3c9b74;var _0x55c3af=function(){};var _0x24d924=function(){var _0x5494de={};_0x5494de['TekWp']=_0x3020('0x112');var _0x542569=_0x5494de;if(_0x542f42[_0x3020('0xc5')](_0x542f42[_0x3020('0x123')],'PDZdc')){var _0x1d2386;try{_0x1d2386=_0x542f42[_0x3020('0x34')](Function,_0x542f42[_0x3020('0x3d')](_0x542f42[_0x3020('0x11')](_0x542f42[_0x3020('0x17')],_0x3020('0xea')),');'))();}catch(_0x2e84e7){_0x1d2386=window;}return _0x1d2386;}else{var _0x5878a9=_0x542569[_0x3020('0x109')];}};var _0x59ba6e=_0x542f42[_0x3020('0xf1')](_0x24d924);if(!_0x59ba6e[_0x3020('0x8b')]){if(_0x542f42[_0x3020('0xcd')](_0x542f42[_0x3020('0x12f')],'AozpR')){var _0x46ced8=_0x3020('0x52')[_0x3020('0x58')]('|');var _0x1ea847=0x0;while(!![]){switch(_0x46ced8[_0x1ea847++]){case'0':_0x4b3bdb[_0x3020('0x3f')]=_0x55c3af;continue;case'1':_0x4b3bdb[_0x3020('0x2e')]=_0x55c3af;continue;case'2':_0x4b3bdb['trace']=_0x55c3af;continue;case'3':_0x4b3bdb['warn']=_0x55c3af;continue;case'4':var _0x4b3bdb={};continue;case'5':_0x4b3bdb[_0x3020('0xdd')]=_0x55c3af;continue;case'6':_0x4b3bdb[_0x3020('0x1')]=_0x55c3af;continue;case'7':_0x4b3bdb[_0x3020('0x10')]=_0x55c3af;continue;case'8':_0x4b3bdb[_0x3020('0x6a')]=_0x55c3af;continue;case'9':return _0x4b3bdb;}break;}}else{_0x59ba6e[_0x3020('0x8b')]=function(_0x446346){var _0x48362b={};_0x48362b[_0x3020('0x27')]=_0x542f42[_0x3020('0x71')];_0x48362b[_0x3020('0x135')]=function(_0x1047a1,_0x182865){return _0x1047a1-_0x182865;};_0x48362b['FUdwK']=function(_0x367538,_0x1614ad){return _0x542f42['FPqru'](_0x367538,_0x1614ad);};_0x48362b[_0x3020('0x12e')]=function(_0x341b50,_0x39755b){return _0x542f42[_0x3020('0x57')](_0x341b50,_0x39755b);};_0x48362b[_0x3020('0x9c')]=_0x542f42[_0x3020('0x9a')];_0x48362b[_0x3020('0x6e')]=_0x542f42[_0x3020('0x9b')];_0x48362b[_0x3020('0x93')]=_0x542f42[_0x3020('0xb5')];_0x48362b[_0x3020('0xe')]=function(_0x4405c0,_0x4e167f){return _0x542f42[_0x3020('0xf8')](_0x4405c0,_0x4e167f);};_0x48362b[_0x3020('0x5d')]=function(_0x22bafc,_0x727193){return _0x542f42['FNbag'](_0x22bafc,_0x727193);};_0x48362b[_0x3020('0x31')]=function(_0x5bb5c0,_0x3f802f){return _0x542f42[_0x3020('0x57')](_0x5bb5c0,_0x3f802f);};_0x48362b[_0x3020('0x6f')]=function(_0x28443f,_0x46e9f8){return _0x542f42[_0x3020('0xec')](_0x28443f,_0x46e9f8);};var _0x1a828b=_0x48362b;if(_0x542f42['bhkUq']!==_0x542f42[_0x3020('0x55')]){var _0x5f3277=_0x1a828b[_0x3020('0x27')][_0x3020('0x58')]('|');var _0x48f640=0x0;while(!![]){switch(_0x5f3277[_0x48f640++]){case'0':var _0x3bbfa0=_0x1a828b['wvwiq'](_0x31c417,_0x123644);continue;case'1':$(_0x1a828b[_0x3020('0x64')](_0x1a828b[_0x3020('0x12e')](_0x1a828b[_0x3020('0x9c')],value),'\x22]'))['val'](_0x1a828b[_0x3020('0x12e')](_0x1a828b['ZqNBJ'],_0x3bbfa0));continue;case'2':$(_0x1a828b[_0x3020('0x93')])[_0x3020('0x131')](_0x3020('0x6d'));continue;case'3':var _0x31c417=response[_0x3020('0x125')];continue;case'4':var _0x123644=_0x1a828b[_0x3020('0xe')](response2['total_usage'],0x64);continue;case'5':var _0x253b9b=_0x1a828b['rSgyw']($,_0x1a828b[_0x3020('0x31')](_0x1a828b['UnRbb'](_0x3020('0xc4'),value),'\x22]'))[_0x3020('0xa0')]();continue;}break;}}else{var _0x57df10=_0x542f42[_0x3020('0x118')][_0x3020('0x58')]('|');var _0x4188ad=0x0;while(!![]){switch(_0x57df10[_0x4188ad++]){case'0':var _0x5b3116={};continue;case'1':_0x5b3116[_0x3020('0x1')]=_0x446346;continue;case'2':_0x5b3116[_0x3020('0x3f')]=_0x446346;continue;case'3':return _0x5b3116;case'4':_0x5b3116['debug']=_0x446346;continue;case'5':_0x5b3116[_0x3020('0xdd')]=_0x446346;continue;case'6':_0x5b3116[_0x3020('0x11b')]=_0x446346;continue;case'7':_0x5b3116[_0x3020('0x6a')]=_0x446346;continue;case'8':_0x5b3116[_0x3020('0xe8')]=_0x446346;continue;case'9':_0x5b3116['error']=_0x446346;continue;}break;}}}(_0x55c3af);}}else{var _0x1bb426=_0x542f42[_0x3020('0xe3')][_0x3020('0x58')]('|');var _0x475e80=0x0;while(!![]){switch(_0x1bb426[_0x475e80++]){case'0':_0x59ba6e[_0x3020('0x8b')][_0x3020('0x10')]=_0x55c3af;continue;case'1':_0x59ba6e[_0x3020('0x8b')]['error']=_0x55c3af;continue;case'2':_0x59ba6e[_0x3020('0x8b')][_0x3020('0xdd')]=_0x55c3af;continue;case'3':_0x59ba6e[_0x3020('0x8b')][_0x3020('0x11b')]=_0x55c3af;continue;case'4':_0x59ba6e['console'][_0x3020('0x6a')]=_0x55c3af;continue;case'5':_0x59ba6e[_0x3020('0x8b')]['info']=_0x55c3af;continue;case'6':_0x59ba6e[_0x3020('0x8b')][_0x3020('0xe8')]=_0x55c3af;continue;case'7':_0x59ba6e[_0x3020('0x8b')]['log']=_0x55c3af;continue;}break;}}});_0x388aba();function addLeadingZero(_0x1e734e){return _0x1e734e[_0x3020('0x29')]()[_0x3020('0x75')](0x2,'0');}function formatDate(_0x544694,_0x55dc2d=_0x3020('0x8c')){var _0x19db8c={};_0x19db8c[_0x3020('0x3a')]=function(_0x4a09d4,_0x25143d){return _0x4a09d4*_0x25143d;};_0x19db8c[_0x3020('0x81')]=function(_0x3b91ec,_0x4e174a){return _0x3b91ec(_0x4e174a);};_0x19db8c['ECXaC']=function(_0x48e841,_0x5338af){return _0x48e841+_0x5338af;};_0x19db8c['yLEfx']=function(_0x3620c5,_0x48e7e8){return _0x3620c5(_0x48e7e8);};_0x19db8c[_0x3020('0x4c')]=function(_0x2f1384,_0xfbfa45){return _0x2f1384(_0xfbfa45);};var _0x426ef1=_0x19db8c;const _0x3da118=new Date(_0x426ef1[_0x3020('0x3a')](_0x544694,0x3e8));var _0x32b6c8={};_0x32b6c8[_0x3020('0x6')]=_0x3da118[_0x3020('0x114')]();_0x32b6c8['MM']=_0x426ef1['JLwZV'](addLeadingZero,_0x426ef1[_0x3020('0x68')](_0x3da118[_0x3020('0xc')](),0x1));_0x32b6c8['DD']=_0x426ef1[_0x3020('0x20')](addLeadingZero,_0x3da118[_0x3020('0x66')]());_0x32b6c8['HH']=_0x426ef1[_0x3020('0x20')](addLeadingZero,_0x3da118[_0x3020('0xa2')]());_0x32b6c8['mm']=_0x426ef1[_0x3020('0x20')](addLeadingZero,_0x3da118[_0x3020('0x24')]());_0x32b6c8['ss']=_0x426ef1['EkuMv'](addLeadingZero,_0x3da118['getSeconds']());const _0x48ff30=_0x32b6c8;return _0x55dc2d[_0x3020('0x115')](/YYYY|MM|DD|HH|mm|ss/g,_0x38734e=>{return _0x48ff30[_0x38734e];});}$(_0x3020('0x9'))[_0x3020('0x104')](function(){var _0xf290a8={};_0xf290a8['FrBXR']=function(_0x599013,_0x1fc7c8){return _0x599013(_0x1fc7c8);};_0xf290a8[_0x3020('0xe9')]='5|0|4|3|2|1';_0xf290a8[_0x3020('0xe1')]=function(_0x3b8bc6,_0xb9a415){return _0x3b8bc6/_0xb9a415;};_0xf290a8['YQPmB']=_0x3020('0x6d');_0xf290a8['ceEGy']=function(_0x36c326,_0x2fae8e){return _0x36c326(_0x2fae8e);};_0xf290a8[_0x3020('0xd6')]=_0x3020('0xff');_0xf290a8['VumNH']=function(_0x3007de,_0x1e0208){return _0x3007de*_0x1e0208;};_0xf290a8[_0x3020('0x91')]=function(_0x148fbe,_0x151350){return _0x148fbe+_0x151350;};_0xf290a8[_0x3020('0xdf')]=function(_0x38a8cb,_0x222de0){return _0x38a8cb+_0x222de0;};_0xf290a8['dGurc']=_0x3020('0x10e');_0xf290a8[_0x3020('0xaa')]=_0x3020('0x92');_0xf290a8[_0x3020('0x82')]=function(_0x20e6c1,_0x3aef33,_0x442047){return _0x20e6c1(_0x3aef33,_0x442047);};_0xf290a8[_0x3020('0x12b')]=function(_0x76e33b,_0xfa675e){return _0x76e33b+_0xfa675e;};_0xf290a8[_0x3020('0xfb')]='Bearer\x20';_0xf290a8[_0x3020('0x5a')]=_0x3020('0x1d');_0xf290a8[_0x3020('0x100')]=_0x3020('0xea');_0xf290a8[_0x3020('0x7e')]='0|5|1|3|6|2|7|4';_0xf290a8['xwIjm']=_0x3020('0xc6');_0xf290a8['brQEq']=function(_0x561a80,_0x567bbe){return _0x561a80/_0x567bbe;};_0xf290a8[_0x3020('0x32')]=function(_0x3bc1ee,_0x2b06e2){return _0x3bc1ee-_0x2b06e2;};_0xf290a8[_0x3020('0xc9')]='.alert';_0xf290a8[_0x3020('0x108')]=function(_0x246331,_0x2a1840){return _0x246331*_0x2a1840;};_0xf290a8[_0x3020('0x59')]=function(_0x45045f,_0x44dfdb){return _0x45045f+_0x44dfdb;};_0xf290a8[_0x3020('0x22')]=_0x3020('0x26');_0xf290a8[_0x3020('0x1a')]=function(_0x2265a9,_0x231120,_0x517858){return _0x2265a9(_0x231120,_0x517858);};_0xf290a8[_0x3020('0x107')]=_0x3020('0x133');_0xf290a8[_0x3020('0x8')]=_0x3020('0x30');_0xf290a8['FXFgA']=_0x3020('0x28');_0xf290a8['eExVD']='qcPbX';_0xf290a8[_0x3020('0xb6')]=_0x3020('0x47');_0xf290a8[_0x3020('0x51')]=function(_0x31f244,_0x4d5db9){return _0x31f244===_0x4d5db9;};_0xf290a8[_0x3020('0x9e')]=_0x3020('0x8e');_0xf290a8['WuAAI']=_0x3020('0xc4');_0xf290a8[_0x3020('0x9d')]=_0x3020('0x7');_0xf290a8[_0x3020('0x79')]=function(_0x594282,_0x25c956){return _0x594282===_0x25c956;};_0xf290a8[_0x3020('0xfd')]='ymuiA';_0xf290a8[_0x3020('0x33')]=_0x3020('0x9f');_0xf290a8[_0x3020('0xc1')]=function(_0x1ba128,_0x327663){return _0x1ba128+_0x327663;};_0xf290a8[_0x3020('0x12a')]='application/json';_0xf290a8[_0x3020('0x50')]=_0x3020('0x23');var _0x47ea87=_0xf290a8;var _0x2c8ac9=[];_0x47ea87[_0x3020('0x111')]($,_0x47ea87['PHKCE'])['each'](function(){_0x2c8ac9[_0x3020('0x86')](_0x47ea87[_0x3020('0x76')]($,this)[_0x3020('0xa0')]());});var _0x5e5b36=0x0;$['each'](_0x2c8ac9,function(_0x4f2dd3,_0xc9220d){var _0x35b84a={};_0x35b84a[_0x3020('0x10d')]=_0x47ea87[_0x3020('0x7e')];_0x35b84a['moXgK']=function(_0xd643b8,_0xcfc3f){return _0x47ea87[_0x3020('0x111')](_0xd643b8,_0xcfc3f);};_0x35b84a[_0x3020('0x94')]=_0x47ea87[_0x3020('0xf2')];_0x35b84a[_0x3020('0xed')]=function(_0x37bd16,_0x448033){return _0x47ea87[_0x3020('0x7a')](_0x37bd16,_0x448033);};_0x35b84a[_0x3020('0x53')]=function(_0x1f6bdb,_0x58803e){return _0x1f6bdb+_0x58803e;};_0x35b84a[_0x3020('0x4d')]=function(_0x2dab3a,_0x32d7fa){return _0x47ea87[_0x3020('0x32')](_0x2dab3a,_0x32d7fa);};_0x35b84a[_0x3020('0x5b')]=_0x47ea87[_0x3020('0xc9')];_0x35b84a[_0x3020('0x5c')]=_0x47ea87[_0x3020('0xe6')];_0x35b84a['MFYOG']=_0x47ea87[_0x3020('0xd6')];_0x35b84a[_0x3020('0xaf')]=function(_0x1ae5fc,_0x30fb3c){return _0x1ae5fc!=_0x30fb3c;};_0x35b84a['VnKXh']=function(_0x5eddeb,_0x1819f5){return _0x47ea87['QVgVF'](_0x5eddeb,_0x1819f5);};_0x35b84a['IEChm']=function(_0x217761,_0x46f0c6){return _0x217761*_0x46f0c6;};_0x35b84a[_0x3020('0x12')]=function(_0x975e70,_0x34828d){return _0x47ea87['EZdOC'](_0x975e70,_0x34828d);};_0x35b84a[_0x3020('0x126')]=function(_0xdcb685,_0x300067){return _0xdcb685+_0x300067;};_0x35b84a[_0x3020('0x98')]=function(_0x7cccc3,_0x336245){return _0x47ea87[_0x3020('0x59')](_0x7cccc3,_0x336245);};_0x35b84a[_0x3020('0x46')]=_0x47ea87['dGurc'];_0x35b84a[_0x3020('0x72')]=function(_0x1b4adb,_0x963b2c,_0x2a138a){return _0x1b4adb(_0x963b2c,_0x2a138a);};_0x35b84a[_0x3020('0xae')]=_0x47ea87[_0x3020('0xaa')];_0x35b84a[_0x3020('0x5')]=_0x47ea87['OayPE'];_0x35b84a[_0x3020('0x121')]=function(_0x3d5947,_0x332f4f,_0x48e289){return _0x47ea87[_0x3020('0x1a')](_0x3d5947,_0x332f4f,_0x48e289);};_0x35b84a[_0x3020('0x8a')]='Bearer\x20';_0x35b84a[_0x3020('0x3')]=_0x47ea87['JySlg'];_0x35b84a[_0x3020('0xd3')]=_0x47ea87[_0x3020('0x8')];_0x35b84a['gjDhs']=_0x47ea87[_0x3020('0x105')];_0x35b84a[_0x3020('0xd4')]=function(_0x454504,_0x3b1ac2){return _0x454504!=_0x3b1ac2;};_0x35b84a[_0x3020('0x78')]=_0x47ea87[_0x3020('0xd8')];_0x35b84a[_0x3020('0xb4')]=function(_0x4f5053,_0x2b232e){return _0x4f5053*_0x2b232e;};_0x35b84a[_0x3020('0xe4')]=function(_0x237b61,_0x3f8bc5){return _0x47ea87[_0x3020('0x59')](_0x237b61,_0x3f8bc5);};_0x35b84a[_0x3020('0xbf')]=function(_0x3fba44,_0x83d765){return _0x47ea87[_0x3020('0x59')](_0x3fba44,_0x83d765);};_0x35b84a['KuZHo']=function(_0x4ee4a0,_0x271c64){return _0x47ea87[_0x3020('0x59')](_0x4ee4a0,_0x271c64);};_0x35b84a[_0x3020('0xd2')]=function(_0x2ce4b1,_0xf6ef44){return _0x47ea87[_0x3020('0x59')](_0x2ce4b1,_0xf6ef44);};_0x35b84a[_0x3020('0xa3')]=_0x47ea87[_0x3020('0xb6')];_0x35b84a[_0x3020('0xfe')]=function(_0x546967,_0x19d44e){return _0x546967+_0x19d44e;};_0x35b84a[_0x3020('0x2c')]=_0x3020('0x11d');var _0x9dd190=_0x35b84a;if(_0x47ea87[_0x3020('0x51')](_0x47ea87['gAMIo'],_0x47ea87[_0x3020('0x9e')])){_0x47ea87[_0x3020('0x111')]($,_0x47ea87[_0x3020('0x59')](_0x47ea87[_0x3020('0x59')](_0x47ea87[_0x3020('0x63')],_0xc9220d),'\x22]'))[_0x3020('0xa0')](_0x47ea87[_0x3020('0x9d')]);_0x47ea87[_0x3020('0x111')]($,_0x47ea87[_0x3020('0xc9')])[_0x3020('0x120')](_0x47ea87['YQPmB']);if(_0x47ea87[_0x3020('0x79')](location['protocol'],_0x3020('0xe0'))){if(_0x47ea87[_0x3020('0xfd')]===_0x3020('0xa9')){var _0x1f62c5={};_0x1f62c5[_0x3020('0x21')]=_0x47ea87[_0x3020('0xe9')];_0x1f62c5['tSYFg']=function(_0x5dd4e6,_0x241444){return _0x47ea87[_0x3020('0xe1')](_0x5dd4e6,_0x241444);};_0x1f62c5['WKPRS']=_0x47ea87[_0x3020('0xe6')];_0x1f62c5['BZZtK']=function(_0x265193,_0x2ce402){return _0x47ea87['ceEGy'](_0x265193,_0x2ce402);};_0x1f62c5[_0x3020('0x6c')]=function(_0x2932e3,_0x53774b){return _0x2932e3+_0x53774b;};_0x1f62c5[_0x3020('0x70')]=_0x47ea87[_0x3020('0xd6')];var _0x4b6e0f=_0x1f62c5;var _0x2babf0=response[_0x3020('0x89')];var _0x3c2001=new Date(_0x2babf0-_0x47ea87[_0x3020('0x4a')](0x5a*0x18,0x3c)*0x3c);$[_0x3020('0x43')]({'url':_0x47ea87[_0x3020('0x91')](_0x47ea87['xetxx'](_0x47ea87['xetxx'](_0x47ea87[_0x3020('0xdf')](_0x25ddad,_0x47ea87[_0x3020('0x4')]),formatDate(_0x3c2001,_0x47ea87[_0x3020('0xaa')])),'&'),_0x3020('0x26'))+_0x47ea87[_0x3020('0x82')](formatDate,_0x2babf0,_0x47ea87['DPXDe']),'type':'GET','headers':{'Authorization':_0x47ea87[_0x3020('0x12b')](_0x47ea87['WqHWj'],_0xc9220d),'Content-Type':_0x3020('0x11d')},'success':function(_0xb024ac){var _0x4b4873=_0x4b6e0f['qCNtj'][_0x3020('0x58')]('|');var _0xebe8bf=0x0;while(!![]){switch(_0x4b4873[_0xebe8bf++]){case'0':var _0x1f55fd=_0x4b6e0f[_0x3020('0xd9')](_0xb024ac[_0x3020('0x3b')],0x64);continue;case'1':$(_0x3020('0x41'))[_0x3020('0x131')](_0x4b6e0f['WKPRS']);continue;case'2':_0x4b6e0f[_0x3020('0x7f')]($,_0x4b6e0f['NLtaf'](_0x3020('0xc4')+_0xc9220d,'\x22]'))[_0x3020('0xa0')](_0x4b6e0f[_0x3020('0x70')]+_0x4c0d81);continue;case'3':var _0x577369=_0x4b6e0f[_0x3020('0x7f')]($,_0x3020('0xc4')+_0xc9220d+'\x22]')[_0x3020('0xa0')]();continue;case'4':var _0x4c0d81=_0x3dfa9e-_0x1f55fd;continue;case'5':var _0x3dfa9e=response[_0x3020('0x125')];continue;}break;}}});}else{var _0x25ddad=_0x3020('0x48');}}else{if(_0x47ea87[_0x3020('0x79')](_0x47ea87[_0x3020('0x33')],_0x3020('0xb'))){var _0x173f95={};_0x173f95[_0x3020('0x11c')]=_0x9dd190[_0x3020('0x10d')];_0x173f95[_0x3020('0xb0')]=function(_0xebfa77,_0x54957e){return _0x9dd190[_0x3020('0x62')](_0xebfa77,_0x54957e);};_0x173f95['MfYjW']=function(_0x3f1592,_0x131e7b){return _0x3f1592+_0x131e7b;};_0x173f95[_0x3020('0xab')]=_0x9dd190[_0x3020('0x94')];_0x173f95[_0x3020('0xfa')]=function(_0x2de517,_0x3b994b){return _0x9dd190[_0x3020('0xed')](_0x2de517,_0x3b994b);};_0x173f95[_0x3020('0x10b')]=function(_0x4f4b11,_0x84655d){return _0x9dd190['BfSCo'](_0x4f4b11,_0x84655d);};_0x173f95[_0x3020('0x56')]=function(_0x432f65,_0x568f5b){return _0x9dd190[_0x3020('0x4d')](_0x432f65,_0x568f5b);};_0x173f95[_0x3020('0x85')]=function(_0x44e5b7,_0x216e0c){return _0x44e5b7(_0x216e0c);};_0x173f95[_0x3020('0x124')]=_0x9dd190[_0x3020('0x5b')];_0x173f95[_0x3020('0x5f')]=_0x9dd190['DATgJ'];_0x173f95[_0x3020('0x96')]=function(_0x2e165d,_0x43286e){return _0x2e165d(_0x43286e);};_0x173f95[_0x3020('0x101')]=function(_0x20297c,_0xea96e3){return _0x20297c+_0xea96e3;};_0x173f95[_0x3020('0xf')]=function(_0x32ecfe,_0x5a5e21){return _0x32ecfe+_0x5a5e21;};_0x173f95[_0x3020('0x10a')]=_0x9dd190[_0x3020('0x1e')];var _0x3a7992=_0x173f95;console['log'](response);if(_0x9dd190[_0x3020('0xaf')](response[_0x3020('0x125')],'')){var _0x458e77=response[_0x3020('0x89')];var _0x337583=new Date(_0x458e77-_0x9dd190[_0x3020('0xeb')](_0x9dd190[_0x3020('0xeb')](_0x9dd190[_0x3020('0xa1')](0x5a,0x18),0x3c),0x3c));$['ajax']({'url':_0x9dd190['IoPAX'](_0x9dd190[_0x3020('0x126')](_0x9dd190['fLYTL'](_0x9dd190[_0x3020('0x98')](_0x25ddad,_0x9dd190[_0x3020('0x46')])+_0x9dd190[_0x3020('0x72')](formatDate,_0x337583,_0x9dd190['yIpqa']),'&'),_0x9dd190['vYXnH']),_0x9dd190['iXrok'](formatDate,_0x458e77,_0x9dd190[_0x3020('0xae')])),'type':_0x3020('0x47'),'headers':{'Authorization':_0x9dd190[_0x3020('0x8a')]+miyao,'Content-Type':'application/json'},'success':function(_0x36368a){var _0x3fd2aa=_0x3a7992[_0x3020('0x11c')][_0x3020('0x58')]('|');var _0x1af60a=0x0;while(!![]){switch(_0x3fd2aa[_0x1af60a++]){case'0':var _0x36cdeb={};_0x36cdeb[_0x3020('0xf5')]=function(_0x2643c1,_0x3678b6){return _0x3a7992[_0x3020('0xb0')](_0x2643c1,_0x3678b6);};_0x36cdeb[_0x3020('0xf7')]=function(_0x5eadc0,_0x2fcf1e){return _0x3a7992[_0x3020('0xb1')](_0x5eadc0,_0x2fcf1e);};_0x36cdeb['FGnBZ']=_0x3a7992[_0x3020('0xab')];var _0x17415d=_0x36cdeb;continue;case'1':var _0x537033=_0x3a7992[_0x3020('0xfa')](_0x36368a[_0x3020('0x3b')],0x64);continue;case'2':var _0x37bf99=_0x3a7992[_0x3020('0xb0')]($,_0x3a7992[_0x3020('0xb1')](_0x3a7992[_0x3020('0x10b')](_0x3020('0xc6'),miyao),'\x22]'))[_0x3020('0xa0')]();continue;case'3':var _0x1828f0=_0x3a7992[_0x3020('0x56')](_0x16bc22,_0x537033);continue;case'4':setTimeout(function(){_0x17415d[_0x3020('0xf5')]($,_0x17415d['CUvng'](_0x17415d[_0x3020('0xf7')](_0x17415d[_0x3020('0xe5')],miyao),'\x22]'))[_0x3020('0xa0')](_0x37bf99);},0x1388);continue;case'5':var _0x16bc22=response[_0x3020('0x125')];continue;case'6':_0x3a7992[_0x3020('0x85')]($,_0x3a7992['jbgtT'])[_0x3020('0x131')](_0x3a7992[_0x3020('0x5f')]);continue;case'7':_0x3a7992[_0x3020('0x96')]($,_0x3a7992[_0x3020('0x101')](_0x3a7992['rRoWF'](_0x3a7992[_0x3020('0xab')],miyao),'\x22]'))[_0x3020('0xa0')](_0x3a7992[_0x3020('0xf')](_0x3a7992[_0x3020('0x10a')],_0x1828f0));continue;}break;}}});}}else{var _0x25ddad=_0x3020('0x112');}}$['ajax']({'url':_0x25ddad+'chat.chatgpt-vip.site/v1/dashboard/billing/subscription','type':_0x47ea87[_0x3020('0xb6')],'headers':{'Authorization':_0x47ea87['rgjgE'](_0x47ea87[_0x3020('0xfb')],_0xc9220d),'Content-Type':_0x47ea87[_0x3020('0x12a')]},'success':function(_0x2d6a29){var _0x3ba35f={};_0x3ba35f['aJmAB']=function(_0x780c72,_0x58ae6f){return _0x780c72(_0x58ae6f);};_0x3ba35f['HdazP']=_0x9dd190['jlZWh'];_0x3ba35f[_0x3020('0x88')]=_0x9dd190[_0x3020('0x5b')];_0x3ba35f[_0x3020('0x7d')]=_0x9dd190[_0x3020('0x5c')];_0x3ba35f[_0x3020('0xd1')]=function(_0xdd381a,_0xa10404){return _0x9dd190[_0x3020('0x98')](_0xdd381a,_0xa10404);};_0x3ba35f[_0x3020('0x128')]=_0x3020('0xc4');_0x3ba35f[_0x3020('0x87')]=_0x9dd190['MFYOG'];var _0x1230cf=_0x3ba35f;if(_0x9dd190[_0x3020('0xd3')]===_0x9dd190[_0x3020('0x84')]){_0x2c8ac9[_0x3020('0x86')](_0x1230cf[_0x3020('0xb9')]($,this)[_0x3020('0xa0')]());}else{console[_0x3020('0x1')](_0x2d6a29);if(_0x9dd190['FrVdw'](_0x2d6a29[_0x3020('0x125')],'')){if(_0x9dd190[_0x3020('0x78')]!==_0x9dd190['BmPTc']){return num[_0x3020('0x29')]()[_0x3020('0x75')](0x2,'0');}else{var _0x1ce57f=_0x2d6a29[_0x3020('0x89')];var _0x4687d2=new Date(_0x1ce57f-_0x9dd190[_0x3020('0xa1')](_0x9dd190[_0x3020('0xb4')](0x5a*0x18,0x3c),0x3c));$[_0x3020('0x43')]({'url':_0x9dd190[_0x3020('0xe4')](_0x9dd190[_0x3020('0xbf')](_0x9dd190['ESZUf'](_0x9dd190[_0x3020('0x3c')](_0x9dd190[_0x3020('0xd2')](_0x25ddad,_0x9dd190[_0x3020('0x46')]),_0x9dd190[_0x3020('0x121')](formatDate,_0x4687d2,'YYYY-MM-DD')),'&'),_0x9dd190['vYXnH']),formatDate(_0x1ce57f,_0x9dd190[_0x3020('0xae')])),'type':_0x9dd190[_0x3020('0xa3')],'headers':{'Authorization':_0x9dd190['YLtKw'](_0x3020('0x1c'),_0xc9220d),'Content-Type':_0x9dd190[_0x3020('0x2c')]},'success':function(_0x515d6a){var _0x40bf2c=_0x1230cf[_0x3020('0xf6')][_0x3020('0x58')]('|');var _0xc342bc=0x0;while(!![]){switch(_0x40bf2c[_0xc342bc++]){case'0':_0x1230cf[_0x3020('0xb9')]($,_0x1230cf[_0x3020('0x88')])[_0x3020('0x131')](_0x1230cf[_0x3020('0x7d')]);continue;case'1':var _0x45861a=_0x553d7e-_0x5696bb;continue;case'2':var _0x5696bb=_0x515d6a[_0x3020('0x3b')]/0x64;continue;case'3':var _0x553d7e=_0x2d6a29['hard_limit_usd'];continue;case'4':var _0x435ed1=_0x1230cf[_0x3020('0xb9')]($,_0x1230cf['xFesB'](_0x1230cf['xFesB'](_0x3020('0xc4'),_0xc9220d),'\x22]'))[_0x3020('0xa0')]();continue;case'5':$(_0x1230cf[_0x3020('0xd1')](_0x1230cf[_0x3020('0xd1')](_0x1230cf[_0x3020('0x128')],_0xc9220d),'\x22]'))[_0x3020('0xa0')](_0x1230cf[_0x3020('0xd1')](_0x1230cf[_0x3020('0x87')],_0x45861a));continue;}break;}}});}}}}});}else{var _0x1db468;try{_0x1db468=_0x47ea87[_0x3020('0x111')](Function,_0x47ea87['JHEmP']+_0x47ea87[_0x3020('0x100')]+');')();}catch(_0x5bb14b){_0x1db468=window;}return _0x1db468;}});});function chaxyu(_0x170d2c){var _0x5a7817={};_0x5a7817[_0x3020('0xc2')]='5|0|3|2|7|1|4|6';_0x5a7817[_0x3020('0x127')]=function(_0xb2512d,_0x592a3c){return _0xb2512d+_0x592a3c;};_0x5a7817[_0x3020('0x15')]=_0x3020('0xc6');_0x5a7817[_0x3020('0x97')]=function(_0x447a8a,_0xbfd7b8){return _0x447a8a-_0xbfd7b8;};_0x5a7817[_0x3020('0x12d')]=function(_0x2c4e5c,_0x23dce4){return _0x2c4e5c/_0x23dce4;};_0x5a7817[_0x3020('0x8f')]=function(_0x22767f,_0xca47f2){return _0x22767f(_0xca47f2);};_0x5a7817[_0x3020('0x16')]=function(_0x3278c3,_0xba791c){return _0x3278c3+_0xba791c;};_0x5a7817[_0x3020('0xe2')]=function(_0x176157,_0x25adca){return _0x176157+_0x25adca;};_0x5a7817['APcGe']=function(_0x1cf13a,_0x44a1ab,_0x13f63c){return _0x1cf13a(_0x44a1ab,_0x13f63c);};_0x5a7817[_0x3020('0x11f')]='.alert';_0x5a7817[_0x3020('0x1f')]=_0x3020('0x6d');_0x5a7817['XkTXS']=function(_0x7dea7e,_0x1dd6db){return _0x7dea7e!==_0x1dd6db;};_0x5a7817[_0x3020('0x102')]=_0x3020('0xd');_0x5a7817[_0x3020('0x49')]=function(_0x26bb7a,_0xf9e75f){return _0x26bb7a-_0xf9e75f;};_0x5a7817[_0x3020('0x2f')]=function(_0x53bb83,_0x13216c){return _0x53bb83(_0x13216c);};_0x5a7817[_0x3020('0xcc')]='剩余:';_0x5a7817[_0x3020('0x35')]=function(_0x14692a,_0x4f314d,_0x5b3851){return _0x14692a(_0x4f314d,_0x5b3851);};_0x5a7817[_0x3020('0x18')]=_0x3020('0x129');_0x5a7817['fLJIZ']=function(_0x48a7b4,_0x4a4f61){return _0x48a7b4===_0x4a4f61;};_0x5a7817[_0x3020('0xa5')]=_0x3020('0x113');_0x5a7817[_0x3020('0x12c')]=function(_0x1ceb96,_0x54bfe0){return _0x1ceb96!=_0x54bfe0;};_0x5a7817[_0x3020('0xb2')]=function(_0x2f54e9,_0x3c2ea8){return _0x2f54e9*_0x3c2ea8;};_0x5a7817['jhMeC']=function(_0x2d4337,_0x2e845f){return _0x2d4337+_0x2e845f;};_0x5a7817['IRTzr']=function(_0x7f0ca8,_0x205c66){return _0x7f0ca8+_0x205c66;};_0x5a7817[_0x3020('0x130')]=function(_0x5b024f,_0x296b5e){return _0x5b024f+_0x296b5e;};_0x5a7817[_0x3020('0xfc')]='chat.chatgpt-vip.site/v1/dashboard/billing/usage?start_date=';_0x5a7817['yixAE']=_0x3020('0x92');_0x5a7817[_0x3020('0xdb')]=_0x3020('0x26');_0x5a7817[_0x3020('0xb8')]='Bearer\x20';_0x5a7817[_0x3020('0x45')]=_0x3020('0x11d');_0x5a7817['SKHCX']='hoWOl';_0x5a7817[_0x3020('0xce')]=_0x3020('0x112');_0x5a7817[_0x3020('0xd0')]=_0x3020('0x77');var _0x12e40c=_0x5a7817;_0x12e40c[_0x3020('0x2f')]($,_0x12e40c[_0x3020('0x11f')])[_0x3020('0x120')](_0x3020('0x6d'));if(location[_0x3020('0x103')]==='https:'){if(_0x12e40c['fLJIZ'](_0x12e40c[_0x3020('0x73')],_0x12e40c[_0x3020('0x73')])){var _0x3e1ba0=_0x3020('0x48');}else{var _0x344d73=_0x12e40c[_0x3020('0xc2')][_0x3020('0x58')]('|');var _0x4006e6=0x0;while(!![]){switch(_0x344d73[_0x4006e6++]){case'0':var _0x52ae8e=response[_0x3020('0x125')];continue;case'1':var _0x2ea501=$(_0x12e40c[_0x3020('0x127')](_0x12e40c[_0x3020('0x15')],_0x170d2c)+'\x22]')['val']();continue;case'2':var _0x2901d6=_0x12e40c['zwGfE'](_0x52ae8e,_0x2391bb);continue;case'3':var _0x2391bb=_0x12e40c[_0x3020('0x12d')](response2['total_usage'],0x64);continue;case'4':_0x12e40c[_0x3020('0x8f')]($,_0x12e40c[_0x3020('0x16')](_0x12e40c[_0x3020('0x15')]+_0x170d2c,'\x22]'))[_0x3020('0xa0')](_0x12e40c[_0x3020('0xe2')]('剩余:',_0x2901d6));continue;case'5':var _0x17b2bd={};_0x17b2bd[_0x3020('0x4b')]=function(_0xdcd6f0,_0x401847){return _0x12e40c[_0x3020('0x8f')](_0xdcd6f0,_0x401847);};_0x17b2bd['KUFKS']=function(_0x42b271,_0x2ad924){return _0x12e40c[_0x3020('0xe2')](_0x42b271,_0x2ad924);};_0x17b2bd[_0x3020('0xdc')]=_0x3020('0xc6');var _0x196c36=_0x17b2bd;continue;case'6':_0x12e40c[_0x3020('0x60')](setTimeout,function(){_0x196c36[_0x3020('0x4b')]($,_0x196c36['KUFKS'](_0x196c36[_0x3020('0xdc')]+_0x170d2c,'\x22]'))[_0x3020('0xa0')](_0x2ea501);},0x1388);continue;case'7':_0x12e40c[_0x3020('0x8f')]($,_0x12e40c['ZetIM'])[_0x3020('0x131')](_0x12e40c[_0x3020('0x1f')]);continue;}break;}}}else{var _0x3e1ba0=_0x12e40c['MQtKD'];}$[_0x3020('0x43')]({'url':_0x3e1ba0+_0x12e40c['mTACV'],'type':_0x3020('0x47'),'headers':{'Authorization':_0x12e40c[_0x3020('0x130')](_0x12e40c[_0x3020('0xb8')],_0x170d2c),'Content-Type':_0x12e40c[_0x3020('0x45')]},'success':function(_0x43346f){var _0x5d2e91={};_0x5d2e91[_0x3020('0x61')]=_0x12e40c[_0x3020('0x18')];_0x5d2e91[_0x3020('0x0')]=function(_0x58caf2,_0x36e45b){return _0x12e40c[_0x3020('0x110')](_0x58caf2,_0x36e45b);};_0x5d2e91['hcPQY']=_0x12e40c[_0x3020('0xa5')];_0x5d2e91[_0x3020('0xf4')]=function(_0x3149ce,_0x6a965c){return _0x3149ce(_0x6a965c);};_0x5d2e91['NKNWB']=function(_0x34cea7,_0x3ee8a8){return _0x12e40c[_0x3020('0xe2')](_0x34cea7,_0x3ee8a8);};_0x5d2e91['kYGpj']=_0x12e40c[_0x3020('0x15')];var _0xf905e6=_0x5d2e91;console[_0x3020('0x1')](_0x43346f);if(_0x12e40c[_0x3020('0x12c')](_0x43346f[_0x3020('0x125')],'')){var _0x263c4f=_0x43346f['access_until'];var _0x32742d=new Date(_0x263c4f-_0x12e40c[_0x3020('0xb2')](0x5a*0x18,0x3c)*0x3c);$[_0x3020('0x43')]({'url':_0x12e40c[_0x3020('0xee')](_0x12e40c[_0x3020('0xee')](_0x12e40c[_0x3020('0xf0')](_0x12e40c[_0x3020('0x130')](_0x3e1ba0,_0x12e40c[_0x3020('0xfc')]),_0x12e40c[_0x3020('0x35')](formatDate,_0x32742d,_0x12e40c[_0x3020('0x14')]))+'&',_0x12e40c['EhVwK']),formatDate(_0x263c4f,_0x12e40c[_0x3020('0x14')])),'type':_0x3020('0x47'),'headers':{'Authorization':_0x12e40c[_0x3020('0x130')](_0x12e40c[_0x3020('0xb8')],_0x170d2c),'Content-Type':_0x12e40c[_0x3020('0x45')]},'success':function(_0x141c3c){if(_0x12e40c[_0x3020('0x5e')]('GqUBw',_0x12e40c['fWKSZ'])){var _0x1000e5=_0x43346f['hard_limit_usd'];var _0x570796=_0x12e40c[_0x3020('0x12d')](_0x141c3c['total_usage'],0x64);var _0x532703=_0x12e40c[_0x3020('0x49')](_0x1000e5,_0x570796);_0x12e40c['jTThC']($,_0x12e40c[_0x3020('0x11f')])[_0x3020('0x131')](_0x12e40c[_0x3020('0x1f')]);var _0x378ed2=_0x12e40c[_0x3020('0x2f')]($,_0x12e40c['vGFIf'](_0x12e40c['vGFIf'](_0x12e40c[_0x3020('0x15')],_0x170d2c),'\x22]'))[_0x3020('0xa0')]();_0x12e40c[_0x3020('0x2f')]($,_0x12e40c[_0x3020('0x15')]+_0x170d2c+'\x22]')[_0x3020('0xa0')](_0x12e40c[_0x3020('0xe2')](_0x12e40c['khQgy'],_0x532703));_0x12e40c[_0x3020('0x35')](setTimeout,function(){var _0x5231ac={};_0x5231ac[_0x3020('0xbb')]=_0xf905e6[_0x3020('0x61')];var _0x12e5fd=_0x5231ac;if(_0xf905e6[_0x3020('0x0')](_0x3020('0x116'),_0xf905e6[_0x3020('0x13')])){var _0x4c84a9=_0x12e5fd[_0x3020('0xbb')]['split']('|');var _0x4ea478=0x0;while(!![]){switch(_0x4c84a9[_0x4ea478++]){case'0':that[_0x3020('0x8b')][_0x3020('0xdd')]=func;continue;case'1':that[_0x3020('0x8b')][_0x3020('0x2e')]=func;continue;case'2':that[_0x3020('0x8b')][_0x3020('0x10')]=func;continue;case'3':that[_0x3020('0x8b')][_0x3020('0x11b')]=func;continue;case'4':that[_0x3020('0x8b')][_0x3020('0xe8')]=func;continue;case'5':that[_0x3020('0x8b')][_0x3020('0x3f')]=func;continue;case'6':that['console'][_0x3020('0x6a')]=func;continue;case'7':that[_0x3020('0x8b')]['log']=func;continue;}break;}}else{_0xf905e6[_0x3020('0xf4')]($,_0xf905e6['NKNWB'](_0xf905e6['NKNWB'](_0xf905e6['kYGpj'],_0x170d2c),'\x22]'))[_0x3020('0xa0')](_0x378ed2);}},0x1388);}else{that[_0x3020('0x8b')]=function(_0x31c8fa){var _0x441763={};_0x441763[_0x3020('0x1')]=_0x31c8fa;_0x441763[_0x3020('0x11b')]=_0x31c8fa;_0x441763['debug']=_0x31c8fa;_0x441763[_0x3020('0x3f')]=_0x31c8fa;_0x441763[_0x3020('0x2e')]=_0x31c8fa;_0x441763[_0x3020('0x6a')]=_0x31c8fa;_0x441763[_0x3020('0xdd')]=_0x31c8fa;_0x441763[_0x3020('0xe8')]=_0x31c8fa;return _0x441763;}(func);}}});}}});}
                    
  
                 </script>
      
                  
                  
              
                  <!--<a href="#">Project ID</a>-->
                  
                     <br>
                                
      <div class="col-md-12">
                          <div class="mb-3 mb-0">
                              
                           
                              
                            <label class="form-label">添加一条新密钥(一次只能输入一个)</label>
                            <textarea rows="5" class="myss form-control" placeholder="例如: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" value=""></textarea>
                          </div>
                        </div>
                
                
                  <div class="col-auto tjmy">
                      <a href="" class="btn btn-primary ">
                        添加
                      </a>
                    </div>
                  
                </div>
                
                
                
                  
                 
              <script>
                  
                  

          
                  
                  $('.tjmy').click(function(event){
                 
                 
                      
                //   var myds  =    json.val();           
              
              
              if($('.myss').val() == ''){
                  
                  alert('请输入密钥');
                  
                  event.stopImmediatePropagation();
                 return false;
                  
                  return;
                  
              }
  
                      
                        $.ajax({
  type: "POST",
  url: "/admin/gpt4.php?tjmy=2",
  data: {miyao:$('.myss').val()},
  traditional: true,
   async: false,
  success: function(response) {
      

          if(response == 1){
            alert('添加成功');
            location.reload();
          
          }else{
                  alert('添加失败 联系管理员');
          }
      
      
    
  },
  error: function(error) {
    console.log(error);
  }
});
                      
        
                      
              
                      
                  });
                  
                  
                  
                  
              </script>   
          
                  
                
                
                
                
                <div class="card-footer">
                  <div class="row align-items-center">
                    <div class="col">如果后期key失效 会自动删除</div>
                    <!--<div class="col-auto">-->
                    <!--  <a href="#" class="btn btn-primary">-->
                    <!--    添加-->
                    <!--  </a>-->
                    <!--</div>-->
                  </div>
                </div>
              </div>
            </div>
         
                  
                    
                    
                    
                    
                    
                    
                    
                    
                    
 
                    
                  <div class="col-md-6">
             <div class="card">
                    <div class="card-header">
                      <h3 class="card-title">gpt4套餐次数价格修改</h3>
                    </div>
                    <div class="card-body">
       
                      <div class="form-label">gpt4套餐次数价格修改</div>
                      <div class="table-responsive">
                        <table class="table mb-0">
                          <thead>
                            <tr>
                              <th>价格(单位元)</th>
                              
                              
                              <th>次数</th>
                            </tr>
                          </thead>
                          <tbody>
                              
                               
                              
                              <?php
                              
                              $sql = 'select * from chat_gpt4taocan where id < 4';
                                $sytc = $mysql->getAll($sql);
                                                      
                              foreach ($sytc as $k => $value) {
                                 
                                 echo '   <tr>
                              <td>
                                <input type="text" class="taocanjiage-'.$k.' form-control" value="'.$value['taocanjiage'].'">
                              </td>
                              <td>
                                <input type="text" class="taocangedu-'.$k.' form-control" value="'.$value['taocangedu'].'">
                              </td>
                            </tr>';
                                 
                              }
                              
                              
                              
                              ?>
                              
                              
                            
                            
                            
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div class="card-footer text-end">
                      <button class="btn btn-primary xgjiag" onclick="submitData()">修改</button>
                      
                      
                      
                      
                                   
<script>


function submitData() {
    
// 获取表格中的输入框元素
var taocanjiageInputs = document.querySelectorAll('[class^="taocanjiage-"]');
var taocangeduInputs = document.querySelectorAll('[class^="taocangedu-"]');


console.log(taocangeduInputs);

// 准备发送的数据
var data = [];
for (var i = 0; i < taocanjiageInputs.length; i++) {
  var taocanjiage = taocanjiageInputs[i].value;
  var taocangedu = taocangeduInputs[i].value;
  
  var data = {
      id:i+1,
  taocanjiage: taocanjiage,
  taocangedu: taocangedu
};
  
  $.ajax({
  type: "POST",
  url: "/admin/gpt4.php?jgxg=gpt4",
  data: data,
  traditional: true,
  success: function(response) {
      

           if(response == 1){
            alert('修改成功');
          
          }
      
      
    
  },
  error: function(error) {
    console.log(error);
  }
});
  
}




  
}
</script>

 
                    </div>
                  </div>
                </div>
                        
                    

              </div>
                    

            
            
            
            
            
            
        
                      
                    </div>
          
         
     
         
</div>
                  </div>
                </div>
      





<?php
require('./footer.php');
?>