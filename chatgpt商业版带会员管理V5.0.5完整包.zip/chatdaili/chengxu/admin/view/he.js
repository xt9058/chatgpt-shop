// window.onkeydown = window.onkeyup = window.onkeypress = function (event) {  
// // if (event.keyCode = 123) {  
// //         event.preventDefault(); 
// //         window.event.returnValue = false;  
// //     }  
// }    
// setInterval(function() {
// check()
// }, 4000);
// var check = function() {
// function doCheck(a) {
// if (("" + a / a)["length"] !== 1 || a % 20 === 0) {
// (function() {}
// ["constructor"]("debugger")())
// } else {
// (function() {}
// ["constructor"]("debugger")())
// }
// doCheck(++a)
// }
// try {
// doCheck(0)
// } catch (err) {}
// };
// check();
// let num = 0;
// const devtools = new Date();
// devtools.toString = function () {
//   num++;
//   if (num > 1) {
//     window.location.href = "http://360.cn";
//   }
// };
// function fuckyou(){
// window.close(); 
// window.location="about:blank"; 
// }
// function click(e) {
// if (document.all) {
//   if (event.button==2||event.button==3) { 
// oncontextmenu="return false";
// }
// }
// if (document.layers) {
// if (e.which == 3) {
// oncontextmenu="return false";
// }
// }
// }
// if (document.layers) {
// fuckyou();
// document.captureEvents(Event.MOUSEDOWN);
// }
// document.onmousedown=click;
// document.oncontextmenu = new Function("return false;")
// document.onkeydown =document.onkeyup = document.onkeypress=function(){ 
// if(window.event.keyCode == 123) { 
// fuckyou();
// window.event.returnValue=false;
// return(false); 
// } 
// }

var sfsc = '没有';


