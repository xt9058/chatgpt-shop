<?php include_once('./tool/get.php');?>
<?php
require('./code.php');
if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
    $ip = $_SERVER["HTTP_CF_CONNECTING_IP"];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
$expiration = time() + (30 * 24 * 60 * 60); 
setcookie("yhip", $ip, $expiration, "/");
require('./tool/coo.php');
require('./tool/pu.php');
if(($sfvip != '') || ($time2 < $time1)){
    $shihuiyuan = '是会员';
}
$banbenhao = file_get_contents($banbenhlj.'admin/banben.php');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="google" content="notranslate">
    <title><?php echo $wzmc;?></title>
    <meta name="description" content="<?php echo $wzms;?>">
    
<script type="text/javascript" src="/jquery.js?id=<?php echo $banbenhao;?>"></script>
<script src="/assets/jquery.cookie.min.js?id=<?php echo $banbenhao;?>"></script>          
<div id="cssah"></div>
<div id="cssah2"></div>
<script src="/assets/anse.js?id=<?php echo $banbenhao;?>"></script>    
<style>
</style>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="/css/index.css?id=<?php echo $banbenhao;?>">
    <script src="/assets/vue@2.62.js?id=<?php echo $banbenhao;?>"></script>
    <link rel="stylesheet" href="/assets/css.css?id=<?php echo $banbenhao;?>">
    
    
    <!--<link rel="stylesheet" href="assets/bo337.css">-->


    
    <link href="/assets/bootstrap.min.css?id=<?php echo $banbenhao;?>" rel="stylesheet">
	<link rel="stylesheet" href="/css/common.css?id=<?php echo $banbenhao;?>">
	<link rel="stylesheet" href="/css/wenda.css?id=<?php echo $banbenhao;?>">
	<link rel="stylesheet" href="/css/hightlight.css?id=<?php echo $banbenhao;?>">
	<link rel="stylesheet" href="/zidingyi.css?id=<?php echo $banbenhao;?>">
	<link href="/assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="/assets/lm.css?id=<?php echo $banbenhao;?>">
    <link rel="stylesheet" href="/css/css/jiazai.css?id=<?php echo $banbenhao;?>">
    <link rel="stylesheet" href="/css/css/youhua.css?id=<?php echo $banbenhao;?>">
</head>
<?php
include_once('./tool/head.php');
?>
<body style="background: white;">
    
<div id="moxicon" class="zbsc" style="display:none;background-color: #f6f6f6;">

<transition name="el-zoom-in-center">

<div  class="con-left" v-show="left_show||dw>800" style="height: 100%; 
    
    
  top: 0;
  bottom: 0;
  
  background-color: #fff;
  z-index: 999;">
        <div style="padding: 10px;position: relative;flex: 1;overflow: auto">
            <div style="display: flex;flex-direction: column">

    
    <?php
    
$sfyjdl = $_COOKIE['dengluname'];
if(!empty(uacc())){
    
    
    if($gpt35qd == '0'){
        if($shihuiyuan == '是会员'){
            echo '<div class="p-4 gmtc2" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
        height: var(--n-merged-size);
        color: #FFF;
        font-size: var(--n-font-size);
        display: inline-flex;
        position: relative;
        overflow: hidden;
        text-align: center;
        border: var(--n-border);
        border-radius: var(--n-border-radius);
        --n-merged-color: var(--n-color);
        background-color: var(--n-merged-color);
        transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
        height: 100%;" class="" loading="eager" src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1="" data-image-src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1=""><!----></span><p style="margin-top: 10px;"><span class="" style="color: white;"> Hi,'.$sfyjdl.'&nbsp;<span data-v-bf40dc81="" class="bg-yellow-200 text-yellow-900 py-0.5 px-1.5 text-xs md:text-sm rounded-md uppercase" style="text-transform: uppercase; font-size: 0.275rem; line-height: 1.25rem; --un-bg-opacity:1; background-color: rgba(254,240,138,var(--un-bg-opacity)); --un-text-opacity:1; color: rgba(113,63,18,var(--un-text-opacity)); padding: 0.125rem 0.375rem; border-radius: 0.375rem;"> 尊贵会员 </span></span></p></div>';
    
        
        }else{
            echo '<div class="p-4 gmtc2" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
        height: var(--n-merged-size);
        color: #FFF;
        font-size: var(--n-font-size);
        display: inline-flex;
        position: relative;
        overflow: hidden;
        text-align: center;
        border: var(--n-border);
        border-radius: var(--n-border-radius);
        --n-merged-color: var(--n-color);
        background-color: var(--n-merged-color);
        transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
        height: 100%;" class="" loading="eager" src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1="" data-image-src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1=""><!----></span><p style="margin-top: 10px;"><span class="" style="color: white;"> Hi,'.$sfyjdl.'&nbsp;<span data-v-bf40dc81="" class="bg-yellow-200 text-yellow-900 py-0.5 px-1.5 text-xs md:text-sm rounded-md uppercase" style="text-transform: uppercase; font-size: 0.275rem; line-height: 1.25rem; --un-bg-opacity:1; background-color: rgba(254,240,138,var(--un-bg-opacity)); --un-text-opacity:1; color: rgba(113,63,18,var(--un-text-opacity)); padding: 0.125rem 0.375rem; border-radius: 0.375rem;"> 升级会员 </span></span></p></div>';
        }
    }else{
        
        
        if($orqiandao == '已签到'){
            echo '<div class="p-4 weiqiandao" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
        height: var(--n-merged-size);
        color: #FFF;
        font-size: var(--n-font-size);
        display: inline-flex;
        position: relative;
        overflow: hidden;
        text-align: center;
        border: var(--n-border);
        border-radius: var(--n-border-radius);
        --n-merged-color: var(--n-color);
        background-color: var(--n-merged-color);
        transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
        height: 100%;" class="" loading="eager" src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1="" data-image-src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1=""><!----></span><p style="margin-top: 10px;"><span class="" style="color: white;"> Hi,'.$sfyjdl.'&nbsp;<span data-v-bf40dc81="" class="bg-yellow-200 text-yellow-900 py-0.5 px-1.5 text-xs md:text-sm rounded-md uppercase qdwz" style="text-transform: uppercase; font-size: 0.275rem; line-height: 1.25rem; --un-bg-opacity:1; background-color: rgba(254,240,138,var(--un-bg-opacity)); --un-text-opacity:1; color: rgba(113,63,18,var(--un-text-opacity)); padding: 0.125rem 0.375rem; border-radius: 0.375rem;"> 已签到 </span></span></p></div>';
        }else{
            echo '<div class="p-4 weiqiandao" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
        height: var(--n-merged-size);
        color: #FFF;
        font-size: var(--n-font-size);
        display: inline-flex;
        position: relative;
        overflow: hidden;
        text-align: center;
        border: var(--n-border);
        border-radius: var(--n-border-radius);
        --n-merged-color: var(--n-color);
        background-color: var(--n-merged-color);
        transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
        height: 100%;" class="" loading="eager" src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1="" data-image-src="https://q1.qlogo.cn/g?b=qq&nk='.$_COOKIE['txx'].'&s=100" width="30" alt="a" data-v-d44900b1=""><!----></span><p style="margin-top: 10px;"><span class="" style="color: white;"> Hi,'.$sfyjdl.'&nbsp;<span data-v-bf40dc81="" class="bg-yellow-200 text-yellow-900 py-0.5 px-1.5 text-xs md:text-sm rounded-md uppercase qdwz" style="text-transform: uppercase; font-size: 0.275rem; line-height: 1.25rem; --un-bg-opacity:1; background-color: rgba(254,240,138,var(--un-bg-opacity)); --un-text-opacity:1; color: rgba(113,63,18,var(--un-text-opacity)); padding: 0.125rem 0.375rem; border-radius: 0.375rem;"> 未签到 </span></span></p></div>';
        }
    }
    
}else{
    echo '<div class="p-4 dlzc" style="text-align: center; cursor: pointer;padding: 1rem;"><span class="n-avatar" style="--n-font-size:14px; --n-border:none; --n-border-radius:50%; --n-color:rgba(204, 204, 204, 1); --n-color-modal:rgba(204, 204, 204, 1); --n-color-popover:rgba(204, 204, 204, 1); --n-bezier:cubic-bezier(0.4, 0, 0.2, 1); --n-merged-size:var(--n-avatar-size-override, 40px);width: var(--n-merged-size);
    height: var(--n-merged-size);
    color: #FFF;
    font-size: var(--n-font-size);
    display: inline-flex;
    position: relative;
    overflow: hidden;
    text-align: center;
    border: var(--n-border);
    border-radius: var(--n-border-radius);
    --n-merged-color: var(--n-color);
    background-color: var(--n-merged-color);
    transition: border-color .3s var(--n-bezier), background-color .3s var(--n-bezier), color .3s var(--n-bezier);"><img style="width: 100%;
    height: 100%;" class="dlzc" loading="eager" src="/assets/anonymous.jpg" data-image-src="/assets/anonymous.jpg"><!----></span><p style="margin-top: 10px;"><span class="dlzc" style="color: white;">点击登录</span></p></div>';
}
    
    ?>
               
            
               <div class="talk-add tjxhh"><i class="el-icon-plus all-talk-icon"></i>
                    新会话
                </div>
               
               
               
               <div id="xdh">
                   
        
                   
               </div>
               
 
               
               
            </div>
        </div>
        <div class="left-bottom" style="">
            <ul style="" >
    
            <li class="indextz">
            <i class="fa fa-send" aria-hidden="true" /></i>
                    <a href="index.php"> 回到ChatGPT提问</a>
                </li>

          
 

    
                    <?php

$sfyjdl = $_COOKIE['dengluname'];
if(!empty(uacc())){
    
    echo '
								
				
						  <li class="yqhy">
              
<i class="fa fa-share-alt" aria-hidden="true" /></i> 邀请好友(可提现)
                </li>		';
    
}else{
    
    
    echo '  <li class="dlzc">
              
<i class="fa fa-share-alt" aria-hidden="true" /></i> 邀请好友(可提现)
                </li>';
    
}


?>
     

         

                
              <?php

$sfyjdl = $_COOKIE['dengluname'];
if(!empty(uacc())){
    
    
    if($shihuiyuan == '是会员'){
        
          echo '<li  @click.stop="nydl()" class="" style="display: flex;flex-direction: row;position: relative" >
                    <a><i class="el-icon-s-custom"></i> Hi,'.$sfyjdl.'</a>     <span class="" style="background: linear-gradient(to right,#ce9434,#fcb848);
                    font-size: 12px;padding: 1px 2px;border-radius: 4px;margin-left: 10px" >尊贵会员</span>
                    
            <li>
            <a href="index.php?tcdl=1">
                 <i class="el-icon-switch-button"></i> 退出登录</a>
                
                </li>    ';
        
    }else{
          echo '<li  @click.stop="nydl()" class="" style="display: flex;flex-direction: row;position: relative" >
                    <a><i class="el-icon-s-custom"></i> Hi,'.$sfyjdl.'</a>     <span class="" style="background: linear-gradient(to right,#ce9434,#fcb848);
                    font-size: 12px;padding: 1px 2px;border-radius: 4px;margin-left: 10px" >升级会员</span>
                    
            <li>
             <a href="index.php?tcdl=1">
                 <i class="el-icon-switch-button"></i> 退出登录</a>
                
                </li>    ';
    }
    

}else{
    echo '  <li  @click.stop="loginOut()" class="dlzc" style="display: flex;flex-direction: row;position: relative" >
                    <a><i class="el-icon-s-custom"></i> 登录or注册</a>     <span class="dlzc" style="background: linear-gradient(to right,#ce9434,#fcb848);
                    font-size: 12px;padding: 1px 2px;border-radius: 4px;margin-left: 10px" >升级会员</span>';
}


    ?>
    
                </li>
                
                
                
<!--更多-->            
<?php
include_once('./tool/gengduo.php');
?>             
                




            </ul>
            
            <br><br>
            
        </div>
</div>
    </transition>



<?php


$user_agent = $_SERVER['HTTP_USER_AGENT'];

if (preg_match('/(iPhone|Android|Windows Phone)/i', $user_agent)) { ?>
   

<div style="z-index: 9; margin: 0px 0 0 0; height:100% " class="con-right" id="con-right" :style="'width: '+con_w+'px;left:'+left_w+'px;'" >
    
    
   <?php } else { ?>

<div style="z-index: 9; margin: 0px 0 0 0; height:100% " class="con-right" id="con-right" :style="'width: '+con_w+'px;left:'+left_w+'px;'" >
    

   <?php } ?> 






<div class="wzfbcl mjh1" style="position: relative; border-radius: 5px;margin: 30px auto; padding: 20px; width: 80%;">
    
    <h1 style="--tw-text-opacity: 1;
    color: black;    text-align: center;font-size: 40px;   font-weight: 600; word-break: keep-all; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">AiChat面具模式</h1>

<br>
<h1 style="--tw-text-opacity:1;color: black;text-align: center;font-size: 30px;font-weight: 600;text-overflow: ellipsis;">与100+AI角色情景对话，当然你也可以创建自己的AI角色!</h1>


<br>
<div style="text-align: center;">
<button class="btn btn-primary wjskl">无角色开聊</button>
&nbsp;&nbsp;&nbsp;
<button  class="btn btn-lgbtn btn-success" data-bs-toggle="modal" data-bs-target="#myModal">自定义Ai角色</button>
</div>

<br>

 
 
 
 
 
 
 
 
<div class="dzuiw" style="">


 
 
 
 
 
<div class="container">
    
    
<h3 style="font-weight: 700;
    font-size: 18px;" class="dzuiwh3"><span></span> 全部角色：</h3>
<br>

  <div class="row">
      
      
      
      
<?php

$sql = "select * from chat_prompt order by id desc";
$all = $mysql->getAll($sql);

if(empty($all)){
    echo '管理员没有发布Prompt角色扮演数据';
}else{

foreach ($all as $value) {

?>

    <div class="col-lg-3 col-md-3 col-sm-6 col-6 mb-4">
      <div class="card h-100" id="<?php echo $value['id'];?>">
        <div class="card-body d-flex align-items-center">
          <!--<div class="rounded-circle bg-secondary mr-3" style="width: 50px; height: 50px;"></div>-->
          <img loading="eager" src="<?php echo $value['prompttb'];?>" style="height: 56px;width: 56px;border-radius: 50%;position: relative;left: -7px;">
          
          
          <div style="    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;">
            <h5 class="card-title mb-0"><?php echo $value['promptbt'];?></h5>
            <p class="card-text"><?php echo $value['promptyjh'];?></p>
          </div>
        </div>
      </div>
    </div> 
      
 
      
<?php

}
    
    
}

?>  
      
      
      
 

      
      
      
      



    
  </div>
</div>

 
 
 
 
 
 
 
 
 
 
 
 


</div>













</div>



<div class="call-box"></div>

</div>

        <div class="call-box" style="display:;   " :style="'width: '+con_w+'px;left:'+left_w+'px;'" >

        
            <div class="sjdh" v-show="dw<=800" style="width: 100%;height: 60px;background: #474646;position: fixed;left: 0;top: 0;text-align: center;color: #fff;z-index: 100;line-height: 60px;">
        
                Ai Chat机器人   
        
        <div class="jzbb" v-if="left_show" style="width: 100%;height: 100vh;background: rgba(140,147,157,0.46);position: fixed;left: 0;top: 0" @click="left_show=false"></div>
        
        
        <span :class="left_show?'el-icon-s-fold fold-icon left_menu_icon':'el-icon-s-unfold fold-icon left_menu_icon sjdhdj'" :style="left_show?'left:'+lw+'px':'' " @click="left_show = !left_show"></span>

    </div>
        
        
								<input   style="    display:none;
    
             height: 25px;
    padding: 0px 5px;
    font-size: 15px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    border: 1px solid #000;
    border-radius: 4px;
    -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
    box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
    -webkit-transition: border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;
    -o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
    transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;" class="" type="text"  placeholder="sk-xxxxxxxxxx" maxlength="100" id="key" value="<?php echo $_COOKIE['key'];?>" style="    background-color: rgb(234, 235, 241);min-width:200px;max-width:280px">


		</div>

</div>
    


<!--添加-->
<div class="modal fade in" id="myModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Prompt角色添加</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                   <form id="myForm" action="prompt.php" method="post">
                        <div class="mb-3">
                            <label for="name" class="form-label">Prompt标题-例如：李白</label>
                            <br>
                            <input style="height:38px;" name="promc" type="text" class="form-control promc" id="name" value="">
                        </div>
                        <!--<div class="mb-3">-->
                        <!--    <label for="email" class="form-label">Prompt标题 例如：李白</label>-->
                        <!--    <input type="email" class="form-control" id="email">-->
                        <!--</div>-->
                        <div class="mb-3">
                            <label for="message" class="form-label">Prompt内容-例如：请你充当李白，以李白的诗歌风格回答问题。可以结合李白的人生经历、文学修养，作诗风格进行回答。请用能够体现出李白诗歌风格的口吻回答我的任何问题，营造一种和真实的李白对话的感觉。</label>
                            <br>
                            <textarea style="    height: 150px;" name="pronr" class="form-control pronr" id="message" value=""></textarea>
                        </div>
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">关闭</button>
                    <button type="submit" form="myForm" class="btn btn-primary ljkl">立即开聊</button>
                </div>
                
                </form>
            </div>
        </div>
    </div>







<div class="loading-wrap">
	<div class="balls">
			<div></div>
			<div></div>
			<div></div>
	</div>
</div>





</body>





 <style>
        .modal-backdrop {
            opacity: 0.5 !important;
        }
    </style>

<style>
 
 textarea {
    resize: vertical!important;
}
 
 
 label {
    display: unset;
    width: unset;
    height: unset;
    border-radius: unset;
    background: unset;
    border: unset;
    cursor: unset;
    position: unset;
    overflow: unset;
}
 
 .form-control {
    display: block!important;
    width: 100%!important;
    padding: .375rem .75rem!important;
    font-size: 1rem!important;
    font-weight: 400!important;
    line-height: 1.5!important;
    color: #212529!important;
    background-color: #fff!important;
    background-clip: padding-box!important;
    border: 1px solid #ced4da!important;
    -webkit-appearance: none!important;
    -moz-appearance: none!important;
    appearance: none!important;
    border-radius: .25rem!important;
    transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out!important;
}
 .modal-content {
    position: relative!important;
    display: flex!important;
    flex-direction: column!important;
    width: 100%!important;
    pointer-events: auto!important;
    background-color: #fff!important;
    background-clip: padding-box!important;
    border: 1px solid rgba(0,0,0,.2)!important;
    border-radius: .3rem!important;
    outline: 0!important;
}
 .modal-body {
    position: relative!important;
    flex: 1 1 auto!important;
    padding: 1rem!important;
}
 .modal-body {
    text-align: unset;
    background: unset;
    border-radius: unset;
    /* margin: 45% 0 0 0; */
    /* position: absolute; */
}
 .card p{
         overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
 }
 
    
.zwcjs{
      /*width: 1186px;*/
    margin: 0 auto;
    
}




.zwcjs .zwcjsx{
 
    width: 19%;
    margin-bottom: 5px;
    
    border-radius: 5px;

}

    
  @media (max-width: 640px){
      .zwcjs{
      width: 100%;
    margin: 0 auto;
}


.zwcjs .zwcjsx{
    width: 100%;
}



.wzfbcl{
    width: 100%!important;
}



  }   
    
    
</style>



<style>

.wzfbcl h1, h2, h3, h4, h5, h6, small {
    /*font-size: revert!important;*/
}

.wzfbcl ul li {
    list-style: disc!important;
}

.wzfbcl ol li{
    list-style: unset!important;
}

.wzfbcl img{
        margin: 10px 0px 10px 0px;
}

.wzfbcl p{
        margin: 10px 0px 10px 0px;
}

.wzfbcl hr{
 margin: 10px 0px 10px 0px;
}
 .wzfbcl p{
          color:black;
      }
      
      
  .wzfbcl img{
      width: 50%;
  }     
      
      
    .form-control{
            /*height: unset!important;*/
            -webkit-box-shadow:unset!important;
    }
    

    .con-right{
        position: relative;
    }
    
    .jzbb{
        background: white;
    }
    
    
    .containersrk{
        position: relative;
    }
    
    @media (min-width: 640px){
        .sjdh{
            display: none;
        }
 
    }
    
.dtsrk {
      padding: 0.7rem 0.5rem;
    line-height: 1.3 !important;
}

.card:hover {
  cursor: pointer;
}


</style>


<script>
    $(document).ready(function() {
        $(".ljkl").click(function() {
            var name = $(".probt").val();
            var message = $(".pronr").val();
            if (name == "" || message == "") {
                alert("表单不完整！");
                return false;
            }
        });
    });
</script>


<script>


$(function() {
    
    
$('.card').click(function() {
 var IdName = $(this).attr('id');
     window.location.href='prompt.php?prompt='+IdName;    
}); 
    
    

$('.wjskl').click(function() {
     window.location.href='prompt.php?prompt='+'无角色';    
}); 
    




    
setTimeout(function() {
if (!(isMobile())) {
  $(".con-right").css("top", '0px');
  
}else{
     $(".con-right").css("height", '90%');
}
  }, 1);
});
</script>  
<script src="/assets/bootstrap.min.js?id=<?php echo $banbenhao;?>"></script>
<script>
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="xiazatp"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl)
    })
</script> 
<script src="/assets/lm.js?id=<?php echo $banbenhao;?>">"></script>
<script src="/zidingyi.js?id=<?php echo $banbenhao;?>"></script>
<script src="js/remarkable.js?id=<?php echo $banbenhao;?>"></script>
<script src="js/jquery.min.js?id=<?php echo $banbenhao;?>"></script>
<script src="js/jquery.cookie.min.js?id=<?php echo $banbenhao;?>"></script>
<script src="js/layer.min.js" type="application/javascript"></script>
<script src="js/chat.js?id=<?php echo $banbenhao;?>"></script>
<script src="js/highlight.min.js?id=<?php echo $banbenhao;?>"></script>
<script src="js/showdown.min.js?id=<?php echo $banbenhao;?>"></script>

<script>
    $(window).on('load', function() {
       $('.zbsc').css('display','unset');
       $('.loading-wrap').css('display','none');
       
       
    });
</script>


<?php
include_once('./tool/tongji.php');
?>


</html>
<?php include_once('./tool/getend.php');?>