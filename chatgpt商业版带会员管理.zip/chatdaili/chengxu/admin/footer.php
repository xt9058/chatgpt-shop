  <div class="footer">
        <div class="container">
          <div class="row">
            <div class="col-lg-8">
              <div class="row">
               
                <div class="col-6 col-md-3">
                  <ul class="list-unstyled mb-0">
                  
                   <li><a>ChatGPT系统</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <!--<div class="col-lg-4 mt-4 mt-lg-0">-->
            <!-- ChatGPT网站-->
            <!--</div>-->
          </div>
        </div>
      </div>

    </div>
    
      <script src="view/zidingyi.js"></script>
    
  </body>
</html>